#ifndef LDID_CMS_ATTRIBUTE_ENGINE_HPP
#define LDID_CMS_ATTRIBUTE_ENGINE_HPP

#include "ldid.hpp"
#include "der_engine.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <limits>
#include <string>
#include <vector>

#include <openssl/asn1.h>
#include <openssl/err.h>
#include <openssl/objects.h>
#include <openssl/pkcs7.h>
#include <openssl/x509.h>

namespace ldid::crypto::cms_attributes {

inline void append_der_length(std::vector<uint8_t>& out, size_t length) {
    if (length < 128U) {
        out.push_back(static_cast<uint8_t>(length));
        return;
    }
    uint8_t encoded[sizeof(size_t)]{};
    size_t count = 0;
    for (size_t value = length; value != 0; value >>= 8) encoded[sizeof(encoded) - 1U - count++] = static_cast<uint8_t>(value & 0xffU);
    out.push_back(static_cast<uint8_t>(0x80U | count));
    out.insert(out.end(), encoded + sizeof(encoded) - count, encoded + sizeof(encoded));
}

inline std::vector<uint8_t> wrap_der(uint8_t tag, const std::vector<uint8_t>& content) {
    std::vector<uint8_t> out;
    out.reserve(1U + sizeof(size_t) + content.size());
    out.push_back(tag);
    append_der_length(out, content.size());
    out.insert(out.end(), content.begin(), content.end());
    return out;
}

inline std::string error_detail(const std::string& context) {
    const unsigned long code = ERR_get_error();
    if (code == 0) return context;
    char message[256]{};
    ERR_error_string_n(code, message, sizeof(message));
    return context + ": " + message;
}

inline bool add_one(PKCS7_SIGNER_INFO* signer_info,
                    const CustomCMSAttribute& attribute,
                    bool signed_attribute,
                    std::string* diagnostic = nullptr) {
    auto fail = [&](const std::string& message) {
        if (diagnostic) *diagnostic = message;
        return false;
    };
    if (!signer_info) return fail("CMS SignerInfo is unavailable");
    if (attribute.oid.empty() || attribute.value_der.empty())
        return fail("custom CMS attribute requires a numeric OID and one DER value");
    if (attribute.value_der.size() > 4U * 1024U * 1024U)
        return fail("custom CMS attribute value exceeds 4 MiB");

    const auto value_check = der::validate(attribute.value_der, der::Limits{4U * 1024U * 1024U, 20000U, 48U});
    if (!value_check.ok) return fail("custom CMS attribute value is not canonical DER: " + value_check.error);

    ASN1_OBJECT* oid_object = OBJ_txt2obj(attribute.oid.c_str(), 1);
    if (!oid_object) return fail("invalid numeric CMS attribute OID: " + attribute.oid);
    std::array<char, 512> canonical{};
    const int canonical_length = OBJ_obj2txt(canonical.data(), static_cast<int>(canonical.size()), oid_object, 1);
    if (canonical_length <= 0 || static_cast<size_t>(canonical_length) >= canonical.size()) {
        ASN1_OBJECT_free(oid_object);
        return fail("CMS attribute OID cannot be canonicalized");
    }
    const std::string oid(canonical.data(), static_cast<size_t>(canonical_length));
    const int oid_nid = OBJ_obj2nid(oid_object);
    if (signed_attribute && (oid_nid == NID_pkcs9_contentType || oid_nid == NID_pkcs9_messageDigest || oid_nid == NID_pkcs9_signingTime)) {
        ASN1_OBJECT_free(oid_object);
        return fail("custom signed attributes cannot replace CMS contentType, messageDigest, or the managed signingTime attribute");
    }
    if (!signed_attribute) {
        const int timestamp_nid = OBJ_txt2nid("1.2.840.113549.1.9.16.2.14");
        if ((timestamp_nid != NID_undef && oid_nid == timestamp_nid) || oid_nid == NID_pkcs9_countersignature) {
            ASN1_OBJECT_free(oid_object);
            return fail("custom unsigned attributes cannot replace the managed RFC 3161 timestamp or countersignature attribute");
        }
    }

    STACK_OF(X509_ATTRIBUTE)*& attributes = signed_attribute ? signer_info->auth_attr : signer_info->unauth_attr;
    if (!attributes) {
        attributes = sk_X509_ATTRIBUTE_new_null();
        if (!attributes) { ASN1_OBJECT_free(oid_object); return fail("cannot allocate CMS attribute set"); }
    }
    for (int i = 0; i < sk_X509_ATTRIBUTE_num(attributes); ++i) {
        X509_ATTRIBUTE* existing = sk_X509_ATTRIBUTE_value(attributes, i);
        const ASN1_OBJECT* existing_oid = existing ? X509_ATTRIBUTE_get0_object(existing) : nullptr;
        if (existing_oid && OBJ_cmp(existing_oid, oid_object) == 0) {
            ASN1_OBJECT_free(oid_object);
            return fail("duplicate CMS attribute OID in the same attribute set: " + oid);
        }
    }

    unsigned char* oid_der_raw = nullptr;
    const int oid_der_length = i2d_ASN1_OBJECT(oid_object, &oid_der_raw);
    ASN1_OBJECT_free(oid_object);
    if (oid_der_length <= 0 || !oid_der_raw) return fail("cannot DER-encode CMS attribute OID");
    std::vector<uint8_t> oid_der(oid_der_raw, oid_der_raw + oid_der_length);
    OPENSSL_free(oid_der_raw);

    // Attribute ::= SEQUENCE { attrType OBJECT IDENTIFIER, attrValues SET OF AttributeValue }
    const auto values_set = wrap_der(0x31U, attribute.value_der);
    std::vector<uint8_t> sequence_content;
    sequence_content.reserve(oid_der.size() + values_set.size());
    sequence_content.insert(sequence_content.end(), oid_der.begin(), oid_der.end());
    sequence_content.insert(sequence_content.end(), values_set.begin(), values_set.end());
    const auto attribute_der = wrap_der(0x30U, sequence_content);
    const auto attribute_check = der::validate(attribute_der, der::Limits{4U * 1024U * 1024U, 20000U, 48U});
    if (!attribute_check.ok) return fail("constructed CMS Attribute is not canonical DER: " + attribute_check.error);

    const unsigned char* cursor = attribute_der.data();
    X509_ATTRIBUTE* parsed = d2i_X509_ATTRIBUTE(nullptr, &cursor, static_cast<long>(attribute_der.size()));
    if (!parsed || cursor != attribute_der.data() + attribute_der.size()) {
        X509_ATTRIBUTE_free(parsed);
        return fail(error_detail("OpenSSL rejected constructed CMS Attribute"));
    }
    if (X509_ATTRIBUTE_count(parsed) != 1) {
        X509_ATTRIBUTE_free(parsed);
        return fail("custom CMS attribute must contain exactly one value");
    }
    if (sk_X509_ATTRIBUTE_push(attributes, parsed) <= 0) {
        X509_ATTRIBUTE_free(parsed);
        return fail("cannot append custom CMS attribute");
    }
    return true;
}

inline bool add_many(PKCS7_SIGNER_INFO* signer_info,
                     const std::vector<CustomCMSAttribute>& attributes,
                     bool signed_attribute,
                     std::string* diagnostic = nullptr) {
    if (!signer_info) {
        if (diagnostic) *diagnostic = "CMS SignerInfo is unavailable";
        return false;
    }
    STACK_OF(X509_ATTRIBUTE)*& stack = signed_attribute ? signer_info->auth_attr : signer_info->unauth_attr;
    const bool stack_existed = stack != nullptr;
    const int original_count = stack ? sk_X509_ATTRIBUTE_num(stack) : 0;
    for (const auto& attribute : attributes) {
        if (!add_one(signer_info, attribute, signed_attribute, diagnostic)) {
            // Treat a batch as one operation: do not leave a partly-mutated
            // SignerInfo when a later OID/value fails validation.
            while (stack && sk_X509_ATTRIBUTE_num(stack) > original_count) {
                X509_ATTRIBUTE_free(sk_X509_ATTRIBUTE_pop(stack));
            }
            if (!stack_existed && stack && sk_X509_ATTRIBUTE_num(stack) == 0) {
                sk_X509_ATTRIBUTE_free(stack);
                stack = nullptr;
            }
            return false;
        }
    }
    return true;
}

} // namespace ldid::crypto::cms_attributes

#endif
