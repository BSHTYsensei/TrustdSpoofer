#define _DARWIN_C_SOURCE
#include "ldid.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <cctype>
#include <chrono>
#include <climits>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <dirent.h>
#include <fcntl.h>
#include <fstream>
#include <future>
#include <getopt.h>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string.h>
#include <sys/stat.h>
#include <thread>
#include <unistd.h>
#include <unordered_set>
#include <vector>
#include <archive.h>
#include <archive_entry.h>
#include <curl/curl.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/objects.h>
#include <openssl/pkcs12.h>
#include <openssl/pkcs7.h>
#include <openssl/rand.h>
#include <openssl/ts.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/x509_vfy.h>
#include <plist/plist.h>
#if defined(__APPLE__)
#include <mach-o/loader.h>
#include <mach-o/fat.h>
#endif
#if defined(__APPLE__)
#include <TargetConditionals.h>
#if TARGET_OS_OSX
#include <Security/Security.h>
#include <CoreFoundation/CoreFoundation.h>
#endif
#endif

namespace ldid {
namespace {

inline uint32_t swap32(uint32_t v) {
    return (v >> 24) | ((v >> 8) & 0x0000FF00) | ((v << 8) & 0x00FF0000) | (v << 24);
}

inline uint64_t align_up64(uint64_t value, uint64_t alignment) {
    if (alignment == 0) return value;
    return ((value + alignment - 1) / alignment) * alignment;
}

inline uint32_t load_le32(const uint8_t* p) {
    uint32_t v;
    std::memcpy(&v, p, sizeof(v));
    return v;
}

inline uint64_t load_le64(const uint8_t* p) {
    uint64_t v;
    std::memcpy(&v, p, sizeof(v));
    return v;
}

inline uint32_t load_be32(const uint8_t* p) {
    return (static_cast<uint32_t>(p[0]) << 24) |
           (static_cast<uint32_t>(p[1]) << 16) |
           (static_cast<uint32_t>(p[2]) << 8) |
           static_cast<uint32_t>(p[3]);
}

inline uint64_t load_be64(const uint8_t* p) {
    return (static_cast<uint64_t>(load_be32(p)) << 32) |
           static_cast<uint64_t>(load_be32(p + 4));
}

inline uint32_t read_u32_file(const uint8_t* p, bool big) {
    return big ? load_be32(p) : load_le32(p);
}

inline uint64_t read_u64_file(const uint8_t* p, bool big) {
    return big ? load_be64(p) : load_le64(p);
}

inline void write_u32_file(uint8_t* p, uint32_t v, bool big) {
    if (big) {
        p[0] = static_cast<uint8_t>(v >> 24);
        p[1] = static_cast<uint8_t>(v >> 16);
        p[2] = static_cast<uint8_t>(v >> 8);
        p[3] = static_cast<uint8_t>(v);
    } else {
        std::memcpy(p, &v, sizeof(v));
    }
}

inline void write_u64_file(uint8_t* p, uint64_t v, bool big) {
    if (big) {
        p[0] = static_cast<uint8_t>(v >> 56);
        p[1] = static_cast<uint8_t>(v >> 48);
        p[2] = static_cast<uint8_t>(v >> 40);
        p[3] = static_cast<uint8_t>(v >> 32);
        p[4] = static_cast<uint8_t>(v >> 24);
        p[5] = static_cast<uint8_t>(v >> 16);
        p[6] = static_cast<uint8_t>(v >> 8);
        p[7] = static_cast<uint8_t>(v);
    } else {
        std::memcpy(p, &v, sizeof(v));
    }
}

inline void append_be32(std::vector<uint8_t>& out, uint32_t v) {
    out.push_back(static_cast<uint8_t>(v >> 24));
    out.push_back(static_cast<uint8_t>(v >> 16));
    out.push_back(static_cast<uint8_t>(v >> 8));
    out.push_back(static_cast<uint8_t>(v));
}

[[maybe_unused]] inline void append_be64(std::vector<uint8_t>& out, uint64_t v) {
    append_be32(out, static_cast<uint32_t>(v >> 32));
    append_be32(out, static_cast<uint32_t>(v & 0xFFFFFFFF));
}

inline std::vector<uint8_t> der_length_bytes(size_t length) {
    std::vector<uint8_t> out;
    if (length < 0x80) {
        out.push_back(static_cast<uint8_t>(length));
        return out;
    }
    std::vector<uint8_t> bytes;
    while (length != 0) {
        bytes.push_back(static_cast<uint8_t>(length & 0xFF));
        length >>= 8;
    }
    out.push_back(static_cast<uint8_t>(0x80 | bytes.size()));
    for (auto it = bytes.rbegin(); it != bytes.rend(); ++it) {
        out.push_back(*it);
    }
    return out;
}

inline std::vector<uint8_t> der_wrap(uint8_t tag, const std::vector<uint8_t>& body) {
    std::vector<uint8_t> out;
    out.push_back(tag);
    auto length = der_length_bytes(body.size());
    out.insert(out.end(), length.begin(), length.end());
    out.insert(out.end(), body.begin(), body.end());
    return out;
}

inline std::vector<uint8_t> der_bool(bool value) {
    return der_wrap(0x01, {static_cast<uint8_t>(value ? 0xFF : 0x00)});
}

inline std::vector<uint8_t> der_utf8(const std::string& value) {
    return der_wrap(0x0C, std::vector<uint8_t>(value.begin(), value.end()));
}

inline std::vector<uint8_t> der_oct(const std::vector<uint8_t>& value) {
    return der_wrap(0x04, value);
}

inline std::vector<uint8_t> der_int(uint64_t value) {
    std::vector<uint8_t> bytes;
    if (value == 0) {
        bytes.push_back(0);
    } else {
        while (value != 0) {
            bytes.push_back(static_cast<uint8_t>(value & 0xFF));
            value >>= 8;
        }
        if (bytes.back() & 0x80) {
            bytes.push_back(0);
        }
        std::reverse(bytes.begin(), bytes.end());
    }
    return der_wrap(0x02, bytes);
}

inline std::vector<uint8_t> der_null() {
    return der_wrap(0x05, {});
}

inline std::vector<uint8_t> der_sequence(const std::vector<std::vector<uint8_t>>& items) {
    std::vector<uint8_t> body;
    for (auto& item : items) {
        body.insert(body.end(), item.begin(), item.end());
    }
    return der_wrap(0x30, body);
}

struct ASN1Node {
    uint8_t tag = 0;
    bool constructed = false;
    std::vector<uint8_t> content;
    std::vector<ASN1Node> children;
};

inline bool asn1_parse_node(const std::vector<uint8_t>& data, size_t& pos, ASN1Node& out) {
    if (pos >= data.size()) return false;
    out.tag = data[pos++];
    out.constructed = (out.tag & 0x20) != 0;
    if (pos >= data.size()) return false;
    uint8_t first = data[pos++];
    size_t length = 0;
    if (first < 0x80) {
        length = first;
    } else {
        size_t count = first & 0x7F;
        if (count == 0 || count > sizeof(size_t) || pos + count > data.size()) return false;
        for (size_t i = 0; i < count; ++i) {
            length = (length << 8) | data[pos++];
        }
    }
    if (pos + length > data.size()) return false;
    out.content.assign(data.begin() + pos, data.begin() + pos + length);
    if (out.constructed) {
        size_t child_pos = 0;
        while (child_pos < out.content.size()) {
            ASN1Node child;
            if (!asn1_parse_node(out.content, child_pos, child)) return false;
            out.children.push_back(child);
        }
    }
    pos += length;
    return true;
}

inline std::string plist_string_value(plist_t node) {
    if (!node) return {};
    char* raw = nullptr;
    plist_get_string_val(node, &raw);
    if (!raw) return {};
    std::string value = raw;
    free(raw);
    return value;
}

inline std::string plist_key_value(plist_t node) {
    if (!node) return {};
    char* raw = nullptr;
    plist_get_key_val(node, &raw);
    if (!raw) return {};
    std::string value = raw;
    free(raw);
    return value;
}

inline std::vector<uint8_t> plist_xml_bytes(plist_t node) {
    if (!node) return {};
    char* xml = nullptr;
    uint32_t length = 0;
    plist_to_xml(node, &xml, &length);
    if (!xml) return {};
    std::vector<uint8_t> out(xml, xml + length);
    free(xml);
    return out;
}

inline plist_t plist_from_xml_bytes(const std::vector<uint8_t>& xml) {
    if (xml.empty() || xml.size() > std::numeric_limits<uint32_t>::max()) return nullptr;
    plist_t plist = nullptr;
    const char* data = reinterpret_cast<const char*>(xml.data());
    const uint32_t size = static_cast<uint32_t>(xml.size());
    if (xml.size() >= 8 && std::memcmp(data, "bplist00", 8) == 0) {
        plist_from_bin(data, size, &plist);
    } else {
        plist_from_xml(data, size, &plist);
    }
    return plist;
}

inline bool plist_dict_bool(plist_t dict, const char* key) {
    if (!dict) return false;
    plist_t item = plist_dict_get_item(dict, key);
    if (!item) return false;
    uint8_t value = 0;
    plist_get_bool_val(item, &value);
    return value != 0;
}

std::vector<uint8_t> der_encode_plist_node(plist_t node);

inline std::vector<uint8_t> der_encode_plist_dict(plist_t dict) {
    std::vector<std::pair<std::string, std::vector<uint8_t>>> entries;
    plist_dict_iter it = nullptr;
    plist_dict_new_iter(dict, &it);
    if (!it) return der_sequence({});
    for (;;) {
        char* key = nullptr;
        plist_t value = nullptr;
        plist_dict_next_item(dict, it, &key, &value);
        if (!key || !value) {
            free(key);
            break;
        }
        entries.emplace_back(std::string(key), der_encode_plist_node(value));
        free(key);
    }
    std::sort(entries.begin(), entries.end(), [](const auto& a, const auto& b) {
        return a.first < b.first;
    });
    std::vector<uint8_t> body;
    for (auto& entry : entries) {
        auto encoded_key = der_utf8(entry.first);
        body.insert(body.end(), encoded_key.begin(), encoded_key.end());
        body.insert(body.end(), entry.second.begin(), entry.second.end());
    }
    return der_wrap(0x31, body);
}

inline std::vector<uint8_t> der_encode_plist_array(plist_t array) {
    std::vector<uint8_t> body;
    uint32_t size = plist_array_get_size(array);
    for (uint32_t i = 0; i < size; ++i) {
        plist_t item = plist_array_get_item(array, i);
        auto encoded = der_encode_plist_node(item);
        body.insert(body.end(), encoded.begin(), encoded.end());
    }
    return der_wrap(0x30, body);
}

inline std::vector<uint8_t> der_encode_plist_node(plist_t node) {
    if (!node) return der_null();
    switch (plist_get_node_type(node)) {
        case PLIST_BOOLEAN: {
            uint8_t value = 0;
            plist_get_bool_val(node, &value);
            return der_bool(value != 0);
        }
        case PLIST_UINT: {
            uint64_t value = 0;
            plist_get_uint_val(node, &value);
            return der_int(value);
        }
        case PLIST_REAL:
            // Apple's DER entitlement representation does not define a safe
            // string-coercion for plist real values. Never silently change a
            // numeric entitlement into a UTF8String: reject it explicitly.
            throw std::invalid_argument("DER entitlements do not support PLIST_REAL values; use an integer or string entitlement");
        case PLIST_STRING:
            return der_utf8(plist_string_value(node));
        case PLIST_KEY:
            return der_utf8(plist_key_value(node));
        case PLIST_ARRAY:
            return der_encode_plist_array(node);
        case PLIST_DICT:
            return der_encode_plist_dict(node);
        case PLIST_DATA: {
            char* buffer = nullptr;
            uint64_t length = 0;
            plist_get_data_val(node, &buffer, &length);
            std::vector<uint8_t> value;
            if (buffer) {
                value.assign(buffer, buffer + length);
                free(buffer);
            }
            return der_oct(value);
        }
        case PLIST_DATE: {
            int64_t unix_seconds = 0;
            plist_get_unix_date_val(node, &unix_seconds);
            constexpr int64_t mac_epoch = 978307200;
            if (unix_seconds > (std::numeric_limits<int64_t>::max() / 1000000) ||
                unix_seconds < (std::numeric_limits<int64_t>::min() / 1000000)) {
                return der_null();
            }
            const int64_t value = (unix_seconds - mac_epoch) * 1000000;
            return der_int(static_cast<uint64_t>(value));
        }
        case PLIST_UID: {
            uint64_t value = 0;
            plist_get_uid_val(node, &value);
            return der_int(value);
        }
        default:
            return der_null();
    }
}

inline std::string make_temp_dir() {
    static std::mt19937_64 rng([] {
        std::random_device rd;
        const auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        return static_cast<uint64_t>(rd()) ^ (static_cast<uint64_t>(now) << 1);
    }());
    std::error_code temp_ec;
    const auto temp_root = std::filesystem::temp_directory_path(temp_ec);
    if (temp_ec) throw std::runtime_error("cannot resolve temporary directory: " + temp_ec.message());
    for (unsigned attempt = 0; attempt < 128; ++attempt) {
        std::ostringstream os;
        os << "ldid-" << std::hex << rng();
        auto path = temp_root / os.str();
        std::error_code ec;
        if (std::filesystem::create_directory(path, ec) && !ec) return path.string();
        if (ec && ec != std::errc::file_exists && ec != std::errc::permission_denied)
            throw std::runtime_error("cannot create temporary directory '" + path.string() + "': " + ec.message());
        if (ec == std::errc::permission_denied)
            throw std::runtime_error("permission denied creating temporary directory under '" + temp_root.string() + "'");
    }
    throw std::runtime_error("unable to allocate a unique temporary directory after 128 attempts");
}

inline std::filesystem::path make_unique_temp_path(const std::filesystem::path& target, const char* suffix) {
    static std::mt19937_64 rng([] {
        std::random_device rd;
        const auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        return static_cast<uint64_t>(rd()) ^ (static_cast<uint64_t>(now) << 1);
    }());
    const auto parent = target.parent_path().empty() ? std::filesystem::path(".") : target.parent_path();
    const auto stem = target.filename().string();
    for (;;) {
        std::ostringstream os;
        os << stem << suffix << '-' << std::hex << rng();
        auto candidate = parent / os.str();
        std::error_code ec;
        if (!std::filesystem::exists(candidate, ec) && !ec) return candidate;
    }
}


inline std::string read_c_string(const std::vector<uint8_t>& data, size_t offset) {
    if (offset >= data.size()) return {};
    size_t end = offset;
    while (end < data.size() && data[end] != 0) ++end;
    return std::string(reinterpret_cast<const char*>(data.data() + offset), end - offset);
}

inline std::string hex_encode(const std::vector<uint8_t>& data) {
    static const char* table = "0123456789abcdef";
    std::string out;
    out.reserve(data.size() * 2);
    for (uint8_t byte : data) {
        out.push_back(table[byte >> 4]);
        out.push_back(table[byte & 0x0F]);
    }
    return out;
}

inline std::vector<uint8_t> hex_decode(const std::string& hex) {
    auto value_of = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    std::vector<uint8_t> out;
    if (hex.size() % 2 != 0) return out;
    out.reserve(hex.size() / 2);
    for (size_t i = 0; i < hex.size(); i += 2) {
        int high = value_of(hex[i]);
        int low = value_of(hex[i + 1]);
        if (high < 0 || low < 0) return {};
        out.push_back(static_cast<uint8_t>((high << 4) | low));
    }
    return out;
}

struct BioPtr {
    BIO* p;
    explicit BioPtr(BIO* ptr) : p(ptr) {}
    BioPtr(const BioPtr&) = delete;
    BioPtr& operator=(const BioPtr&) = delete;
    BioPtr(BioPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    BioPtr& operator=(BioPtr&& other) noexcept { if (this != &other) { if (p) BIO_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~BioPtr() { if (p) BIO_free(p); }
    BIO* get() const { return p; }
};

struct PkeyPtr {
    EVP_PKEY* p;
    explicit PkeyPtr(EVP_PKEY* ptr) : p(ptr) {}
    PkeyPtr(const PkeyPtr&) = delete;
    PkeyPtr& operator=(const PkeyPtr&) = delete;
    PkeyPtr(PkeyPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    PkeyPtr& operator=(PkeyPtr&& other) noexcept { if (this != &other) { if (p) EVP_PKEY_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~PkeyPtr() { if (p) EVP_PKEY_free(p); }
    EVP_PKEY* get() const { return p; }
};

struct X509Ptr {
    X509* p;
    explicit X509Ptr(X509* ptr) : p(ptr) {}
    X509Ptr(const X509Ptr&) = delete;
    X509Ptr& operator=(const X509Ptr&) = delete;
    X509Ptr(X509Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    X509Ptr& operator=(X509Ptr&& other) noexcept { if (this != &other) { if (p) X509_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~X509Ptr() { if (p) X509_free(p); }
    X509* get() const { return p; }
};

struct Pkcs7Ptr {
    PKCS7* p;
    explicit Pkcs7Ptr(PKCS7* ptr) : p(ptr) {}
    Pkcs7Ptr(const Pkcs7Ptr&) = delete;
    Pkcs7Ptr& operator=(const Pkcs7Ptr&) = delete;
    Pkcs7Ptr(Pkcs7Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    Pkcs7Ptr& operator=(Pkcs7Ptr&& other) noexcept { if (this != &other) { if (p) PKCS7_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~Pkcs7Ptr() { if (p) PKCS7_free(p); }
    PKCS7* get() const { return p; }
};

struct P12Ptr {
    PKCS12* p;
    explicit P12Ptr(PKCS12* ptr) : p(ptr) {}
    P12Ptr(const P12Ptr&) = delete;
    P12Ptr& operator=(const P12Ptr&) = delete;
    P12Ptr(P12Ptr&& other) noexcept : p(other.p) { other.p = nullptr; }
    P12Ptr& operator=(P12Ptr&& other) noexcept { if (this != &other) { if (p) PKCS12_free(p); p = other.p; other.p = nullptr; } return *this; }
    ~P12Ptr() { if (p) PKCS12_free(p); }
    PKCS12* get() const { return p; }
};

struct StackPtr {
    STACK_OF(X509)* p;
    explicit StackPtr(STACK_OF(X509)* ptr) : p(ptr) {}
    StackPtr(const StackPtr&) = delete;
    StackPtr& operator=(const StackPtr&) = delete;
    StackPtr(StackPtr&& other) noexcept : p(other.p) { other.p = nullptr; }
    StackPtr& operator=(StackPtr&& other) noexcept { if (this != &other) { if (p) sk_X509_pop_free(p, X509_free); p = other.p; other.p = nullptr; } return *this; }
    ~StackPtr() { if (p) sk_X509_pop_free(p, X509_free); }
    STACK_OF(X509)* get() const { return p; }
};

}

namespace macho {

constexpr uint32_t kMH_MAGIC = 0xfeedface;
constexpr uint32_t kMH_CIGAM = 0xcefaedfe;
constexpr uint32_t kMH_MAGIC_64 = 0xfeedfacf;
constexpr uint32_t kMH_CIGAM_64 = 0xcffaedfe;
constexpr uint32_t kFAT_MAGIC = 0xcafebabe;
constexpr uint32_t kFAT_CIGAM = 0xbebafeca;
constexpr uint32_t kFAT_MAGIC_64 = 0xcafebabf;
constexpr uint32_t kFAT_CIGAM_64 = 0xbfbafeca;
constexpr uint32_t kLC_SEGMENT = 0x1;
constexpr uint32_t kLC_SEGMENT_64 = 0x19;
constexpr uint32_t kLC_CODE_SIGNATURE = 0x1d;
constexpr uint32_t SUPERBLOB_MAGIC = 0xfade0cc0;
constexpr uint32_t CODEDIRECTORY_MAGIC = 0xfade0c02;
constexpr uint32_t REQUIREMENTS_MAGIC = 0xfade0c01;
constexpr uint32_t ENTITLEMENTS_MAGIC = 0xfade7171;
constexpr uint32_t DER_ENTITLEMENTS_MAGIC = 0xfade7172;
constexpr uint32_t BLOBWRAPPER_MAGIC = 0xfade0b01;
constexpr uint32_t SLOT_CODEDIRECTORY = 0;
constexpr uint32_t SLOT_REQUIREMENTS = 2;
constexpr uint32_t SLOT_ENTITLEMENTS = 5;
constexpr uint32_t SLOT_DER_ENTITLEMENTS = 7;
constexpr uint32_t SLOT_CMS_SIGNATURE = 0x10000;

struct MachHeaderFields {
    bool valid = false;
    uint32_t magic = 0;
    CPUType cputype = CPUType::ANY;
    uint32_t cpusubtype = 0;
    uint32_t filetype = 0;
    uint32_t ncmds = 0;
    uint32_t sizeofcmds = 0;
    uint32_t flags = 0;
    uint32_t reserved = 0;
    bool is_64 = false;
    bool big = false;
    size_t header_size = 0;
};

struct LoadCommandRef {
    uint32_t cmd = 0;
    uint32_t cmdsize = 0;
    size_t offset = 0;
};

struct MachoAnalysis {
    bool valid = false;
    bool is_fat = false;
    bool is_64 = false;
    bool big = false;
    CPUType cpu_type = CPUType::ANY;
    uint32_t cpu_subtype = 0;
    size_t base = 0;
    size_t load_commands_offset = 0;
    size_t header_end = 0;
    uint32_t ncmds = 0;
    uint32_t sizeofcmds = 0;
    size_t code_signature_offset = 0;
    size_t code_signature_size = 0;
    size_t linkedit_fileoff = 0;
    size_t linkedit_filesize = 0;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint64_t exec_seg_flags = 0;
    bool main_executable = false;
    uint32_t sdk_version = 0;
    uint32_t min_os_version = 0;
};

inline bool is_thin_magic(uint32_t magic) {
    return magic == kMH_MAGIC || magic == kMH_CIGAM || magic == kMH_MAGIC_64 || magic == kMH_CIGAM_64;
}

inline bool is_fat_magic(uint32_t magic) {
    return magic == kFAT_MAGIC || magic == kFAT_CIGAM || magic == kFAT_MAGIC_64 || magic == kFAT_CIGAM_64;
}

inline MachHeaderFields parse_header(const std::vector<uint8_t>& data, size_t offset = 0) {
    MachHeaderFields fields;
    if (offset + 4 > data.size()) return fields;
    uint32_t magic = load_le32(data.data() + offset);
    if (magic == kMH_MAGIC || magic == kMH_MAGIC_64) {
        fields.big = false;
        fields.magic = magic;
    } else if (magic == kMH_CIGAM || magic == kMH_CIGAM_64) {
        fields.big = true;
        fields.magic = swap32(magic);
    } else {
        return fields;
    }
    fields.is_64 = fields.magic == kMH_MAGIC_64;
    fields.header_size = fields.is_64 ? 32 : 28;
    if (offset + fields.header_size > data.size()) return fields;
    const uint8_t* p = data.data() + offset;
    fields.cputype = static_cast<CPUType>(read_u32_file(p + 4, fields.big));
    fields.cpusubtype = read_u32_file(p + 8, fields.big);
    fields.filetype = read_u32_file(p + 12, fields.big);
    fields.ncmds = read_u32_file(p + 16, fields.big);
    fields.sizeofcmds = read_u32_file(p + 20, fields.big);
    fields.flags = read_u32_file(p + 24, fields.big);
    if (fields.is_64) {
        fields.reserved = read_u32_file(p + 28, fields.big);
    }
    fields.valid = true;
    return fields;
}

inline std::vector<LoadCommandRef> enumerate_load_commands(const std::vector<uint8_t>& data, const MachHeaderFields& header, size_t base = 0) {
    std::vector<LoadCommandRef> commands;
    if (!header.valid) return commands;
    size_t pos = base + header.header_size;
    for (uint32_t i = 0; i < header.ncmds; ++i) {
        if (pos + 8 > data.size()) break;
        uint32_t cmd = read_u32_file(data.data() + pos, header.big);
        uint32_t cmdsize = read_u32_file(data.data() + pos + 4, header.big);
        if (cmdsize < 8 || pos + cmdsize > data.size()) break;
        commands.push_back({cmd, cmdsize, pos});
        pos += cmdsize;
    }
    return commands;
}

inline MachoAnalysis analyze_thin(const std::vector<uint8_t>& data, size_t base = 0) {
    MachoAnalysis analysis;
    auto header = parse_header(data, base);
    if (!header.valid) return analysis;
    analysis.valid = true;
    analysis.is_fat = false;
    analysis.is_64 = header.is_64;
    analysis.big = header.big;
    analysis.cpu_type = header.cputype;
    analysis.cpu_subtype = header.cpusubtype;
    analysis.base = base;
    analysis.load_commands_offset = base + header.header_size;
    analysis.header_end = analysis.load_commands_offset + header.sizeofcmds;
    analysis.ncmds = header.ncmds;
    analysis.sizeofcmds = header.sizeofcmds;
    analysis.main_executable = header.filetype == 2U;
    bool exec_seg_is_text = false;
    auto commands = enumerate_load_commands(data, header, base);
    for (auto& command : commands) {
        if (command.cmd == 0x32 && command.cmdsize >= 24) {
            analysis.min_os_version = read_u32_file(data.data() + command.offset + 12, header.big);
            analysis.sdk_version = read_u32_file(data.data() + command.offset + 16, header.big);
        }
        if (command.cmd == 0x24 || command.cmd == 0x25 || command.cmd == 0x2F) {
            if (command.cmdsize >= 16) {
                analysis.min_os_version = read_u32_file(data.data() + command.offset + 8, header.big);
                analysis.sdk_version = read_u32_file(data.data() + command.offset + 12, header.big);
            }
        }
        if (command.cmd == kLC_CODE_SIGNATURE && command.cmdsize >= 16) {
            analysis.code_signature_offset = base + read_u32_file(data.data() + command.offset + 8, header.big);
            analysis.code_signature_size = read_u32_file(data.data() + command.offset + 12, header.big);
        }
        if (command.cmd == kLC_SEGMENT && command.cmdsize >= 56) {
            std::string name = read_c_string(data, command.offset + 8);
            uint64_t vmaddr = read_u32_file(data.data() + command.offset + 24, header.big);
            uint64_t vmsize = read_u32_file(data.data() + command.offset + 28, header.big);
            uint32_t fileoff = read_u32_file(data.data() + command.offset + 32, header.big);
            uint32_t filesize = read_u32_file(data.data() + command.offset + 36, header.big);
            uint32_t initprot = read_u32_file(data.data() + command.offset + 48, header.big);
            if (name == "__LINKEDIT") {
                analysis.linkedit_fileoff = base + fileoff;
                analysis.linkedit_filesize = filesize;
            }
            if ((initprot & 0x4U) != 0) {
                const bool prefer_text = name == "__TEXT";
                if (prefer_text || (!exec_seg_is_text && (analysis.exec_seg_limit == 0 || vmaddr < analysis.exec_seg_base))) {
                    analysis.exec_seg_base = vmaddr;
                    analysis.exec_seg_limit = vmaddr + vmsize;
                    exec_seg_is_text = prefer_text;
                }
            }
        }
        if (command.cmd == kLC_SEGMENT_64 && command.cmdsize >= 72) {
            std::string name = read_c_string(data, command.offset + 8);
            uint64_t vmaddr = read_u64_file(data.data() + command.offset + 24, header.big);
            uint64_t vmsize = read_u64_file(data.data() + command.offset + 32, header.big);
            uint64_t fileoff = read_u64_file(data.data() + command.offset + 40, header.big);
            uint64_t filesize = read_u64_file(data.data() + command.offset + 48, header.big);
            uint32_t initprot = read_u32_file(data.data() + command.offset + 60, header.big);
            if (name == "__LINKEDIT") {
                analysis.linkedit_fileoff = base + static_cast<size_t>(fileoff);
                analysis.linkedit_filesize = static_cast<size_t>(filesize);
            }
            if ((initprot & 0x4U) != 0) {
                const bool prefer_text = name == "__TEXT";
                if (prefer_text || (!exec_seg_is_text && (analysis.exec_seg_limit == 0 || vmaddr < analysis.exec_seg_base))) {
                    analysis.exec_seg_base = vmaddr;
                    analysis.exec_seg_limit = vmaddr + vmsize;
                    exec_seg_is_text = prefer_text;
                }
            }
        }
    }
    return analysis;
}

inline bool is_macho_impl(const std::vector<uint8_t>& data) {
    if (data.size() < 4) return false;
    uint32_t le = load_le32(data.data());
    uint32_t be = load_be32(data.data());
    return is_thin_magic(le) || is_fat_magic(be);
}

inline std::vector<Slice> parse_slices_impl(const std::vector<uint8_t>& data) {
    std::vector<Slice> slices;
    if (data.size() < 8) return slices;
    uint32_t magic = load_be32(data.data());
    bool is64 = magic == kFAT_MAGIC_64 || magic == kFAT_CIGAM_64;
    bool cigam = magic == kFAT_CIGAM || magic == kFAT_CIGAM_64;
    if (magic == kFAT_MAGIC || magic == kFAT_CIGAM || magic == kFAT_MAGIC_64 || magic == kFAT_CIGAM_64) {
        auto load32 = [&](size_t offset) { return cigam ? load_le32(data.data() + offset) : load_be32(data.data() + offset); };
        auto load64 = [&](size_t offset) { return cigam ? load_le64(data.data() + offset) : load_be64(data.data() + offset); };
        uint32_t count = load32(4);
        size_t stride = is64 ? 32 : 20;
        if (count > (data.size() - 8) / stride) return slices;
        size_t pos = 8;
        for (uint32_t i = 0; i < count; ++i) {
            Slice slice;
            slice.cpu_type = static_cast<CPUType>(load32(pos));
            slice.cpu_subtype = load32(pos + 4);
            slice.fat64_container = is64;
            slice.fat_cigam_container = cigam;
            if (is64) {
                slice.offset = load64(pos + 8);
                slice.size = load64(pos + 16);
                slice.align = load32(pos + 24);
            } else {
                slice.offset = load32(pos + 8);
                slice.size = load32(pos + 12);
                slice.align = load32(pos + 16);
            }
            if (slice.offset <= data.size() && slice.size <= data.size() - slice.offset) slices.push_back(slice);
            pos += stride;
        }
        return slices;
    }
    auto header = parse_header(data, 0);
    if (!header.valid) return slices;
    Slice slice;
    slice.offset = 0;
    slice.size = data.size();
    slice.cpu_type = header.cputype;
    slice.cpu_subtype = header.cpusubtype;
    slice.align = 0;
    slices.push_back(slice);
    return slices;
}

inline CPUType cpu_type_from_arch(const std::string& arch, uint32_t& subtype, bool& has_subtype) {
    subtype = 0;
    has_subtype = false;
    auto colon = arch.find(':');
    if (colon != std::string::npos) {
        try {
            uint32_t cpu = static_cast<uint32_t>(std::stoul(arch.substr(0, colon)));
            subtype = static_cast<uint32_t>(std::stoul(arch.substr(colon + 1)));
            has_subtype = true;
            return static_cast<CPUType>(cpu);
        } catch (...) {
            return CPUType::ANY;
        }
    }
    if (arch == "arm64" || arch == "arm64e") return CPUType::ARM64;
    if (arch == "arm64_32") return CPUType::ARM64_32;
    if (arch.rfind("arm", 0) == 0) return CPUType::ARM;
    if (arch == "x86_64" || arch == "x86_64h") return CPUType::X86_64;
    if (arch == "i386" || arch == "x86") return CPUType::X86;
    if (arch == "ppc64") return CPUType::POWERPC64;
    if (arch == "ppc") return CPUType::POWERPC;
    return CPUType::ANY;
}

inline std::vector<uint8_t> select_slice_impl(const std::vector<uint8_t>& data, const std::string& arch) {
    if (arch.empty()) return data;
    auto slices = parse_slices_impl(data);
    if (slices.empty()) return {};
    if (slices.size() == 1 && slices[0].offset == 0 && slices[0].size == data.size()) {
        return data;
    }
    uint32_t subtype = 0;
    bool has_subtype = false;
    CPUType wanted = cpu_type_from_arch(arch, subtype, has_subtype);
    for (auto& slice : slices) {
        if (wanted == CPUType::ANY || slice.cpu_type == wanted) {
            if (!has_subtype || slice.cpu_subtype == subtype) {
                if (slice.offset + slice.size <= data.size()) {
                    return std::vector<uint8_t>(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
                }
            }
        }
    }
    throw std::invalid_argument("architecture not found");
}

inline std::vector<uint8_t> rebuild_fat_with_format_impl(const std::vector<std::vector<uint8_t>>& slices, bool use64, bool cigam, const std::vector<Slice>& source_slices = {}) {
    if (slices.empty()) return {};
    struct FatEntry { CPUType cpu = CPUType::ANY; uint32_t subtype = 0; uint64_t offset = 0; uint64_t size = 0; uint32_t align = 0; };
    std::vector<FatEntry> entries(slices.size());
    for (size_t i = 0; i < slices.size(); ++i) {
        auto header = parse_header(slices[i], 0);
        if (!header.valid) throw std::invalid_argument("invalid Mach-O slice");
        entries[i].cpu = header.cputype;
        entries[i].subtype = header.cpusubtype;
        entries[i].align = (source_slices.size() == slices.size())
            ? static_cast<uint32_t>(std::min<uint64_t>(source_slices[i].align, 31))
            : ((entries[i].cpu == CPUType::ARM64 || entries[i].cpu == CPUType::ARM64_32 || entries[i].cpu == CPUType::POWERPC64) ? 14U : 12U);
    }
    auto build = [&](bool fat64) -> std::vector<uint8_t> {
        uint64_t offset = 8ULL + static_cast<uint64_t>(slices.size()) * (fat64 ? 32ULL : 20ULL);
        for (size_t i = 0; i < slices.size(); ++i) {
            entries[i].offset = align_up64(offset, 1ULL << entries[i].align);
            entries[i].size = slices[i].size();
            if (!fat64 && (entries[i].offset > 0xFFFFFFFFULL || entries[i].size > 0xFFFFFFFFULL)) return {};
            offset = entries[i].offset + entries[i].size;
        }
        std::vector<uint8_t> out(static_cast<size_t>(offset), 0);
        auto put32 = [&](size_t pos, uint32_t value) {
            if (cigam) { out[pos]=static_cast<uint8_t>(value); out[pos+1]=static_cast<uint8_t>(value>>8); out[pos+2]=static_cast<uint8_t>(value>>16); out[pos+3]=static_cast<uint8_t>(value>>24); }
            else { out[pos]=static_cast<uint8_t>(value>>24); out[pos+1]=static_cast<uint8_t>(value>>16); out[pos+2]=static_cast<uint8_t>(value>>8); out[pos+3]=static_cast<uint8_t>(value); }
        };
        auto put64 = [&](size_t pos, uint64_t value) {
            if (cigam) { for (size_t j=0;j<8;++j) out[pos+j]=static_cast<uint8_t>(value>>(8*j)); }
            else { out[pos]=static_cast<uint8_t>(value>>56); out[pos+1]=static_cast<uint8_t>(value>>48); out[pos+2]=static_cast<uint8_t>(value>>40); out[pos+3]=static_cast<uint8_t>(value>>32); out[pos+4]=static_cast<uint8_t>(value>>24); out[pos+5]=static_cast<uint8_t>(value>>16); out[pos+6]=static_cast<uint8_t>(value>>8); out[pos+7]=static_cast<uint8_t>(value); }
        };
        uint32_t magic = fat64 ? kFAT_MAGIC_64 : kFAT_MAGIC;
        put32(0, magic);
        put32(4, static_cast<uint32_t>(slices.size()));
        size_t pos = 8;
        for (const auto& entry : entries) {
            put32(pos, static_cast<uint32_t>(entry.cpu));
            put32(pos+4, entry.subtype);
            if (fat64) { put64(pos+8, entry.offset); put64(pos+16, entry.size); put32(pos+24, static_cast<uint32_t>(entry.align)); put32(pos+28, 0); }
            else { put32(pos+8, static_cast<uint32_t>(entry.offset)); put32(pos+12, static_cast<uint32_t>(entry.size)); put32(pos+16, static_cast<uint32_t>(entry.align)); }
            pos += fat64 ? 32 : 20;
        }
        for (size_t i=0;i<slices.size();++i) std::copy(slices[i].begin(), slices[i].end(), out.begin()+static_cast<size_t>(entries[i].offset));
        return out;
    };
    auto out = build(use64);
    if (out.empty()) throw std::length_error("unable to rebuild universal binary without changing fat format");
    return out;
}

inline std::vector<uint8_t> rebuild_fat_impl(const std::vector<std::vector<uint8_t>>& slices) {
    return rebuild_fat_with_format_impl(slices, false, false);
}

inline bool all_zero(const std::vector<uint8_t>& data, size_t offset, size_t length) {
    if (offset + length > data.size()) return false;
    for (size_t i = 0; i < length; ++i) {
        if (data[offset + i] != 0) return false;
    }
    return true;
}

inline void pad_to(std::vector<uint8_t>& data, size_t target) {
    if (data.size() < target) {
        data.insert(data.end(), target - data.size(), 0);
    }
}

inline void update_linkedit_size(std::vector<uint8_t>& data, const MachHeaderFields& header, size_t linkedit_fileoff) {
    if (linkedit_fileoff > data.size()) return;
    uint64_t filesize = static_cast<uint64_t>(data.size() - linkedit_fileoff);
    uint64_t vmsize = align_up64(filesize, 0x1000);
    auto commands = enumerate_load_commands(data, header, 0);
    for (const auto& command : commands) {
        if (command.cmd == kLC_SEGMENT && command.cmdsize >= 56 && read_c_string(data, command.offset + 8) == "__LINKEDIT") {
            write_u32_file(data.data() + command.offset + 36, static_cast<uint32_t>(std::min<uint64_t>(filesize, 0xFFFFFFFFULL)), header.big);
            write_u32_file(data.data() + command.offset + 28, static_cast<uint32_t>(std::min<uint64_t>(vmsize, 0xFFFFFFFFULL)), header.big);
        } else if (command.cmd == kLC_SEGMENT_64 && command.cmdsize >= 72 && read_c_string(data, command.offset + 8) == "__LINKEDIT") {
            write_u64_file(data.data() + command.offset + 48, filesize, header.big);
            write_u64_file(data.data() + command.offset + 32, vmsize, header.big);
        }
    }
}

inline std::vector<uint8_t> strip_signature_thin(const std::vector<uint8_t>& data) {
    auto analysis = analyze_thin(data, 0);
    if (!analysis.valid) return data;
    std::vector<uint8_t> out = data;
    auto header = parse_header(out, 0);
    auto commands = enumerate_load_commands(out, header, 0);
    bool removed = false;
    for (auto& command : commands) {
        if (command.cmd != kLC_CODE_SIGNATURE) continue;
        size_t next = command.offset + command.cmdsize;
        size_t commands_end = analysis.load_commands_offset + analysis.sizeofcmds;
        if (next < commands_end) {
            std::memmove(out.data() + command.offset, out.data() + next, commands_end - next);
        }
        size_t new_commands_end = commands_end - command.cmdsize;
        if (new_commands_end < commands_end) {
            std::fill(out.begin() + new_commands_end, out.begin() + commands_end, 0);
        }
        write_u32_file(out.data() + 16, header.ncmds - 1, header.big);
        write_u32_file(out.data() + 20, header.sizeofcmds - command.cmdsize, header.big);
        removed = true;
        break;
    }
    if (removed && analysis.code_signature_offset != 0 && analysis.code_signature_size != 0) {
        if (analysis.code_signature_offset + analysis.code_signature_size == out.size()) {
            out.resize(analysis.code_signature_offset);
        } else if (analysis.code_signature_offset + analysis.code_signature_size <= out.size()) {
            std::fill(out.begin() + analysis.code_signature_offset,
                      out.begin() + analysis.code_signature_offset + analysis.code_signature_size,
                      0);
        }
    }
    if (removed) update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> strip_signature_impl(const std::vector<uint8_t>& data) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> stripped;
        stripped.reserve(slices.size());
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            stripped.push_back(strip_signature_thin(slice_data));
        }
        const bool use64 = be_magic == kFAT_MAGIC_64 || be_magic == kFAT_CIGAM_64;
        const bool cigam = be_magic == kFAT_CIGAM || be_magic == kFAT_CIGAM_64;
        return rebuild_fat_with_format_impl(stripped, use64, cigam, slices);
    }
    return strip_signature_thin(data);
}

inline std::vector<uint8_t> embed_signature_thin(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    auto analysis = analyze_thin(data, 0);
    if (!analysis.valid) return data;
    std::vector<uint8_t> out = data;
    auto header = parse_header(out, 0);
    auto commands = enumerate_load_commands(out, header, 0);
    const LoadCommandRef* existing = nullptr;
    size_t used_commands = 0;
    size_t max_header = out.size();
    for (auto& command : commands) {
        used_commands += command.cmdsize;
        if (command.cmd == kLC_CODE_SIGNATURE) {
            existing = &command;
        }
        if (command.cmd == kLC_SEGMENT && command.cmdsize >= 40) {
            uint32_t fileoff = read_u32_file(out.data() + command.offset + 32, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = fileoff;
        }
        if (command.cmd == kLC_SEGMENT_64 && command.cmdsize >= 56) {
            uint64_t fileoff = read_u64_file(out.data() + command.offset + 40, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = static_cast<size_t>(fileoff);
        }
    }
    size_t new_offset = 0;
    size_t new_size = signature.size();
    if (existing) {
        size_t old_offset = read_u32_file(out.data() + existing->offset + 8, header.big);
        size_t old_size = read_u32_file(out.data() + existing->offset + 12, header.big);
        if (old_offset + old_size == out.size()) {
            out.resize(old_offset);
            new_offset = align_up64(out.size(), 16);
            macho::pad_to(out, new_offset);
            out.insert(out.end(), signature.begin(), signature.end());
        } else if (old_offset < out.size() && new_size <= old_size) {
            new_offset = old_offset;
            std::copy(signature.begin(), signature.end(), out.begin() + new_offset);
            if (new_size < old_size) {
                std::fill(out.begin() + new_offset + new_size, out.begin() + new_offset + old_size, 0);
            }
        } else {
            new_offset = align_up64(out.size(), 16);
            macho::pad_to(out, new_offset);
            out.insert(out.end(), signature.begin(), signature.end());
        }
        write_u32_file(out.data() + existing->offset + 8, static_cast<uint32_t>(new_offset), header.big);
        write_u32_file(out.data() + existing->offset + 12, static_cast<uint32_t>(new_size), header.big);
        update_linkedit_size(out, header, analysis.linkedit_fileoff);
        return out;
    }
    size_t insert_pos = analysis.load_commands_offset + used_commands;
    if (insert_pos + 16 > max_header || !macho::all_zero(out, insert_pos, 16)) {
        throw std::runtime_error("no room for kLC_CODE_SIGNATURE");
    }
    new_offset = align_up64(out.size(), 16);
    macho::pad_to(out, new_offset);
    out.insert(out.end(), signature.begin(), signature.end());
    write_u32_file(out.data() + insert_pos, kLC_CODE_SIGNATURE, header.big);
    write_u32_file(out.data() + insert_pos + 4, 16, header.big);
    write_u32_file(out.data() + insert_pos + 8, static_cast<uint32_t>(new_offset), header.big);
    write_u32_file(out.data() + insert_pos + 12, static_cast<uint32_t>(new_size), header.big);
    write_u32_file(out.data() + 16, header.ncmds + 1, header.big);
    write_u32_file(out.data() + 20, header.sizeofcmds + 16, header.big);
    update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> embed_signature_impl(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> signed_slices;
        signed_slices.reserve(slices.size());
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            signed_slices.push_back(embed_signature_thin(slice_data, signature));
        }
        const bool use64 = be_magic == kFAT_MAGIC_64 || be_magic == kFAT_CIGAM_64;
        const bool cigam = be_magic == kFAT_CIGAM || be_magic == kFAT_CIGAM_64;
        return rebuild_fat_with_format_impl(signed_slices, use64, cigam, slices);
    }
    return embed_signature_thin(data, signature);
}

inline std::vector<uint8_t> blob_content(const std::vector<uint8_t>& signature, size_t offset) {
    if (offset + 8 > signature.size()) return {};
    uint32_t length = load_be32(signature.data() + offset + 4);
    if (offset + length > signature.size()) return {};
    return std::vector<uint8_t>(signature.begin() + offset + 8, signature.begin() + offset + length);
}

inline std::vector<uint8_t> whole_blob(const std::vector<uint8_t>& signature, size_t offset) {
    if (offset + 8 > signature.size()) return {};
    uint32_t length = load_be32(signature.data() + offset + 4);
    if (offset + length > signature.size()) return {};
    return std::vector<uint8_t>(signature.begin() + offset, signature.begin() + offset + length);
}

inline SignatureInfo get_signature_info_impl(const std::vector<uint8_t>& data) {
    SignatureInfo info;
    std::vector<uint8_t> slice_data = data;
    uint32_t be_magic = data.size() >= 8 ? load_be32(data.data()) : 0;
    if (is_fat_magic(be_magic)) {
        auto slices = parse_slices_impl(data);
        if (slices.empty()) return info;
        auto first = slices.front();
        slice_data.assign(data.begin() + first.offset, data.begin() + first.offset + first.size);
    }
    auto analysis = analyze_thin(slice_data, 0);
    if (!analysis.valid || analysis.code_signature_size == 0) return info;
    if (analysis.code_signature_offset + analysis.code_signature_size > slice_data.size()) return info;
    std::vector<uint8_t> signature(slice_data.begin() + analysis.code_signature_offset,
                                   slice_data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    if (signature.size() < 12 || load_be32(signature.data()) != SUPERBLOB_MAGIC) return info;
    uint32_t count = load_be32(signature.data() + 8);
    size_t pos = 12;
    for (uint32_t i = 0; i < count; ++i) {
        if (pos + 8 > signature.size()) break;
        uint32_t type = load_be32(signature.data() + pos);
        uint32_t offset = load_be32(signature.data() + pos + 4);
        pos += 8;
        if (offset >= signature.size()) continue;
        if (type == SLOT_CODEDIRECTORY && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == CODEDIRECTORY_MAGIC) {
            auto cd = whole_blob(signature, offset);
            if (cd.size() < 44) continue;
            uint32_t version = load_be32(cd.data() + 8);
            uint32_t flags = load_be32(cd.data() + 12);
            uint32_t ident_offset = load_be32(cd.data() + 20);
            uint8_t hash_type = cd[37];
            info.version = version;
            info.flags = flags;
            info.hash_type = hash_type == 1 ? HashType::SHA1 : (hash_type == 2 ? HashType::SHA256 : (hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384));
            info.identifier = read_c_string(cd, ident_offset);
            if (version >= 0x20200 && cd.size() >= 52) {
                uint32_t team_offset = load_be32(cd.data() + 48);
                if (team_offset != 0 && team_offset < cd.size()) {
                    info.team_id = read_c_string(cd, team_offset);
                }
            }
            unsigned char digest[EVP_MAX_MD_SIZE];
            unsigned int digest_length = 0;
            const EVP_MD* md = info.hash_type == HashType::SHA1 ? EVP_sha1() : (info.hash_type == HashType::SHA384 ? EVP_sha384() : EVP_sha256());
            EVP_Digest(cd.data(), cd.size(), digest, &digest_length, md, nullptr);
            size_t cd_hash_length = std::min<size_t>(20, digest_length);
            info.cd_hash.assign(digest, digest + cd_hash_length);
            info.adhoc = (flags & static_cast<uint32_t>(CodeDirectoryFlag::ADHOC)) != 0;
            info.true_sign = false;
        }
        if (type == SLOT_ENTITLEMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == ENTITLEMENTS_MAGIC) {
            auto content = blob_content(signature, offset);
            info.entitlements_xml.assign(content.begin(), content.end());
        }
        if (type == SLOT_DER_ENTITLEMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == DER_ENTITLEMENTS_MAGIC) {
            info.entitlements_der = blob_content(signature, offset);
        }
        if (type == SLOT_REQUIREMENTS && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == 0xfade0c01U) {
            info.requirements_blob = whole_blob(signature, offset);
        }
        if (type == SLOT_CMS_SIGNATURE && offset + 8 <= signature.size() && load_be32(signature.data() + offset) == BLOBWRAPPER_MAGIC) {
            info.cms_signature = blob_content(signature, offset);
            info.true_sign = !info.cms_signature.empty();
        }
    }
    return info;
}

}

}
#include "ldid.hpp"
#include <openssl/pem.h>
#include <openssl/objects.h>
#if defined(__APPLE__)
#include <TargetConditionals.h>
#if TARGET_OS_OSX
#include <Security/Security.h>
#include <CoreFoundation/CoreFoundation.h>
#endif
#endif
#include <openssl/asn1.h>
#include <openssl/obj_mac.h>

namespace ldid {

namespace crypto {
std::vector<uint8_t> hash_impl(HashType type, const std::vector<uint8_t>& data);
}

namespace blob {

constexpr uint32_t SUPERBLOB_MAGIC = 0xfade0cc0;
[[maybe_unused]] constexpr uint32_t REQUIREMENTS_SUPERBLOB_MAGIC = 0xfade0c01;
constexpr uint32_t REQUIREMENT_MAGIC = 0xfade0c00;
constexpr uint32_t CODEDIRECTORY_MAGIC = 0xfade0c02;
constexpr uint32_t ENTITLEMENTS_MAGIC = 0xfade7171;
constexpr uint32_t DER_ENTITLEMENTS_MAGIC = 0xfade7172;

inline void put_be32(std::vector<uint8_t>& out, size_t offset, uint32_t value) {
    out[offset + 0] = static_cast<uint8_t>(value >> 24);
    out[offset + 1] = static_cast<uint8_t>(value >> 16);
    out[offset + 2] = static_cast<uint8_t>(value >> 8);
    out[offset + 3] = static_cast<uint8_t>(value);
}

inline void put_be64(std::vector<uint8_t>& out, size_t offset, uint64_t value) {
    out[offset + 0] = static_cast<uint8_t>(value >> 56);
    out[offset + 1] = static_cast<uint8_t>(value >> 48);
    out[offset + 2] = static_cast<uint8_t>(value >> 40);
    out[offset + 3] = static_cast<uint8_t>(value >> 32);
    out[offset + 4] = static_cast<uint8_t>(value >> 24);
    out[offset + 5] = static_cast<uint8_t>(value >> 16);
    out[offset + 6] = static_cast<uint8_t>(value >> 8);
    out[offset + 7] = static_cast<uint8_t>(value);
}

inline void put_u8(std::vector<uint8_t>& out, size_t offset, uint8_t value) {
    out[offset] = value;
}

inline std::vector<uint8_t> make_blob_impl(uint32_t magic, const std::vector<uint8_t>& data) {
    if (data.size() > static_cast<size_t>(std::numeric_limits<uint32_t>::max()) - 8U) {
        throw std::length_error("code-signing blob too large");
    }
    const size_t total = data.size() + 8U;
    std::vector<uint8_t> out;
    out.reserve(total);
    append_be32(out, magic);
    append_be32(out, static_cast<uint32_t>(total));
    out.insert(out.end(), data.begin(), data.end());
    return out;
}

inline std::vector<uint8_t> build_superblob_impl(const std::map<uint32_t, std::vector<uint8_t>>& blobs) {
    size_t count = blobs.size();
    size_t header_size = 12 + 8 * count;
    size_t total = header_size;
    std::vector<std::pair<uint32_t, size_t>> indexes;
    indexes.reserve(count);
    for (auto& entry : blobs) {
        total = align_up64(total, 4);
        indexes.push_back({entry.first, total});
        total += entry.second.size();
    }
    std::vector<uint8_t> out(total, 0);
    put_be32(out, 0, SUPERBLOB_MAGIC);
    put_be32(out, 4, static_cast<uint32_t>(total));
    put_be32(out, 8, static_cast<uint32_t>(count));
    size_t pos = 12;
    size_t index = 0;
    for (auto& entry : blobs) {
        put_be32(out, pos, entry.first);
        put_be32(out, pos + 4, static_cast<uint32_t>(indexes[index].second));
        pos += 8;
        ++index;
    }
    index = 0;
    for (auto& entry : blobs) {
        size_t offset = indexes[index].second;
        std::copy(entry.second.begin(), entry.second.end(), out.begin() + offset);
        ++index;
    }
    return out;
}

struct CodeScatterRecord {
    uint32_t count = 0;
    uint32_t base = 0;
    uint64_t target_offset = 0;
    uint64_t spare = 0;
};

struct CodeDirectoryInputs {
    std::vector<uint8_t> code;
    std::string identifier;
    std::string team_id;
    HashType hash_type = HashType::SHA256;
    uint32_t flags = 0;
    uint32_t version = 0x20200;
    uint32_t page_size = 4096;
    bool infinite_page_size = false;
    Platform platform = Platform::UNKNOWN;
    std::vector<std::vector<uint8_t>> special_slots;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint64_t exec_seg_flags = 0;
    uint32_t runtime_version = 0;
    std::vector<CodeScatterRecord> scatter;
    std::vector<uint8_t> pre_encrypt_hashes;
    uint8_t linkage_hash_type = 0;
    uint8_t linkage_application_type = 0;
    uint16_t linkage_application_subtype = 0;
    std::vector<uint8_t> linkage_data;
    bool pre_encrypt = false;
};

inline uint8_t page_exponent(uint32_t page_size) {
    uint8_t exponent = 0;
    while (page_size > 1) {
        page_size >>= 1;
        ++exponent;
    }
    return exponent;
}

inline size_t code_directory_header_size(uint32_t version) {
    if (version < 0x20100) return 44;
    if (version < 0x20200) return 48;
    if (version < 0x20300) return 52;
    if (version < 0x20400) return 64;
    if (version < 0x20500) return 88;
    if (version < 0x20600) return 96;
    return 108;
}

inline std::vector<uint8_t> build_code_directory_full(const CodeDirectoryInputs& input) {
    HashType hash_type = input.hash_type == HashType::ANY ? HashType::SHA256 : input.hash_type;
    if (hash_type != HashType::SHA1 && hash_type != HashType::SHA256 && hash_type != HashType::SHA256_TRUNCATED && hash_type != HashType::SHA384)
        throw std::invalid_argument("unsupported CodeDirectory hash type");

    const uint64_t code_limit = input.code.size();
    uint32_t version = std::max<uint32_t>(input.version, 0x20001);
    if (code_limit > 0xFFFFFFFFULL) version = std::max<uint32_t>(version, 0x20300);
    if (!input.team_id.empty()) version = std::max<uint32_t>(version, 0x20200);
    if (input.exec_seg_base != 0 || input.exec_seg_limit != 0 || input.exec_seg_flags != 0) version = std::max<uint32_t>(version, 0x20400);
    if (input.runtime_version != 0 || input.pre_encrypt || !input.pre_encrypt_hashes.empty()) version = std::max<uint32_t>(version, 0x20500);
    if (!input.linkage_data.empty() || input.linkage_hash_type != 0 || input.linkage_application_type != 0 || input.linkage_application_subtype != 0)
        version = std::max<uint32_t>(version, 0x20600);
    if (!input.scatter.empty()) version = std::max<uint32_t>(version, 0x20100);
    if (version > 0x20600) throw std::invalid_argument("unsupported CodeDirectory generation version (maximum implemented: 0x20600)");

    const size_t hash_size = hash_type == HashType::SHA1 || hash_type == HashType::SHA256_TRUNCATED ? 20 :
                             (hash_type == HashType::SHA256 ? 32 : 48);
    const uint8_t hash_type_byte = static_cast<uint8_t>(hash_type);
    const uint32_t page_size = input.page_size;
    if (!input.infinite_page_size && (page_size == 0 || (page_size & (page_size - 1)) != 0 || page_size > (1U << 20)))
        throw std::invalid_argument("CodeDirectory page size must be a power of two no larger than 1 MiB, or explicitly infinite");
    const uint8_t page_exp = input.infinite_page_size ? 0 : page_exponent(page_size);

    uint64_t code_slots64 = code_limit == 0 ? 0 : (input.infinite_page_size ? 1ULL : (code_limit + page_size - 1) / page_size);
    if (!input.scatter.empty()) {
        if (input.infinite_page_size) throw std::invalid_argument("CodeDirectory scatter requires a finite page size");
        uint64_t max_slot = 0;
        bool sentinel = false;
        for (const auto& entry : input.scatter) {
            if (entry.spare != 0) throw std::invalid_argument("CodeDirectory scatter spare field must be zero");
            if (entry.count == 0) { sentinel = true; break; }
            const uint64_t end_slot = static_cast<uint64_t>(entry.base) + entry.count;
            const uint64_t byte_count = static_cast<uint64_t>(entry.count) * page_size;
            if (end_slot > std::numeric_limits<uint32_t>::max() || entry.target_offset > code_limit ||
                byte_count > code_limit - entry.target_offset)
                throw std::invalid_argument("CodeDirectory scatter entry exceeds signed code range");
            max_slot = std::max(max_slot, end_slot);
        }
        if (!sentinel) throw std::invalid_argument("CodeDirectory scatter vector must terminate with a zero-count sentinel");
        code_slots64 = max_slot;
    }
    if (code_slots64 > std::numeric_limits<uint32_t>::max()) throw std::length_error("too many CodeDirectory code slots");
    const uint32_t code_slots = static_cast<uint32_t>(code_slots64);

    uint32_t special_slots = 0;
    for (size_t i = 1; i < input.special_slots.size() && i <= 11; ++i)
        if (!input.special_slots[i].empty()) special_slots = static_cast<uint32_t>(i);

    const size_t header_size = code_directory_header_size(version);
    const size_t identifier_size = input.identifier.size() + 1;
    const size_t team_size = input.team_id.empty() ? 0 : input.team_id.size() + 1;
    const size_t ident_offset = header_size;
    const size_t team_offset = input.team_id.empty() ? 0 : ident_offset + identifier_size;
    size_t scatter_offset = 0;
    size_t scatter_bytes = 0;
    if (!input.scatter.empty()) {
        scatter_offset = header_size + identifier_size + team_size;
        if (input.scatter.size() > std::numeric_limits<size_t>::max() / 24) throw std::length_error("scatter vector is too large");
        scatter_bytes = input.scatter.size() * 24;
    }
    const size_t hashes_start = header_size + identifier_size + team_size + scatter_bytes;
    const size_t hash_offset = hashes_start + static_cast<size_t>(special_slots) * hash_size;
    const uint64_t code_hash_bytes = static_cast<uint64_t>(code_slots64) * hash_size;
    if (!input.pre_encrypt_hashes.empty() && input.pre_encrypt_hashes.size() != code_hash_bytes)
        throw std::invalid_argument("pre-encrypt hash data length must equal nCodeSlots * hashSize");
    const uint64_t pre_encrypt_bytes = input.pre_encrypt_hashes.size();
    const uint64_t pre_encrypt_offset = pre_encrypt_bytes ? hash_offset + code_hash_bytes : 0;
    const uint64_t linkage_offset = input.linkage_data.empty() ? 0 : hash_offset + code_hash_bytes + pre_encrypt_bytes;
    const uint64_t total64 = static_cast<uint64_t>(hashes_start) +
        static_cast<uint64_t>(special_slots) * hash_size + code_hash_bytes + pre_encrypt_bytes + input.linkage_data.size();
    if (total64 > std::numeric_limits<uint32_t>::max()) throw std::length_error("CodeDirectory too large");
    const size_t total = static_cast<size_t>(total64);
    std::vector<uint8_t> out(total, 0);

    put_be32(out, 0, CODEDIRECTORY_MAGIC);
    put_be32(out, 4, static_cast<uint32_t>(total));
    put_be32(out, 8, version);
    put_be32(out, 12, input.flags);
    put_be32(out, 16, static_cast<uint32_t>(hash_offset));
    put_be32(out, 20, static_cast<uint32_t>(ident_offset));
    put_be32(out, 24, special_slots);
    put_be32(out, 28, code_slots);
    put_be32(out, 32, code_limit > 0xFFFFFFFFULL ? 0xFFFFFFFFU : static_cast<uint32_t>(code_limit));
    put_u8(out, 36, static_cast<uint8_t>(hash_size));
    put_u8(out, 37, hash_type_byte);
    put_u8(out, 38, static_cast<uint8_t>(input.platform));
    put_u8(out, 39, page_exp);
    put_be32(out, 40, 0);
    if (version >= 0x20100) put_be32(out, 44, static_cast<uint32_t>(scatter_offset));
    if (version >= 0x20200) put_be32(out, 48, static_cast<uint32_t>(team_offset));
    if (version >= 0x20300) {
        put_be32(out, 52, 0);
        put_be64(out, 56, code_limit);
    }
    if (version >= 0x20400) {
        put_be64(out, 64, input.exec_seg_base);
        put_be64(out, 72, input.exec_seg_limit);
        put_be64(out, 80, input.exec_seg_flags);
    }
    if (version >= 0x20500) {
        put_be32(out, 88, input.runtime_version);
        put_be32(out, 92, static_cast<uint32_t>(pre_encrypt_offset));
    }
    if (version >= 0x20600) {
        put_u8(out, 96, input.linkage_hash_type);
        put_u8(out, 97, input.linkage_application_type);
        out[98] = static_cast<uint8_t>(input.linkage_application_subtype >> 8);
        out[99] = static_cast<uint8_t>(input.linkage_application_subtype);
        put_be32(out, 100, static_cast<uint32_t>(linkage_offset));
        put_be32(out, 104, static_cast<uint32_t>(input.linkage_data.size()));
    }

    std::copy(input.identifier.begin(), input.identifier.end(), out.begin() + static_cast<std::ptrdiff_t>(ident_offset));
    out[ident_offset + input.identifier.size()] = 0;
    if (!input.team_id.empty()) {
        std::copy(input.team_id.begin(), input.team_id.end(), out.begin() + static_cast<std::ptrdiff_t>(team_offset));
        out[team_offset + input.team_id.size()] = 0;
    }
    if (!input.scatter.empty()) {
        size_t pos = scatter_offset;
        for (const auto& entry : input.scatter) {
            put_be32(out, pos, entry.count);
            put_be32(out, pos + 4, entry.base);
            put_be64(out, pos + 8, entry.target_offset);
            put_be64(out, pos + 16, entry.spare);
            pos += 24;
        }
    }

    for (uint32_t slot = 1; slot <= special_slots; ++slot) {
        const size_t position = hashes_start + static_cast<size_t>(special_slots - slot) * hash_size;
        if (slot < input.special_slots.size() && !input.special_slots[slot].empty()) {
            const auto digest = crypto::hash_impl(hash_type, input.special_slots[slot]);
            if (digest.size() != hash_size) throw std::runtime_error("CodeDirectory special slot digest size mismatch");
            std::copy(digest.begin(), digest.end(), out.begin() + static_cast<std::ptrdiff_t>(position));
        }
    }

    auto hash_code_range = [&](uint64_t slot, uint64_t start, uint64_t length) {
        if (slot >= code_slots64 || start > input.code.size() || length > input.code.size() - start)
            throw std::invalid_argument("CodeDirectory scatter page is outside signed image");
        const size_t begin = static_cast<size_t>(start);
        const size_t end = static_cast<size_t>(start + length);
        const auto digest = crypto::hash_impl(hash_type,
            std::vector<uint8_t>(input.code.begin() + static_cast<std::ptrdiff_t>(begin), input.code.begin() + static_cast<std::ptrdiff_t>(end)));
        if (digest.size() != hash_size) throw std::runtime_error("CodeDirectory code digest size mismatch");
        const size_t position = hash_offset + static_cast<size_t>(slot) * hash_size;
        std::copy(digest.begin(), digest.end(), out.begin() + static_cast<std::ptrdiff_t>(position));
    };
    if (input.scatter.empty()) {
        for (uint64_t page = 0; page < code_slots64; ++page) {
            const uint64_t start = input.infinite_page_size ? 0 : page * page_size;
            const uint64_t length = input.infinite_page_size ? code_limit : std::min<uint64_t>(page_size, code_limit - start);
            hash_code_range(page, start, length);
        }
    } else {
        std::set<uint64_t> assigned;
        for (const auto& entry : input.scatter) {
            if (entry.count == 0) break;
            for (uint32_t i = 0; i < entry.count; ++i) {
                const uint64_t slot = static_cast<uint64_t>(entry.base) + i;
                if (!assigned.insert(slot).second) throw std::invalid_argument("overlapping CodeDirectory scatter slot ranges");
                const uint64_t start = entry.target_offset + static_cast<uint64_t>(i) * page_size;
                const uint64_t length = std::min<uint64_t>(page_size, code_limit - start);
                hash_code_range(slot, start, length);
            }
        }
    }

    if (!input.pre_encrypt_hashes.empty()) {
        std::copy(input.pre_encrypt_hashes.begin(), input.pre_encrypt_hashes.end(), out.begin() + static_cast<std::ptrdiff_t>(pre_encrypt_offset));
    }
    if (!input.linkage_data.empty()) {
        std::copy(input.linkage_data.begin(), input.linkage_data.end(), out.begin() + static_cast<std::ptrdiff_t>(linkage_offset));
    }
    return out;
}

inline std::vector<uint8_t> build_code_directory_impl(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags) {
    CodeDirectoryInputs input;
    input.code = code;
    input.identifier = identifier;
    input.team_id = team_id;
    input.hash_type = hash_type;
    input.flags = flags;
    input.version = 0x20100;
    return build_code_directory_full(input);
}

inline std::vector<uint8_t> build_cd_versioned_impl(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version) {
    CodeDirectoryInputs input;
    input.code = code;
    input.identifier = identifier;
    input.team_id = team_id;
    input.hash_type = hash_type;
    input.flags = flags;
    input.version = version;
    return build_code_directory_full(input);
}

inline std::vector<uint8_t> build_entitlements_blob_impl(const std::string& xml) {
    return make_blob_impl(ENTITLEMENTS_MAGIC, std::vector<uint8_t>(xml.begin(), xml.end()));
}

inline std::vector<uint8_t> build_der_entitlements_blob_impl(const std::string& xml) {
    std::vector<uint8_t> xml_bytes(xml.begin(), xml.end());
    plist_t root = plist_from_xml_bytes(xml_bytes);
    if (!root) {
        return make_blob_impl(DER_ENTITLEMENTS_MAGIC, {});
    }
    std::vector<uint8_t> der = der_encode_plist_node(root);
    plist_free(root);
    return make_blob_impl(DER_ENTITLEMENTS_MAGIC, der);
}

inline void append_requirement_string(std::vector<uint8_t>& out, const std::string& value) {
    if (value.size() > std::numeric_limits<uint32_t>::max()) throw std::length_error("requirement string too large");
    append_be32(out, static_cast<uint32_t>(value.size()));
    out.insert(out.end(), value.begin(), value.end());
    while ((out.size() & 3U) != 0) out.push_back(0);
}

inline std::vector<uint8_t> requirement_ident_expression(const std::string& identifier) {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::IDENTIFIER));
    append_requirement_string(out, identifier);
    return out;
}

inline std::vector<uint8_t> requirement_anchor_expression() {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::APPLE_GENERIC_ANCHOR));
    return out;
}

inline std::vector<uint8_t> requirement_team_expression(const std::string& team_id) {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::CERT_FIELD));
    append_be32(out, 0);
    append_requirement_string(out, "subject.OU");
    append_be32(out, 1);
    append_requirement_string(out, team_id);
    return out;
}

inline std::vector<uint8_t> requirement_and_expression(const std::vector<uint8_t>& lhs, const std::vector<uint8_t>& rhs) {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::AND_EXPR));
    out.insert(out.end(), lhs.begin(), lhs.end());
    out.insert(out.end(), rhs.begin(), rhs.end());
    return out;
}

inline std::vector<uint8_t> build_dr_impl(const std::string& identifier, const std::string& team_id) {
    if (identifier.empty()) throw std::invalid_argument("designated requirement identifier is empty");
    std::vector<uint8_t> expression = requirement_ident_expression(identifier);
    if (!team_id.empty()) {
        expression = requirement_and_expression(expression, requirement_anchor_expression());
        expression = requirement_and_expression(expression, requirement_team_expression(team_id));
    }
    return make_blob_impl(REQUIREMENT_MAGIC, [&] {
        std::vector<uint8_t> body;
        append_be32(body, 1);
        body.insert(body.end(), expression.begin(), expression.end());
        return body;
    }());
}

inline std::vector<uint8_t> build_requirements_blob_impl(const std::string& identifier, const std::string& team_id) {
    auto designated = build_dr_impl(identifier, team_id);
    std::vector<uint8_t> out;
    append_be32(out, 0xfade0c01U);
    append_be32(out, 20U + static_cast<uint32_t>(designated.size()));
    append_be32(out, 1);
    append_be32(out, 3);
    append_be32(out, 20);
    out.insert(out.end(), designated.begin(), designated.end());
    return out;
}

inline std::string extract_quoted_value(const std::string& text, const std::string& marker) {
    size_t pos = text.find(marker);
    if (pos == std::string::npos) return {};
    size_t first = text.find('\"', pos + marker.size());
    if (first == std::string::npos) return {};
    size_t second = text.find('\"', first + 1);
    if (second == std::string::npos) return {};
    return text.substr(first + 1, second - first - 1);
}

inline std::vector<uint8_t> requirement_match_expression(uint32_t opcode, uint32_t cert_index, const std::string& field, uint32_t match, const std::string& value) {
    std::vector<uint8_t> out;
    append_be32(out, opcode);
    if (opcode == requirement_opcode_value(RequirementOpcode::CERT_FIELD)) append_be32(out, cert_index);
    append_requirement_string(out, field);
    append_be32(out, match);
    if (match != 0 && match != 14) append_requirement_string(out, value);
    return out;
}

inline std::vector<uint8_t> requirement_cdhash_expression(const std::vector<uint8_t>& hash) {
    if (hash.size() != 20) throw std::invalid_argument("cdhash requirement must contain exactly 20 bytes");
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::CDHASH));
    out.insert(out.end(), hash.begin(), hash.end());
    return out;
}

inline std::vector<uint8_t> requirement_not_expression(const std::vector<uint8_t>& value) {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::NOT_EXPR));
    out.insert(out.end(), value.begin(), value.end());
    return out;
}

inline std::vector<uint8_t> requirement_or_expression(const std::vector<uint8_t>& lhs, const std::vector<uint8_t>& rhs) {
    std::vector<uint8_t> out;
    append_be32(out, requirement_opcode_value(RequirementOpcode::OR_EXPR));
    out.insert(out.end(), lhs.begin(), lhs.end());
    out.insert(out.end(), rhs.begin(), rhs.end());
    return out;
}

inline std::vector<uint8_t> requirement_info_field_expression(const std::string& key, uint32_t match, const std::string& value) {
    return requirement_match_expression(requirement_opcode_value(RequirementOpcode::INFO_KEY_FIELD), 0, key, match, value);
}

inline std::vector<uint8_t> requirement_entitlement_field_expression(const std::string& key, uint32_t match, const std::string& value) {
    return requirement_match_expression(requirement_opcode_value(RequirementOpcode::ENTITLEMENT_FIELD), 0, key, match, value);
}

inline uint32_t requirement_cert_index(const std::string& name) {
    if (name == "leaf") return 0;
    if (name == "root" || name == "anchor") return 0xFFFFFFFFU;
    size_t value = 0;
    try {
        value = std::stoul(name);
    } catch (...) {
        throw std::invalid_argument("invalid certificate index in requirement");
    }
    if (value > std::numeric_limits<uint32_t>::max()) throw std::invalid_argument("certificate index out of range");
    return static_cast<uint32_t>(value);
}

inline std::vector<uint8_t> oid_content_from_dotted(const std::string& dotted) {
    std::vector<uint64_t> arcs;
    size_t start = 0;
    while (start <= dotted.size()) {
        size_t end = dotted.find('.', start);
        std::string part = dotted.substr(start, end == std::string::npos ? std::string::npos : end - start);
        if (part.empty()) throw std::invalid_argument("invalid certificate OID");
        uint64_t n = 0;
        for (char c : part) {
            if (c < '0' || c > '9') throw std::invalid_argument("invalid certificate OID");
            n = n * 10 + static_cast<uint64_t>(c - '0');
            if (n > 0xFFFFFFFFULL) throw std::invalid_argument("certificate OID arc too large");
        }
        arcs.push_back(n);
        if (end == std::string::npos) break;
        start = end + 1;
    }
    if (arcs.size() < 2 || arcs[0] > 2 || (arcs[0] < 2 && arcs[1] > 39)) throw std::invalid_argument("invalid certificate OID");
    std::vector<uint8_t> out;
    auto emit_base128 = [&](uint64_t value) {
        uint8_t bytes[10]; size_t n = 0;
        do { bytes[n++] = static_cast<uint8_t>(value & 0x7f); value >>= 7; } while (value != 0);
        while (n != 0) {
            uint8_t b = bytes[--n];
            if (n != 0) b |= 0x80;
            out.push_back(b);
        }
    };
    emit_base128(arcs[0] * 40 + arcs[1]);
    for (size_t i = 2; i < arcs.size(); ++i) emit_base128(arcs[i]);
    return out;
}

class RequirementTextParser {
public:
    explicit RequirementTextParser(const std::string& text) : text_(text) {}

    std::vector<uint8_t> parse() {
        skip();
        auto result = parse_or();
        skip();
        if (pos_ != text_.size()) throw std::invalid_argument("unexpected trailing requirement expression near: " + text_.substr(pos_, std::min<size_t>(32, text_.size() - pos_)));
        return result;
    }

private:
    const std::string& text_;
    size_t pos_ = 0;

    void skip() {
        while (pos_ < text_.size() && std::isspace(static_cast<unsigned char>(text_[pos_]))) ++pos_;
    }
    bool consume_word(const char* word) {
        skip();
        const size_t n = std::strlen(word);
        if (text_.compare(pos_, n, word) != 0) return false;
        if (pos_ + n < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_ + n])) || text_[pos_ + n] == '_' || text_[pos_ + n] == '.')) return false;
        pos_ += n; return true;
    }
    void expect_word(const char* word) {
        if (!consume_word(word)) throw std::invalid_argument(std::string("expected '") + word + "' in requirement");
    }
    std::string quoted() {
        skip();
        if (pos_ >= text_.size() || text_[pos_] != '"') throw std::invalid_argument("expected quoted string in requirement");
        ++pos_;
        std::string out;
        while (pos_ < text_.size()) {
            char c = text_[pos_++];
            if (c == '"') return out;
            if (c == '\\' && pos_ < text_.size()) {
                char e = text_[pos_++];
                if (e == 'n') out.push_back('\n'); else if (e == 'r') out.push_back('\r'); else if (e == 't') out.push_back('\t'); else out.push_back(e);
            } else out.push_back(c);
        }
        throw std::invalid_argument("unterminated quoted string in requirement");
    }
    std::string bracket_field() {
        skip();
        if (pos_ >= text_.size() || text_[pos_] != '[') throw std::invalid_argument("expected '[' in requirement");
        ++pos_; skip();
        std::string out;
        while (pos_ < text_.size() && text_[pos_] != ']') out.push_back(text_[pos_++]);
        if (pos_ >= text_.size()) throw std::invalid_argument("unterminated certificate field in requirement");
        ++pos_;
        while (!out.empty() && std::isspace(static_cast<unsigned char>(out.back()))) out.pop_back();
        return out;
    }
    uint32_t match_operation() {
        skip();
        if (consume_word("exists")) return 0;
        if (consume_word("absent")) return 14;
        if (text_.compare(pos_, 2, "==") == 0 || text_.compare(pos_, 1, "=") == 0) { pos_ += text_.compare(pos_, 2, "==") == 0 ? 2 : 1; return 1; }
        if (text_.compare(pos_, 2, "*=") == 0) { pos_ += 2; return 2; }
        if (text_.compare(pos_, 2, "^=") == 0) { pos_ += 2; return 3; }
        if (text_.compare(pos_, 2, "$=") == 0) { pos_ += 2; return 4; }
        if (text_.compare(pos_, 2, "<=" ) == 0) { pos_ += 2; return 6; }
        if (text_.compare(pos_, 2, ">=" ) == 0) { pos_ += 2; return 8; }
        if (text_.compare(pos_, 1, "<") == 0) { ++pos_; return 5; }
        if (text_.compare(pos_, 1, ">") == 0) { ++pos_; return 7; }
        throw std::invalid_argument("unsupported requirement match operator");
    }
    std::vector<uint8_t> parse_or() {
        auto lhs = parse_and();
        for (;;) {
            size_t save = pos_; if (!consume_word("or")) { pos_ = save; return lhs; }
            auto rhs = parse_and(); lhs = requirement_or_expression(lhs, rhs);
        }
    }
    std::vector<uint8_t> parse_and() {
        auto lhs = parse_unary();
        for (;;) {
            size_t save = pos_; if (!consume_word("and")) { pos_ = save; return lhs; }
            auto rhs = parse_unary(); lhs = requirement_and_expression(lhs, rhs);
        }
    }
    std::vector<uint8_t> parse_unary() {
        skip();
        if (consume_word("not")) return requirement_not_expression(parse_unary());
        if (pos_ < text_.size() && text_[pos_] == '(') { ++pos_; auto e = parse_or(); skip(); if (pos_ >= text_.size() || text_[pos_] != ')') throw std::invalid_argument("unclosed requirement expression"); ++pos_; return e; }
        return parse_atom();
    }
    std::vector<uint8_t> parse_atom() {
        skip();
        if (consume_word("true")) { return std::vector<uint8_t>{0,0,0,1}; }
        if (consume_word("false")) { return std::vector<uint8_t>{0,0,0,0}; }
        if (consume_word("anchor")) {
            if (consume_word("apple")) {
                if (consume_word("generic")) { std::vector<uint8_t> out; append_be32(out, 15); return out; }
                std::vector<uint8_t> out; append_be32(out, requirement_opcode_value(RequirementOpcode::APPLE_ANCHOR)); return out;
            }
            throw std::invalid_argument("unsupported anchor requirement");
        }
        if (consume_word("identifier")) return requirement_ident_expression(quoted());
        if (consume_word("cdhash")) {
            skip(); size_t begin = pos_; while (pos_ < text_.size() && std::isxdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
            auto hash = hex_decode(text_.substr(begin, pos_ - begin)); return requirement_cdhash_expression(hash);
        }
        if (consume_word("info")) {
            std::string field = bracket_field(); uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            return requirement_info_field_expression(field, match, value);
        }
        if (consume_word("entitlement")) {
            std::string field = bracket_field(); uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            return requirement_entitlement_field_expression(field, match, value);
        }
        if (consume_word("platform")) {
            uint32_t match = match_operation(); if (match != 1) throw std::invalid_argument("platform requirement requires equality");
            skip(); size_t begin = pos_; while (pos_ < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_])) || text_[pos_] == '_')) ++pos_;
            std::string name = text_.substr(begin, pos_ - begin); uint32_t platform = 0;
            if (name == "macOS" || name == "macos") platform = 1; else if (name == "iOS" || name == "ios") platform = 2; else if (name == "tvOS" || name == "tvos") platform = 3; else if (name == "watchOS" || name == "watchos") platform = 4; else if (name == "bridgeOS" || name == "bridgeos") platform = 5; else if (name == "macCatalyst" || name == "maccatalyst") platform = 6; else { try { platform = std::stoul(name); } catch (...) { throw std::invalid_argument("unknown platform requirement"); } }
            std::vector<uint8_t> out; append_be32(out, requirement_opcode_value(RequirementOpcode::PLATFORM)); append_be32(out, platform); return out;
        }
        if (consume_word("certificate")) {
            skip(); size_t begin = pos_; while (pos_ < text_.size() && (std::isalnum(static_cast<unsigned char>(text_[pos_])) || text_[pos_] == '_')) ++pos_;
            std::string index_name = text_.substr(begin, pos_ - begin); uint32_t index = requirement_cert_index(index_name); std::string field = bracket_field();
            uint32_t match = match_operation(); std::string value = match == 0 || match == 14 ? std::string() : quoted();
            if (field.rfind("field.", 0) == 0) {
                auto oid = oid_content_from_dotted(field.substr(6)); std::vector<uint8_t> out; append_be32(out, requirement_opcode_value(RequirementOpcode::CERT_GENERIC)); append_be32(out, index); append_requirement_string(out, std::string(reinterpret_cast<const char*>(oid.data()), oid.size())); append_be32(out, match); if (match != 0 && match != 14) append_requirement_string(out, value); return out;
            }
            return requirement_match_expression(requirement_opcode_value(RequirementOpcode::CERT_FIELD), index, field, match, value);
        }
        throw std::invalid_argument("unsupported requirement expression near: " + text_.substr(pos_, std::min<size_t>(48, text_.size() - pos_)));
    }
};

inline std::vector<uint8_t> compile_requirements_impl(const std::string& text) {
    if (text.size() >= 12 && load_be32(reinterpret_cast<const uint8_t*>(text.data())) == 0xfade0c01U) return std::vector<uint8_t>(text.begin(), text.end());
    if (text.size() >= 8 && load_be32(reinterpret_cast<const uint8_t*>(text.data())) == REQUIREMENT_MAGIC) {
        if (text.size() > std::numeric_limits<uint32_t>::max() - 20U) {
            throw std::length_error("requirements source too large");
        }
        std::vector<uint8_t> out;
        append_be32(out, 0xfade0c01U);
        append_be32(out, 20U + static_cast<uint32_t>(text.size()));
        append_be32(out, 1); append_be32(out, 3); append_be32(out, 20);
        out.insert(out.end(), text.begin(), text.end());
        return out;
    }
    RequirementTextParser parser(text);
    auto expression = parser.parse();
    std::vector<uint8_t> requirement_body;
    append_be32(requirement_body, 1);
    requirement_body.insert(requirement_body.end(), expression.begin(), expression.end());
    auto requirement = make_blob_impl(REQUIREMENT_MAGIC, requirement_body);
    if (requirement.size() > std::numeric_limits<uint32_t>::max() - 20U) throw std::length_error("requirements blob too large");
    std::vector<uint8_t> out;
    append_be32(out, 0xfade0c01U);
    append_be32(out, 20U + static_cast<uint32_t>(requirement.size()));
    append_be32(out, 1); append_be32(out, 3); append_be32(out, 20);
    out.insert(out.end(), requirement.begin(), requirement.end());
    return out;
}

}

namespace crypto {

inline std::vector<uint8_t> sha1_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(20);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha1(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> sha256_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(32);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha256(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> sha384_impl(const std::vector<uint8_t>& data) {
    std::vector<uint8_t> out(48);
    unsigned int length = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &length, EVP_sha384(), nullptr);
    out.resize(length);
    return out;
}

inline std::vector<uint8_t> hash_impl(HashType type, const std::vector<uint8_t>& data) {
    if (type == HashType::SHA1) return sha1_impl(data);
    if (type == HashType::SHA384) return sha384_impl(data);
    auto out = sha256_impl(data);
    if (type == HashType::SHA256_TRUNCATED && out.size() > 20) out.resize(20);
    return out;
}

inline std::vector<uint8_t> build_apple_cdhash_attr_impl(const std::vector<uint8_t>& cd_hash, HashType hash_type) {
    std::vector<uint8_t> oid;
    if (hash_type == HashType::SHA1) oid = {0x2B, 0x0E, 0x03, 0x02, 0x1A};
    else if (hash_type == HashType::SHA384) oid = {0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x02};
    else oid = {0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01};
    return der_sequence({der_wrap(0x06, oid), der_oct(cd_hash)});
}

inline std::vector<uint8_t> build_cdhashes_plist_xml_impl(const std::vector<std::pair<HashType, std::vector<uint8_t>>>& hashes) {
    plist_t root = plist_new_dict();
    plist_t array = plist_new_array();
    if (!root || !array) {
        if (root) plist_free(root);
        if (array) plist_free(array);
        return {};
    }
    for (const auto& item : hashes) {
        auto digest = item.second;
        if (digest.size() > 20) digest.resize(20);
        plist_array_append_item(array, plist_new_data(reinterpret_cast<const char*>(digest.data()), static_cast<uint64_t>(digest.size())));
    }
    plist_dict_set_item(root, "cdhashes", array);
    auto xml = plist_xml_bytes(root);
    plist_free(root);
    if (xml.empty() || xml.back() != '\n') xml.push_back('\n');
    return xml;
}

inline void remove_signing_time_attribute_impl(PKCS7_SIGNER_INFO* signer_info) {
    if (!signer_info || !signer_info->auth_attr) return;
    for (int i = sk_X509_ATTRIBUTE_num(signer_info->auth_attr) - 1; i >= 0; --i) {
        X509_ATTRIBUTE* attribute = sk_X509_ATTRIBUTE_value(signer_info->auth_attr, i);
        ASN1_OBJECT* object = X509_ATTRIBUTE_get0_object(attribute);
        if (object && OBJ_obj2nid(object) == NID_pkcs9_signingTime) {
            attribute = sk_X509_ATTRIBUTE_delete(signer_info->auth_attr, i);
            X509_ATTRIBUTE_free(attribute);
        }
    }
}

inline bool add_apple_cdhash_attributes_impl(PKCS7_SIGNER_INFO* signer_info, const std::vector<std::pair<HashType, std::vector<uint8_t>>>& hashes) {
    if (!signer_info || hashes.empty()) return false;
    int plist_nid = OBJ_txt2nid("1.2.840.113635.100.9.1");
    if (plist_nid == NID_undef) plist_nid = OBJ_create("1.2.840.113635.100.9.1", "appleCdHashes", "Apple Code Directory Hashes");
    int v2_nid = OBJ_txt2nid("1.2.840.113635.100.9.2");
    if (v2_nid == NID_undef) v2_nid = OBJ_create("1.2.840.113635.100.9.2", "appleCdHashes2", "Apple Code Directory Hashes 2");
    if (plist_nid == NID_undef || v2_nid == NID_undef) return false;
    auto plist_xml = build_cdhashes_plist_xml_impl(hashes);
    if (plist_xml.empty()) return false;
    ASN1_OCTET_STRING* plist_value = ASN1_OCTET_STRING_new();
    if (!plist_value) return false;
    if (ASN1_OCTET_STRING_set(plist_value, plist_xml.data(), static_cast<int>(plist_xml.size())) != 1) {
        ASN1_OCTET_STRING_free(plist_value);
        return false;
    }
    if (PKCS7_add_signed_attribute(signer_info, plist_nid, V_ASN1_OCTET_STRING, plist_value) != 1) {
        ASN1_OCTET_STRING_free(plist_value);
        return false;
    }
    std::vector<uint8_t> sequence_body;
    for (const auto& item : hashes) {
        auto sequence = build_apple_cdhash_attr_impl(item.second, item.first);
        if (sequence.size() < 2 || sequence[0] != 0x30) return false;
        size_t length = sequence[1];
        size_t header = 2;
        if ((sequence[1] & 0x80U) != 0) {
            size_t length_octets = sequence[1] & 0x7FU;
            if (length_octets == 0 || length_octets > sizeof(size_t) || 2 + length_octets > sequence.size()) return false;
            length = 0;
            for (size_t i = 0; i < length_octets; ++i) length = (length << 8) | sequence[2 + i];
            header += length_octets;
        }
        if (header + length != sequence.size()) return false;
        sequence_body.insert(sequence_body.end(), sequence.begin() + static_cast<std::ptrdiff_t>(header), sequence.end());
    }
    // OpenSSL represents V_ASN1_SEQUENCE attribute values as the complete
    // DER-encoded SEQUENCE in ASN1_STRING. Keep the outer SEQUENCE TLV here.
    auto sequence_der = der_wrap(0x30, sequence_body);
    ASN1_STRING* raw = ASN1_STRING_new();
    if (!raw) return false;
    if (ASN1_STRING_set(raw, sequence_der.data(), static_cast<int>(sequence_der.size())) != 1) {
        ASN1_STRING_free(raw);
        return false;
    }
    if (PKCS7_add_signed_attribute(signer_info, v2_nid, V_ASN1_SEQUENCE, raw) != 1) {
        ASN1_STRING_free(raw);
        return false;
    }
    return true;
}

inline X509Ptr load_certificate_der(const std::vector<uint8_t>& der) {
    const unsigned char* p = der.data();
    return X509Ptr(d2i_X509(nullptr, &p, static_cast<long>(der.size())));
}

inline PkeyPtr load_private_key_der(const std::vector<uint8_t>& der) {
    const unsigned char* p = der.data();
    return PkeyPtr(d2i_AutoPrivateKey(nullptr, &p, static_cast<long>(der.size())));
}

inline X509Ptr load_certificate_file(const std::string& path) {
    BioPtr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio.get()) return X509Ptr(nullptr);
    X509* cert = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
    if (cert) return X509Ptr(cert);
    BioPtr der_bio(BIO_new_file(path.c_str(), "r"));
    if (!der_bio.get()) return X509Ptr(nullptr);
    return X509Ptr(d2i_X509_bio(der_bio.get(), nullptr));
}

inline PkeyPtr load_private_key_file(const std::string& path, const std::string& password) {
    BioPtr bio(BIO_new_file(path.c_str(), "r"));
    if (!bio.get()) return PkeyPtr(nullptr);
    return PkeyPtr(PEM_read_bio_PrivateKey(bio.get(), nullptr, nullptr, const_cast<char*>(password.c_str())));
}

inline std::string openssl_error_detail(const std::string& context) {
    const unsigned long code = ERR_get_error();
    if (code == 0) return context;
    char message[256]{};
    ERR_error_string_n(code, message, sizeof(message));
    return context + ": " + message;
}

inline bool load_p12_impl(const std::string& path, const std::string& password,
                          std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der,
                          std::string* error = nullptr) {
    cert_der.clear();
    key_der.clear();
    ERR_clear_error();
    BioPtr bio(BIO_new_file(path.c_str(), "rb"));
    if (!bio.get()) {
        if (error) *error = "cannot open PKCS#12 file '" + path + "': " + std::strerror(errno);
        return false;
    }
    P12Ptr p12(d2i_PKCS12_bio(bio.get(), nullptr));
    if (!p12.get()) {
        if (error) *error = openssl_error_detail("invalid PKCS#12 file '" + path + "'");
        return false;
    }
    EVP_PKEY* key = nullptr;
    X509* cert = nullptr;
    STACK_OF(X509)* ca = nullptr;
    if (PKCS12_parse(p12.get(), password.c_str(), &key, &cert, &ca) != 1) {
        if (key) EVP_PKEY_free(key);
        if (cert) X509_free(cert);
        if (ca) sk_X509_pop_free(ca, X509_free);
        if (error) *error = openssl_error_detail("cannot decrypt/parse PKCS#12 file '" + path + "' (check the password)");
        return false;
    }
    StackPtr ca_ptr(ca);
    X509Ptr cert_ptr(cert);
    PkeyPtr key_ptr(key);
    if (cert_ptr.get()) {
        unsigned char* buffer = nullptr;
        int length = i2d_X509(cert_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            cert_der.assign(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    if (key_ptr.get()) {
        unsigned char* buffer = nullptr;
        int length = i2d_PrivateKey(key_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            key_der.assign(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    if (cert_der.empty() || key_der.empty()) {
        if (error) *error = "PKCS#12 file '" + path + "' does not contain both a certificate and a private key";
        return false;
    }
    return true;
}


struct CurlBuffer {
    std::vector<uint8_t> data;
};

inline size_t curl_write_callback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    auto* buffer = static_cast<CurlBuffer*>(userdata);
    size_t total = size * nmemb;
    buffer->data.insert(buffer->data.end(), reinterpret_cast<uint8_t*>(ptr), reinterpret_cast<uint8_t*>(ptr) + total);
    return total;
}

inline std::vector<uint8_t> make_timestamp_request(const std::vector<uint8_t>& signature, const std::string& policy) {
    TS_REQ* req = TS_REQ_new();
    if (!req) return {};
    bool ok = TS_REQ_set_version(req, 1) == 1;
    TS_MSG_IMPRINT* imprint = nullptr;
    X509_ALGOR* algorithm = nullptr;
    ASN1_INTEGER* nonce = nullptr;
    if (ok) imprint = TS_MSG_IMPRINT_new();
    if (ok && !imprint) ok = false;
    if (ok) algorithm = X509_ALGOR_new();
    if (ok && !algorithm) ok = false;
    if (ok) {
        ASN1_OBJECT* sha256 = OBJ_nid2obj(NID_sha256);
        if (!sha256 || !X509_ALGOR_set0(algorithm, sha256, V_ASN1_NULL, nullptr)) ok = false;
    }
    auto digest = sha256_impl(signature);
    if (ok && TS_MSG_IMPRINT_set_algo(imprint, algorithm) != 1) ok = false;
    if (ok) algorithm = nullptr;
    if (ok && TS_MSG_IMPRINT_set_msg(imprint, digest.data(), static_cast<int>(digest.size())) != 1) ok = false;
    if (ok && TS_REQ_set_msg_imprint(req, imprint) != 1) ok = false;
    if (ok) imprint = nullptr;
    if (ok && !policy.empty()) {
        ASN1_OBJECT* policy_obj = OBJ_txt2obj(policy.c_str(), 1);
        if (!policy_obj || TS_REQ_set_policy_id(req, policy_obj) != 1) ok = false;
        ASN1_OBJECT_free(policy_obj);
    }
    if (ok) {
        unsigned char random_bytes[16];
        nonce = ASN1_INTEGER_new();
        if (!nonce || RAND_bytes(random_bytes, sizeof(random_bytes)) != 1) ok = false;
        if (ok) {
            BIGNUM* bn = BN_bin2bn(random_bytes, sizeof(random_bytes), nullptr);
            if (!bn || !BN_to_ASN1_INTEGER(bn, nonce)) ok = false;
            BN_free(bn);
        }
    }
    if (ok && TS_REQ_set_nonce(req, nonce) != 1) ok = false;
    if (ok && TS_REQ_set_cert_req(req, 1) != 1) ok = false;
    ASN1_INTEGER_free(nonce);
    if (!ok) { X509_ALGOR_free(algorithm); TS_MSG_IMPRINT_free(imprint); TS_REQ_free(req); return {}; }
    unsigned char* der = nullptr;
    int len = i2d_TS_REQ(req, &der);
    TS_REQ_free(req);
    if (len <= 0 || !der) return {};
    std::vector<uint8_t> out(der, der + len);
    OPENSSL_free(der);
    return out;
}

inline X509_STORE* create_certificate_store(const CertificateChainOptions& options, std::string* diagnostic = nullptr) {
    X509_STORE* store = X509_STORE_new();
    if (!store) { if (diagnostic) *diagnostic = openssl_error_detail("X509_STORE_new failed"); return nullptr; }
    bool loaded_any = false;
    ERR_clear_error();
    if (X509_STORE_set_default_paths(store) == 1) loaded_any = true;
    else ERR_clear_error();
    if (!options.ca_file.empty()) {
        if (X509_STORE_load_locations(store, options.ca_file.c_str(), nullptr) != 1) {
            if (diagnostic) *diagnostic = openssl_error_detail("cannot load CA file '" + options.ca_file + "'");
            X509_STORE_free(store); return nullptr;
        }
        loaded_any = true;
    }
    if (!options.ca_path.empty()) {
        if (X509_STORE_load_locations(store, nullptr, options.ca_path.c_str()) != 1) {
            if (diagnostic) *diagnostic = openssl_error_detail("cannot load CA directory '" + options.ca_path + "'");
            X509_STORE_free(store); return nullptr;
        }
        loaded_any = true;
    }
    if (!loaded_any) {
        if (diagnostic) *diagnostic = "no usable trust roots: provide --ca-file/--ca-path or install OpenSSL default trust paths";
        X509_STORE_free(store); return nullptr;
    }
    return store;
}

inline bool verify_pkcs7_chain_and_root(PKCS7* p7, X509_STORE* store,
                                        const CertificateChainOptions& options,
                                        std::string* diagnostic) {
    if (!options.enabled) return true;
    STACK_OF(X509)* signers = PKCS7_get0_signers(p7, nullptr, 0);
    if (!signers || sk_X509_num(signers) == 0) {
        if (diagnostic) *diagnostic = "CMS contains no resolvable SignerInfo certificate";
        if (signers) sk_X509_free(signers);
        return false;
    }
    bool ok = true;
    for (int i = 0; i < sk_X509_num(signers); ++i) {
        X509* signer = sk_X509_value(signers, i);
        X509_STORE_CTX* ctx = X509_STORE_CTX_new();
        if (!ctx) { ok = false; if (diagnostic) *diagnostic = "X509_STORE_CTX_new failed"; break; }
        STACK_OF(X509)* untrusted = nullptr;
        if (PKCS7_type_is_signed(p7) && p7->d.sign) untrusted = p7->d.sign->cert;
        int init_ok = X509_STORE_CTX_init(ctx, store, signer, untrusted);
        if (init_ok == 1 && options.verification_time != 0) {
            X509_VERIFY_PARAM* param = X509_STORE_CTX_get0_param(ctx);
            X509_VERIFY_PARAM_set_time(param, static_cast<time_t>(options.verification_time));
        }
        int verify_ok = init_ok == 1 ? X509_verify_cert(ctx) : 0;
        if (verify_ok != 1) {
            if (diagnostic) {
                const int error = X509_STORE_CTX_get_error(ctx);
                *diagnostic = "certificate chain validation failed: " + std::string(X509_verify_cert_error_string(error));
            }
            ok = false;
            X509_STORE_CTX_free(ctx);
            break;
        }
        if (options.require_root) {
            STACK_OF(X509)* chain = X509_STORE_CTX_get1_chain(ctx);
            X509* root = chain && sk_X509_num(chain) > 0 ? sk_X509_value(chain, sk_X509_num(chain) - 1) : nullptr;
            EVP_PKEY* root_key = root ? X509_get_pubkey(root) : nullptr;
            const bool self_issued = root && X509_check_issued(root, root) == X509_V_OK;
            const bool self_signed = self_issued && root_key && X509_verify(root, root_key) == 1;
            EVP_PKEY_free(root_key);
            if (chain) sk_X509_pop_free(chain, X509_free);
            if (!self_signed) {
                if (diagnostic) *diagnostic = "certificate path is trusted but did not terminate at an included self-signed root certificate (--verify-chain-root)";
                ok = false;
                X509_STORE_CTX_free(ctx);
                break;
            }
        }
        X509_STORE_CTX_free(ctx);
    }
    sk_X509_free(signers);
    return ok;
}

inline bool verify_tsa_token_response(TS_REQ* request, TS_RESP* response,
                                      const std::string& ca_file, const std::string& ca_path,
                                      bool require_chain, bool require_root,
                                      std::string* diagnostic = nullptr) {
    if (!request || !response) { if (diagnostic) *diagnostic = "missing RFC 3161 request/response"; return false; }
    PKCS7* token = TS_RESP_get_token(response);
    if (!token) { if (diagnostic) *diagnostic = "RFC 3161 response has no timestamp token"; return false; }

    // Always validate the TSA CMS signature and timestamping certificate purpose,
    // even when ordinary certificate-path validation is disabled. OpenSSL's
    // TS_RESP_verify_signature performs the RFC 3161 ESS signer-certificate check.
    CertificateChainOptions chain;
    chain.enabled = require_chain;
    chain.require_root = require_root;
    chain.ca_file = ca_file;
    chain.ca_path = ca_path;
    X509_STORE* store = nullptr;
    if (require_chain) {
        std::string store_error;
        store = create_certificate_store(chain, &store_error);
        if (!store) { if (diagnostic) *diagnostic = store_error; return false; }
    }
    X509* tsa_signer = nullptr;
    const int signature_ok = TS_RESP_verify_signature(token, nullptr, store, &tsa_signer);
    if (signature_ok != 1 || !tsa_signer) {
        if (diagnostic) *diagnostic = openssl_error_detail("RFC 3161 TSA CMS signature / timestamping EKU validation failed");
        X509_free(tsa_signer);
        if (store) X509_STORE_free(store);
        return false;
    }
    X509_free(tsa_signer);
    if (require_chain && require_root &&
        !verify_pkcs7_chain_and_root(token, store, chain, diagnostic)) {
        X509_STORE_free(store);
        return false;
    }

    TS_VERIFY_CTX* ctx = TS_REQ_to_TS_VERIFY_CTX(request, nullptr);
    if (!ctx) {
        if (diagnostic) *diagnostic = openssl_error_detail("TS_REQ_to_TS_VERIFY_CTX failed");
        if (store) X509_STORE_free(store);
        return false;
    }
    TS_VERIFY_CTX_add_flags(ctx, TS_VFY_SIGNATURE);
    if (require_chain && TS_VERIFY_CTX_set0_store(ctx, store) != 1) {
        if (diagnostic) *diagnostic = openssl_error_detail("TS_VERIFY_CTX_set0_store failed");
        X509_STORE_free(store);
        TS_VERIFY_CTX_free(ctx);
        return false;
    }
    // set0_store transfers ownership to TS_VERIFY_CTX on success.
    const int verified = TS_RESP_verify_response(ctx, response);
    TS_VERIFY_CTX_free(ctx);
    if (verified != 1 && diagnostic) *diagnostic = openssl_error_detail("RFC 3161 nonce/imprint/policy/TSA verification failed");
    return verified == 1;
}

inline std::vector<uint8_t> request_timestamp_token(const std::vector<uint8_t>& signature, const std::string& url, const std::string& policy,
                                                       const std::string& ca_file, const std::string& ca_path,
                                                       bool require_trusted_tsa_chain, bool require_tsa_root) {
    if (url.empty()) return {};
    auto request = make_timestamp_request(signature, policy);
    if (request.empty()) return {};
    static std::once_flag curl_once;
    std::call_once(curl_once, [] {
        if (curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK) std::atexit(curl_global_cleanup);
    });
    CURL* curl = curl_easy_init();
    if (!curl) return {};
    CurlBuffer response;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, request.data());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(request.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/timestamp-query");
    headers = curl_slist_append(headers, "Accept: application/timestamp-reply");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(curl);
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    if (rc != CURLE_OK || response.data.empty()) return {};
    const unsigned char* req_ptr = request.data();
    TS_REQ* parsed_request = d2i_TS_REQ(nullptr, &req_ptr, static_cast<long>(request.size()));
    const unsigned char* p = response.data.data();
    TS_RESP* resp = d2i_TS_RESP(nullptr, &p, static_cast<long>(response.data.size()));
    if (!parsed_request || !resp || req_ptr != request.data() + request.size() ||
        p != response.data.data() + response.data.size()) {
        TS_REQ_free(parsed_request);
        TS_RESP_free(resp);
        return {};
    }
    bool response_ok = false;
    const TS_STATUS_INFO* status_info = TS_RESP_get_status_info(resp);
    const ASN1_INTEGER* status = status_info ? TS_STATUS_INFO_get0_status(status_info) : nullptr;
    if (status) {
        const long status_code = ASN1_INTEGER_get(status);
        response_ok = status_code == TS_STATUS_GRANTED || status_code == TS_STATUS_GRANTED_WITH_MODS;
    }
    TS_TST_INFO* tst_info = response_ok ? TS_RESP_get_tst_info(resp) : nullptr;
    const ASN1_INTEGER* requested_nonce = TS_REQ_get_nonce(parsed_request);
    const ASN1_INTEGER* returned_nonce = tst_info ? TS_TST_INFO_get_nonce(tst_info) : nullptr;
    if (!requested_nonce || !returned_nonce || ASN1_INTEGER_cmp(requested_nonce, returned_nonce) != 0) response_ok = false;
    if (response_ok) {
        TS_MSG_IMPRINT* imprint = TS_TST_INFO_get_msg_imprint(tst_info);
        ASN1_OCTET_STRING* imprint_message = imprint ? TS_MSG_IMPRINT_get_msg(imprint) : nullptr;
        const ASN1_OBJECT* imprint_algorithm = nullptr;
        if (imprint) X509_ALGOR_get0(&imprint_algorithm, nullptr, nullptr, TS_MSG_IMPRINT_get_algo(imprint));
        auto expected_imprint = sha256_impl(signature);
        if (!imprint_message || !imprint_algorithm || OBJ_obj2nid(imprint_algorithm) != NID_sha256 ||
            ASN1_STRING_length(imprint_message) != static_cast<int>(expected_imprint.size()) ||
            !std::equal(expected_imprint.begin(), expected_imprint.end(), ASN1_STRING_get0_data(imprint_message))) {
            response_ok = false;
        }
    }
    if (response_ok) {
        std::string tsa_error;
        if (!verify_tsa_token_response(parsed_request, resp, ca_file, ca_path, require_trusted_tsa_chain, require_tsa_root, &tsa_error)) {
            response_ok = false;
            if (require_trusted_tsa_chain) {
                TS_REQ_free(parsed_request);
                TS_RESP_free(resp);
                throw std::runtime_error("required RFC 3161 TSA verification failed: " + tsa_error);
            }
        }
    }
    PKCS7* token = response_ok ? TS_RESP_get_token(resp) : nullptr;
    if (!token) {
        TS_REQ_free(parsed_request);
        TS_RESP_free(resp);
        return {};
    }
    unsigned char* token_der = nullptr;
    int token_len = i2d_PKCS7(token, &token_der);
    TS_REQ_free(parsed_request);
    TS_RESP_free(resp);
    if (token_len <= 0 || !token_der) return {};
    std::vector<uint8_t> out(token_der, token_der + token_len);
    OPENSSL_free(token_der);
    return out;
}

inline std::vector<uint8_t> sign_pkcs7_detached_impl(const std::vector<uint8_t>& data, const std::vector<std::pair<HashType, std::vector<uint8_t>>>& cd_hashes, const std::string& cert_path, const std::string& key_path, const std::string& password, bool emit_signing_time, bool emit_cdhashes, const std::string& timestamp_url, bool timestamp_required, const std::string& timestamp_policy,
                                                            HashType cms_digest_hash, const std::string& timestamp_ca_file,
                                                            const std::string& timestamp_ca_path, bool timestamp_require_root = false) {
    if (timestamp_required && timestamp_url.empty()) {
        throw std::invalid_argument("timestamp is required but no timestamp URL was provided");
    }
    X509Ptr cert(nullptr);
    PkeyPtr key(nullptr);
    if (!key_path.empty()) {
        ERR_clear_error();
        cert = load_certificate_file(cert_path);
        if (!cert.get()) throw std::runtime_error(openssl_error_detail("failed to load certificate '" + cert_path + "'"));
        ERR_clear_error();
        key = load_private_key_file(key_path, password);
        if (!key.get()) throw std::runtime_error(openssl_error_detail("failed to load private key '" + key_path + "' (check the password)"));
    } else {
        std::vector<uint8_t> cert_der;
        std::vector<uint8_t> key_der;
        std::string load_error;
        if (!load_p12_impl(cert_path, password, cert_der, key_der, &load_error)) {
            throw std::runtime_error(load_error.empty() ? "failed to load PKCS#12 signing material" : load_error);
        }
        cert = load_certificate_der(cert_der);
        key = load_private_key_der(key_der);
        if (!cert.get() || !key.get()) throw std::runtime_error(openssl_error_detail("failed to decode PKCS#12 certificate/private key"));
    }
    if (X509_check_private_key(cert.get(), key.get()) != 1) {
        throw std::runtime_error(openssl_error_detail("certificate and private key do not match"));
    }
    if (data.size() > static_cast<size_t>(INT_MAX)) throw std::length_error("CMS signed content exceeds BIO length limit");
    BioPtr data_bio(BIO_new_mem_buf(data.data(), static_cast<int>(data.size())));
    if (!data_bio.get()) throw std::runtime_error(openssl_error_detail("failed to allocate CMS data BIO"));
    const int flags = PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOSMIMECAP | PKCS7_PARTIAL;
    ERR_clear_error();
    // Start with an empty partial SignedData and explicitly bind CMS digest to
    // the primary CodeDirectory hash. SHA-256-truncated CodeDirectories use the
    // full SHA-256 CMS digest algorithm (CMS digest algorithms are not truncated).
    Pkcs7Ptr p7(PKCS7_sign(nullptr, nullptr, nullptr, nullptr, flags));
    if (!p7.get()) throw std::runtime_error(openssl_error_detail("PKCS7_sign partial initialization failed"));
    const EVP_MD* cms_md = cms_digest_hash == HashType::SHA1 ? EVP_sha1() :
                           (cms_digest_hash == HashType::SHA384 ? EVP_sha384() : EVP_sha256());
    PKCS7_SIGNER_INFO* signer_info = PKCS7_sign_add_signer(p7.get(), cert.get(), key.get(), cms_md, PKCS7_NOSMIMECAP);
    if (!signer_info) throw std::runtime_error(openssl_error_detail("PKCS7_sign_add_signer failed"));
    auto* signer_infos = PKCS7_get_signer_info(p7.get());
    if (!signer_infos || sk_PKCS7_SIGNER_INFO_num(signer_infos) != 1)
        throw std::runtime_error("CMS signer initialization did not produce exactly one SignerInfo");
    if (!emit_signing_time) remove_signing_time_attribute_impl(signer_info);
    if (emit_cdhashes && !cd_hashes.empty() && !add_apple_cdhash_attributes_impl(signer_info, cd_hashes)) {
        throw std::runtime_error(openssl_error_detail("failed to add Apple CodeDirectory hash attributes"));
    }
    if (BIO_reset(data_bio.get()) != 1) throw std::runtime_error("failed to rewind CMS content BIO");
    ERR_clear_error();
    if (PKCS7_final(p7.get(), data_bio.get(), PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOSMIMECAP) != 1) {
        throw std::runtime_error(openssl_error_detail("PKCS7_final failed"));
    }
    if (!timestamp_url.empty()) {
        if (!signer_info->enc_digest) return {};
        const unsigned char* signature_bytes = ASN1_STRING_get0_data(signer_info->enc_digest);
        int signature_length = ASN1_STRING_length(signer_info->enc_digest);
        if (!signature_bytes || signature_length <= 0) return {};
        std::vector<uint8_t> signature_value(signature_bytes, signature_bytes + signature_length);
        auto timestamp_token = request_timestamp_token(signature_value, timestamp_url, timestamp_policy,
                                                               timestamp_ca_file, timestamp_ca_path,
                                                               timestamp_required || timestamp_require_root || !timestamp_ca_file.empty() || !timestamp_ca_path.empty(),
                                                               timestamp_require_root);
        if (timestamp_token.empty()) {
            if (timestamp_required) throw std::runtime_error("timestamp server did not return a valid RFC 3161 token");
        } else {
            int timestamp_nid = OBJ_txt2nid("1.2.840.113549.1.9.16.2.14");
            if (timestamp_nid == NID_undef) timestamp_nid = OBJ_create("1.2.840.113549.1.9.16.2.14", "id-aa-signatureTimeStampToken", "Signature Time-Stamp Token");
            if (timestamp_nid == NID_undef) return {};
            // V_ASN1_SEQUENCE attributes in OpenSSL store the complete encoded
            // SEQUENCE TLV. Validate that the timestamp token is one DER
            // SEQUENCE, then preserve its complete DER encoding as the value.
            size_t token_pos = 0;
            ASN1Node token_node;
            if (!asn1_parse_node(timestamp_token, token_pos, token_node) ||
                token_pos != timestamp_token.size() || token_node.tag != 0x30) return {};
            ASN1_STRING* timestamp_value = ASN1_STRING_new();
            if (!timestamp_value) return {};
            bool set_ok = ASN1_STRING_set(timestamp_value, timestamp_token.data(), static_cast<int>(timestamp_token.size())) == 1;
            if (!set_ok || PKCS7_add_attribute(signer_info, timestamp_nid, V_ASN1_SEQUENCE, timestamp_value) != 1) {
                ASN1_STRING_free(timestamp_value);
                return {};
            }
        }
    }
    unsigned char* der = nullptr;
    int length = i2d_PKCS7(p7.get(), &der);
    if (length <= 0 || !der) return {};
    std::vector<uint8_t> out(der, der + length);
    OPENSSL_free(der);
    return out;
}

inline std::vector<uint8_t> sign_pkcs7_impl(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password) {
    return sign_pkcs7_detached_impl(data, {}, cert_path, key_path, password, true, false, {}, false, {}, HashType::SHA256, {}, {});
}

inline bool verify_pkcs7_impl(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature,
                              const CertificateChainOptions& chain_options = {}, std::string* diagnostic = nullptr) {
    if (data.size() > static_cast<size_t>(INT_MAX) || signature.empty() || signature.size() > static_cast<size_t>(LONG_MAX)) {
        if (diagnostic) *diagnostic = "CMS data/signature size is outside OpenSSL limits";
        return false;
    }
    const unsigned char* p = signature.data();
    Pkcs7Ptr p7(d2i_PKCS7(nullptr, &p, static_cast<long>(signature.size())));
    if (!p7.get() || p != signature.data() + signature.size()) {
        if (diagnostic) *diagnostic = openssl_error_detail("invalid or trailing DER PKCS#7 data");
        return false;
    }
    BioPtr data_bio(BIO_new_mem_buf(data.data(), static_cast<int>(data.size())));
    if (!data_bio.get()) {
        if (diagnostic) *diagnostic = openssl_error_detail("failed to create CMS content BIO");
        return false;
    }
    ERR_clear_error();
    const int math_flags = PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOVERIFY | PKCS7_NOCHAIN;
    if (PKCS7_verify(p7.get(), nullptr, nullptr, data_bio.get(), nullptr, math_flags) != 1) {
        if (diagnostic) *diagnostic = openssl_error_detail("CMS mathematical signature validation failed");
        return false;
    }
    if (!chain_options.enabled) return true;
    X509_STORE* store = create_certificate_store(chain_options, diagnostic);
    if (!store) return false;
    const bool chain_ok = verify_pkcs7_chain_and_root(p7.get(), store, chain_options, diagnostic);
    X509_STORE_free(store);
    return chain_ok;
}

inline bool verify_pkcs7_attached_impl(PKCS7* p7, const CertificateChainOptions& chain_options,
                                       std::vector<uint8_t>* content, std::string* diagnostic = nullptr) {
    if (!p7) { if (diagnostic) *diagnostic = "null PKCS#7 object"; return false; }
    BIO* output = BIO_new(BIO_s_mem());
    if (!output) { if (diagnostic) *diagnostic = openssl_error_detail("cannot allocate PKCS#7 output BIO"); return false; }
    ERR_clear_error();
    const int rc = PKCS7_verify(p7, nullptr, nullptr, nullptr, output,
                                PKCS7_BINARY | PKCS7_NOVERIFY | PKCS7_NOCHAIN);
    if (rc == 1 && content) {
        char* raw = nullptr;
        const long n = BIO_get_mem_data(output, &raw);
        if (n > 0 && raw) content->assign(raw, raw + n);
        else content->clear();
    }
    if (rc != 1) {
        if (diagnostic) *diagnostic = openssl_error_detail("attached PKCS#7 mathematical signature validation failed");
        BIO_free(output);
        return false;
    }
    BIO_free(output);
    if (!chain_options.enabled) return true;
    std::string store_error;
    X509_STORE* store = create_certificate_store(chain_options, &store_error);
    if (!store) { if (diagnostic) *diagnostic = store_error; return false; }
    const bool chain_ok = verify_pkcs7_chain_and_root(p7, store, chain_options, diagnostic);
    X509_STORE_free(store);
    return chain_ok;
}

inline std::vector<std::vector<uint8_t>> extract_certs_raw_impl(const std::string& cert_path) {
    std::vector<std::vector<uint8_t>> out;
    BioPtr bio(BIO_new_file(cert_path.c_str(), "r"));
    if (!bio.get()) return out;
    for (;;) {
        X509* cert = PEM_read_bio_X509(bio.get(), nullptr, nullptr, nullptr);
        if (!cert) break;
        X509Ptr cert_ptr(cert);
        unsigned char* buffer = nullptr;
        int length = i2d_X509(cert_ptr.get(), &buffer);
        if (length > 0 && buffer) {
            out.emplace_back(buffer, buffer + length);
            OPENSSL_free(buffer);
        }
    }
    if (out.empty()) {
        BioPtr der_bio(BIO_new_file(cert_path.c_str(), "r"));
        if (der_bio.get()) {
            X509Ptr cert(d2i_X509_bio(der_bio.get(), nullptr));
            if (cert.get()) {
                unsigned char* buffer = nullptr;
                int length = i2d_X509(cert.get(), &buffer);
                if (length > 0 && buffer) {
                    out.emplace_back(buffer, buffer + length);
                    OPENSSL_free(buffer);
                }
            }
        }
    }
    if (out.empty()) {
        std::vector<uint8_t> cert_der;
        std::vector<uint8_t> key_der;
        if (load_p12_impl(cert_path, "", cert_der, key_der)) {
            out.push_back(cert_der);
        }
    }
    return out;
}

inline std::string extract_team_id_from_certificate_der_impl(const std::vector<uint8_t>& der) {
    X509Ptr cert = load_certificate_der(der);
    if (!cert.get()) return {};
    char buffer[256] = {0};
    int length = X509_NAME_get_text_by_NID(X509_get_subject_name(cert.get()), NID_organizationalUnitName, buffer, sizeof(buffer));
    if (length < 0) return {};
    return std::string(buffer, static_cast<size_t>(length));
}

inline std::string extract_team_id_from_certificate_file_impl(const std::string& cert_path) {
    X509Ptr cert = load_certificate_file(cert_path);
    if (!cert.get()) return {};
    char buffer[256] = {0};
    int length = X509_NAME_get_text_by_NID(X509_get_subject_name(cert.get()), NID_organizationalUnitName, buffer, sizeof(buffer));
    if (length < 0) return {};
    return std::string(buffer, static_cast<size_t>(length));
}

inline std::string extract_team_id_from_p12_impl(const std::string& p12_path, const std::string& password) {
    std::vector<uint8_t> cert_der;
    std::vector<uint8_t> key_der;
    if (!load_p12_impl(p12_path, password, cert_der, key_der)) return {};
    return extract_team_id_from_certificate_der_impl(cert_der);
}

inline std::vector<uint8_t> get_public_key_hash_impl(const std::string& cert_path) {
    X509Ptr cert = load_certificate_file(cert_path);
    if (!cert.get()) return {};
    unsigned char digest[EVP_MAX_MD_SIZE];
    unsigned int length = 0;
    if (X509_pubkey_digest(cert.get(), EVP_sha256(), digest, &length) != 1) return {};
    return std::vector<uint8_t>(digest, digest + length);
}

}

}
namespace ldid {

namespace signer {
void sign_file_impl(const std::filesystem::path& path, const SignOptions& options);
std::vector<uint8_t> sign_macho_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path = {}, const std::vector<std::vector<uint8_t>>& extra_special_slots = {});
ArchiveSignPlan build_sign_plan_impl(const std::filesystem::path& dir);
void sign_plan_impl(const ArchiveSignPlan& plan, const SignOptions& options);
}

namespace archive {

struct ArchiveReader {
    ::archive* handle;
    ArchiveReader() {
        handle = archive_read_new();
        if (handle) {
            archive_read_support_format_all(handle);
            archive_read_support_filter_all(handle);
        }
    }
    ~ArchiveReader() {
        if (handle) archive_read_free(handle);
    }
};

struct ArchiveWriter {
    ::archive* handle;
    ArchiveWriter() {
        handle = archive_write_new();
    }
    ~ArchiveWriter() {
        if (handle) archive_write_free(handle);
    }
};

inline std::string sanitize_relative_path(const std::string& raw) {
    std::filesystem::path input(raw);
    std::filesystem::path out;
    for (const auto& part : input) {
        if (part == ".." || part == "." || part == "/") continue;
        out /= part;
    }
    return out.generic_string();
}

inline bool is_archive_impl(const std::filesystem::path& path) {
    // Mach-O is never an archive. This early test also makes the dispatch rule
    // resilient to libarchive format registration changes across platforms.
    {
        std::ifstream probe(path, std::ios::binary);
        uint8_t magic[4]{};
        if (probe.read(reinterpret_cast<char*>(magic), sizeof(magic))) {
            std::vector<uint8_t> probe_bytes(magic, magic + sizeof(magic));
            if (macho::is_macho_impl(probe_bytes)) return false;
        }
    }
    ArchiveReader reader;
    if (!reader.handle) return false;
    if (archive_read_open_filename(reader.handle, path.string().c_str(), 10240) != ARCHIVE_OK) return false;
    ::archive_entry* entry = nullptr;
    const int result = archive_read_next_header(reader.handle, &entry);
    if (result != ARCHIVE_OK) return false;
    // archive_read_support_format_all() excludes the raw format, but can
    // recognize the special empty format. Do not treat that as a package.
    const int format = archive_format(reader.handle);
    if (format == ARCHIVE_FORMAT_EMPTY || format == ARCHIVE_FORMAT_RAW) return false;
    return archive_entry_pathname(entry) != nullptr;
}

inline ArchiveFormat detect_format_impl(const std::filesystem::path& path) {
    auto extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    if (extension == ".ipa") return ArchiveFormat::IPA;
    if (extension == ".zip") return ArchiveFormat::ZIP;
    if (extension == ".tar" || extension == ".tgz" || extension == ".gz") return ArchiveFormat::TAR;
    if (is_archive_impl(path)) return ArchiveFormat::ZIP;
    return ArchiveFormat::UNKNOWN;
}

inline std::vector<ArchiveEntryInfo> list_contents_impl(const std::filesystem::path& path) {
    std::vector<ArchiveEntryInfo> entries;
    ArchiveReader reader;
    if (!reader.handle) return entries;
    if (archive_read_open_filename(reader.handle, path.string().c_str(), 10240) != ARCHIVE_OK) return entries;
    for (;;) {
        ::archive_entry* entry = nullptr;
        int result = archive_read_next_header(reader.handle, &entry);
        if (result != ARCHIVE_OK) break;
        ArchiveEntryInfo info;
        const char* name = archive_entry_pathname(entry);
        info.path = name ? name : "";
        int64_t size = archive_entry_size(entry);
        info.size = size < 0 ? 0 : static_cast<uint64_t>(size);
        mode_t type = archive_entry_filetype(entry);
        info.is_directory = (type == AE_IFDIR);
        info.is_symlink = (type == AE_IFLNK);
        info.is_executable = false;
        info.is_signable = false;
        entries.push_back(info);
    }
    return entries;
}

inline void extract_archive_impl(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir) {
    std::filesystem::create_directories(out_dir);
    ArchiveReader reader;
    if (!reader.handle) throw std::runtime_error("archive reader allocation failed");
    if (archive_read_open_filename(reader.handle, archive_path.string().c_str(), 10240) != ARCHIVE_OK) {
        throw std::runtime_error("archive open failed");
    }
    for (;;) {
        ::archive_entry* entry = nullptr;
        int result = archive_read_next_header(reader.handle, &entry);
        if (result == ARCHIVE_EOF) break;
        if (result != ARCHIVE_OK) throw std::runtime_error("archive read failed");
        const char* raw_name = archive_entry_pathname(entry);
        std::string safe_name = sanitize_relative_path(raw_name ? raw_name : "");
        if (safe_name.empty()) continue;
        std::filesystem::path full_path = out_dir / safe_name;
        archive_entry_set_pathname(entry, full_path.string().c_str());
        int extract_result = archive_read_extract(reader.handle, entry, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_UNLINK);
        if (extract_result != ARCHIVE_OK && extract_result != ARCHIVE_WARN) {
            throw std::runtime_error("archive extract failed");
        }
    }
}

inline void configure_write_format_impl(::archive* handle, ArchiveFormat format) {
    if (format == ArchiveFormat::ZIP || format == ArchiveFormat::IPA) {
        archive_write_set_format_zip(handle);
    } else {
        archive_write_set_format_pax(handle);
    }
}

inline void add_directory_recursive_impl(const std::filesystem::path& dir, ::archive* handle) {
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        auto& item = *iterator;
        std::string relative = std::filesystem::relative(item.path(), dir).generic_string();
        if (relative.empty()) continue;
        ::archive_entry* entry = archive_entry_new();
        if (!entry) continue;
        archive_entry_set_pathname(entry, relative.c_str());
        auto status = std::filesystem::symlink_status(item.path());
        if (std::filesystem::is_symlink(status)) {
            archive_entry_set_filetype(entry, AE_IFLNK);
            archive_entry_set_perm(entry, 0777);
            std::filesystem::path target = std::filesystem::read_symlink(item.path());
            archive_entry_set_symlink(entry, target.generic_string().c_str());
        } else if (std::filesystem::is_directory(status)) {
            archive_entry_set_filetype(entry, AE_IFDIR);
            archive_entry_set_perm(entry, 0755);
        } else if (std::filesystem::is_regular_file(status)) {
            archive_entry_set_filetype(entry, AE_IFREG);
            auto permissions = std::filesystem::status(item.path()).permissions();
            bool executable = (permissions & std::filesystem::perms::owner_exec) != std::filesystem::perms::none;
            archive_entry_set_perm(entry, executable ? 0755 : 0644);
            archive_entry_set_size(entry, static_cast<int64_t>(std::filesystem::file_size(item.path())));
        } else {
            archive_entry_free(entry);
            continue;
        }
        if (archive_write_header(handle, entry) != ARCHIVE_OK) {
            archive_entry_free(entry);
            continue;
        }
        if (std::filesystem::is_regular_file(status)) {
            std::ifstream input(item.path(), std::ios::binary);
            std::vector<char> buffer(65536);
            while (input.read(buffer.data(), static_cast<std::streamsize>(buffer.size()))) {
                archive_write_data(handle, buffer.data(), static_cast<size_t>(input.gcount()));
            }
            if (input.gcount() > 0) {
                archive_write_data(handle, buffer.data(), static_cast<size_t>(input.gcount()));
            }
        }
        archive_entry_free(entry);
    }
}

inline void create_archive_impl(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format) {
    if (out.has_parent_path()) {
        std::filesystem::create_directories(out.parent_path());
    }
    ArchiveWriter writer;
    if (!writer.handle) throw std::runtime_error("archive writer allocation failed");
    configure_write_format_impl(writer.handle, format);
    if (archive_write_open_filename(writer.handle, out.string().c_str()) != ARCHIVE_OK) {
        throw std::runtime_error("archive write open failed");
    }
    add_directory_recursive_impl(dir, writer.handle);
}

inline void create_ipa_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::IPA);
}

inline void create_zip_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::ZIP);
}

inline void create_tar_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::TAR);
}

inline void extract_ipa_impl(const std::filesystem::path& ipa, const std::filesystem::path& dir) {
    extract_archive_impl(ipa, dir);
}

inline void repack_ipa_impl(const std::filesystem::path& dir, const std::filesystem::path& out) {
    create_archive_impl(dir, out, ArchiveFormat::IPA);
}

inline bool is_signable_bundle_extension(const std::filesystem::path& path) {
    auto extension = path.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return extension == ".app" || extension == ".framework" ||
           extension == ".xpc" || extension == ".appex" || extension == ".kext" ||
           extension == ".plugin";
}

inline bool is_macho_file_impl(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return false;
    std::vector<uint8_t> head(8);
    input.read(reinterpret_cast<char*>(head.data()), static_cast<std::streamsize>(head.size()));
    auto count = input.gcount();
    if (count < 4) return false;
    head.resize(static_cast<size_t>(count));
    return macho::is_macho_impl(head);
}

inline std::filesystem::path find_app_bundle_impl(const std::filesystem::path& dir) {
    if (!std::filesystem::exists(dir)) return {};
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (iterator->is_directory() && iterator->path().extension() == ".app") {
            return iterator->path();
        }
    }
    return {};
}

inline std::filesystem::path find_executable_in_bundle_impl(const std::filesystem::path& bundle) {
    std::filesystem::path info_plist = bundle / "Info.plist";
    if (std::filesystem::exists(info_plist)) {
        std::ifstream input(info_plist, std::ios::binary);
        std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
        plist_t root = plist_from_xml_bytes(data);
        if (root) {
            plist_t item = plist_dict_get_item(root, "CFBundleExecutable");
            if (item) {
                char* raw = nullptr;
                plist_get_string_val(item, &raw);
                if (raw) {
                    std::string executable_name = raw;
                    free(raw);
                    std::filesystem::path candidate = bundle / executable_name;
                    if (std::filesystem::exists(candidate)) {
                        plist_free(root);
                        return candidate;
                    }
                }
            }
            plist_free(root);
        }
    }
    std::string fallback = bundle.stem().string();
    if (!fallback.empty()) {
        std::filesystem::path candidate = bundle / fallback;
        if (std::filesystem::exists(candidate)) return candidate;
    }
    for (auto& item : std::filesystem::directory_iterator(bundle)) {
        std::error_code ec;
        const auto status = item.symlink_status(ec);
        if (ec || std::filesystem::is_symlink(status) || !std::filesystem::is_regular_file(status)) continue;
        const auto permissions = status.permissions();
        if ((permissions & std::filesystem::perms::owner_exec) != std::filesystem::perms::none) return item.path();
    }
    return {};
}

inline bool path_is_under(const std::filesystem::path& child, const std::filesystem::path& root) {
    auto child_string = child.lexically_normal().generic_string();
    auto root_string = root.lexically_normal().generic_string();
    if (child_string == root_string) return true;
    if (root_string.empty()) return false;
    if (root_string.back() != '/') root_string.push_back('/');
    return child_string.rfind(root_string, 0) == 0;
}

inline std::vector<ArchiveEntryInfo> scan_for_signables_impl(const std::filesystem::path& dir) {
    std::vector<ArchiveEntryInfo> result;
    if (!std::filesystem::exists(dir)) return result;
    std::vector<std::filesystem::path> candidates;
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (iterator->is_directory() && is_signable_bundle_extension(iterator->path())) {
            candidates.push_back(iterator->path());
        }
    }
    std::sort(candidates.begin(), candidates.end(), [](const auto& a, const auto& b) {
        return a.generic_string().size() < b.generic_string().size();
    });
    std::vector<std::filesystem::path> selected_bundles;
    for (auto& candidate : candidates) {
        bool nested = false;
        for (auto& selected : selected_bundles) {
            if (path_is_under(candidate, selected)) {
                nested = true;
                break;
            }
        }
        if (!nested) selected_bundles.push_back(candidate);
    }
    for (auto& bundle : selected_bundles) {
        ArchiveEntryInfo info;
        info.path = bundle.generic_string();
        info.size = 0;
        info.is_directory = true;
        info.is_executable = false;
        info.is_symlink = false;
        info.is_signable = true;
        result.push_back(info);
    }
    for (auto iterator = std::filesystem::recursive_directory_iterator(dir, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (!iterator->is_regular_file()) continue;
        bool inside_bundle = false;
        for (auto& bundle : selected_bundles) {
            if (path_is_under(iterator->path(), bundle)) {
                inside_bundle = true;
                break;
            }
        }
        if (inside_bundle) continue;
        if (is_macho_file_impl(iterator->path())) {
            ArchiveEntryInfo info;
            info.path = iterator->path().generic_string();
            info.size = static_cast<uint64_t>(std::filesystem::file_size(iterator->path()));
            info.is_directory = false;
            info.is_symlink = false;
            info.is_executable = (std::filesystem::status(iterator->path()).permissions() & std::filesystem::perms::owner_exec) != std::filesystem::perms::none;
            info.is_signable = true;
            result.push_back(info);
        }
    }
    return result;
}

inline bool archive_path_contains_bundle(const std::string& name) {
    std::filesystem::path path(name);
    for (const auto& component : path) {
        std::string part = component.string();
        std::string lower = part;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        for (const char* suffix : {".app", ".framework", ".appex", ".bundle", ".xpc", ".plugin", ".kext"}) {
            if (lower.size() >= std::strlen(suffix) && lower.compare(lower.size() - std::strlen(suffix), std::strlen(suffix), suffix) == 0) return true;
        }
    }
    return false;
}

inline bool read_archive_chunk(struct archive* reader, std::vector<uint8_t>& buffer, size_t max_size) {
    buffer.clear();
    buffer.resize(max_size);
    la_ssize_t n = archive_read_data(reader, buffer.data(), max_size);
    if (n < 0) throw std::runtime_error("archive entry read failed");
    buffer.resize(static_cast<size_t>(n));
    return n != 0;
}

inline void write_archive_all(struct archive* writer, const uint8_t* data, size_t size) {
    size_t written = 0;
    while (written < size) {
        la_ssize_t n = archive_write_data(writer, data + written, size - written);
        if (n <= 0) throw std::runtime_error("archive entry write failed");
        written += static_cast<size_t>(n);
    }
}

inline void stream_sign_passthrough_impl(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    ArchiveReader reader;
    if (!reader.handle || archive_read_open_filename(reader.handle, in.string().c_str(), 10240) != ARCHIVE_OK) throw std::runtime_error("archive open failed");
    ArchiveFormat format = detect_format_impl(in);
    ArchiveWriter writer;
    if (!writer.handle) throw std::runtime_error("archive writer allocation failed");
    configure_write_format_impl(writer.handle, format);
    std::filesystem::path target = out.empty() ? in : out;
    bool replace_original = target == in;
    std::filesystem::path temporary = replace_original ? make_unique_temp_path(target, ".ldid-streaming-signed") : target;
    if (archive_write_open_filename(writer.handle, temporary.string().c_str()) != ARCHIVE_OK) throw std::runtime_error("archive output open failed");

    constexpr size_t chunk_size = 1024 * 1024;
    for (;;) {
        ::archive_entry* entry = nullptr;
        int status = archive_read_next_header(reader.handle, &entry);
        if (status == ARCHIVE_EOF) break;
        if (status != ARCHIVE_OK) throw std::runtime_error("archive read failed");
        const char* raw_name = archive_entry_pathname(entry);
        std::string name = sanitize_relative_path(raw_name ? raw_name : "");
        if (name.empty()) { archive_read_data_skip(reader.handle); continue; }
        auto cloned = archive_entry_clone(entry);
        if (!cloned) throw std::runtime_error("archive entry clone failed");
        archive_entry_set_pathname(cloned, name.c_str());
        mode_t type = archive_entry_filetype(entry);

        if (type == AE_IFLNK) {
            archive_entry_set_filetype(cloned, AE_IFLNK);
            const char* link = archive_entry_symlink(entry);
            archive_entry_set_symlink(cloned, link ? link : "");
            archive_read_data_skip(reader.handle);
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            archive_entry_free(cloned);
            continue;
        }

        if (type != AE_IFREG) {
            archive_read_data_skip(reader.handle);
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            archive_entry_free(cloned);
            continue;
        }

        std::vector<uint8_t> prefix;
        prefix.reserve(8);
        while (prefix.size() < 8) {
            std::vector<uint8_t> chunk;
            if (!read_archive_chunk(reader.handle, chunk, 8 - prefix.size())) break;
            prefix.insert(prefix.end(), chunk.begin(), chunk.end());
        }
        bool is_macho = prefix.size() >= 4 && macho::is_macho_impl(prefix);
        std::vector<uint8_t> content;
        std::filesystem::path spool;
        std::ofstream spool_stream;
        struct SpoolCleanup {
            std::filesystem::path path;
            ~SpoolCleanup() {
                if (!path.empty()) {
                    std::error_code ec;
                    std::filesystem::remove(path, ec);
                }
            }
        } spool_cleanup;
        const la_int64_t entry_size = archive_entry_size(entry);
        const bool known_size = entry_size >= 0;

        if (is_macho) {
            content = std::move(prefix);
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) content.insert(content.end(), chunk.begin(), chunk.end());
            content = signer::sign_macho_memory_impl(content, options, std::filesystem::path(name), {});
            archive_entry_set_size(cloned, static_cast<la_int64_t>(content.size()));
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            write_archive_all(writer.handle, content.data(), content.size());
        } else if (known_size) {
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            write_archive_all(writer.handle, prefix.data(), prefix.size());
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) write_archive_all(writer.handle, chunk.data(), chunk.size());
        } else {
            spool = make_unique_temp_path(std::filesystem::temp_directory_path() / "ldid-archive-entry", ".spool");
            spool_cleanup.path = spool;
            spool_stream.open(spool, std::ios::binary | std::ios::trunc);
            if (!spool_stream) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool open failed");
            }
            if (!prefix.empty()) spool_stream.write(reinterpret_cast<const char*>(prefix.data()), static_cast<std::streamsize>(prefix.size()));
            std::vector<uint8_t> chunk;
            while (read_archive_chunk(reader.handle, chunk, chunk_size)) {
                if (!chunk.empty()) spool_stream.write(reinterpret_cast<const char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
            }
            spool_stream.close();
            std::error_code ec;
            const auto actual_size = std::filesystem::file_size(spool, ec);
            if (ec || actual_size > static_cast<uintmax_t>(std::numeric_limits<la_int64_t>::max())) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool size invalid");
            }
            archive_entry_set_size(cloned, static_cast<la_int64_t>(actual_size));
            if (archive_write_header(writer.handle, cloned) != ARCHIVE_OK) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive header write failed");
            }
            std::ifstream spool_input(spool, std::ios::binary);
            if (!spool_input) {
                archive_entry_free(cloned);
                throw std::runtime_error("archive spool read failed");
            }
            std::vector<uint8_t> chunk_buf(chunk_size);
            while (spool_input) {
                spool_input.read(reinterpret_cast<char*>(chunk_buf.data()), static_cast<std::streamsize>(chunk_buf.size()));
                const auto got = spool_input.gcount();
                if (got > 0) write_archive_all(writer.handle, chunk_buf.data(), static_cast<size_t>(got));
            }
            spool_input.close();
        }
        archive_entry_free(cloned);
    }
    archive_write_close(writer.handle);
    if (replace_original) {
        std::error_code ec;
        std::filesystem::rename(temporary, target, ec);
        if (ec) {
            std::filesystem::remove(temporary, ec);
            throw std::runtime_error("failed to replace archive: " + ec.message());
        }
    }
}
inline void stream_sign_impl(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    if (!is_archive_impl(in)) {
        signer::sign_file_impl(in, options);
        return;
    }
    if (!options.deep && !options.super_deep) {
        bool has_bundle = false;
        for (const auto& item : list_contents_impl(in)) {
            if (archive_path_contains_bundle(item.path)) { has_bundle = true; break; }
        }
        if (!has_bundle) {
            stream_sign_passthrough_impl(in, out, options);
            return;
        }
    }
    std::string work_dir = make_temp_dir();
    extract_archive_impl(in, work_dir);
    ArchiveSignPlan plan = signer::build_sign_plan_impl(work_dir);
    signer::sign_plan_impl(plan, options);
    std::filesystem::path target = out.empty() ? in : out;
    std::filesystem::path temporary_output = target;
    bool replace_original = false;
    if (target == in) {
        temporary_output = target;
        temporary_output += ".ldid-signed";
        replace_original = true;
    }
    create_archive_impl(work_dir, temporary_output, detect_format_impl(in));
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
    if (replace_original) {
        std::filesystem::rename(temporary_output, target, ec);
    }
}

}

namespace signer {

inline std::vector<uint8_t> read_bytes_local(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
}

inline std::string read_text_local(const std::filesystem::path& path) {
    std::vector<uint8_t> bytes = read_bytes_local(path);
    return std::string(bytes.begin(), bytes.end());
}

inline bool write_bytes_local(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
        if (ec) return false;
    }
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return false;
    output.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    output.flush();
    return static_cast<bool>(output);
}

inline bool write_bytes_atomic_local(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    static std::atomic<uint64_t> sequence{0};
    std::error_code ec;
    if (path.has_parent_path()) std::filesystem::create_directories(path.parent_path(), ec);
    if (ec) return false;
    const auto temporary = path.string() + ".ldid-tmp-" + std::to_string(
#if defined(_WIN32)
        0
#else
        static_cast<long long>(::getpid())
#endif
    ) + "-" + std::to_string(sequence.fetch_add(1, std::memory_order_relaxed));
    const bool had_original = std::filesystem::exists(path, ec) && !ec;
    const auto original_permissions = had_original ? std::filesystem::status(path, ec).permissions() : std::filesystem::perms::unknown;
    if (!write_bytes_local(temporary, data)) { std::filesystem::remove(temporary, ec); return false; }
    if (had_original && original_permissions != std::filesystem::perms::unknown) {
        std::filesystem::permissions(temporary, original_permissions, std::filesystem::perm_options::replace, ec);
        if (ec) { std::filesystem::remove(temporary, ec); return false; }
    }
    std::filesystem::rename(temporary, path, ec);
    if (ec) {
        // Windows does not replace an existing file with rename; retain a
        // recoverable backup rather than truncating the original in place.
        const auto backup = path.string() + ".ldid-backup-" + std::to_string(sequence.fetch_add(1, std::memory_order_relaxed));
        std::error_code backup_ec;
        if (std::filesystem::exists(path)) std::filesystem::rename(path, backup, backup_ec);
        ec.clear();
        std::filesystem::rename(temporary, path, ec);
        if (ec) {
            std::error_code restore_ec;
            if (std::filesystem::exists(backup)) std::filesystem::rename(backup, path, restore_ec);
            std::filesystem::remove(temporary, restore_ec);
            return false;
        }
        std::filesystem::remove(backup, backup_ec);
    }
    return true;
}

inline std::string identifier_from_path(const std::filesystem::path& path) {
    if (path.empty()) return "ldid-binary";
    auto filename = path.filename().string();
    if (filename.empty()) return "ldid-binary";
    auto dot = filename.find_last_of('.');
    if (dot != std::string::npos && dot != 0) {
        return filename.substr(0, dot);
    }
    return filename;
}

inline void merge_plist_dict(plist_t destination, plist_t overlay, bool deep) {
    if (!destination || !overlay || plist_get_node_type(destination) != PLIST_DICT || plist_get_node_type(overlay) != PLIST_DICT)
        throw std::invalid_argument("entitlement merge requires dictionary plists");
    plist_dict_iter iterator = nullptr;
    plist_dict_new_iter(overlay, &iterator);
    if (!iterator) return;
    for (;;) {
        char* key = nullptr;
        plist_t incoming = nullptr;
        plist_dict_next_item(overlay, iterator, &key, &incoming);
        if (!key || !incoming) { free(key); break; }
        plist_t current = plist_dict_get_item(destination, key);
        if (deep && current && plist_get_node_type(current) == PLIST_DICT && plist_get_node_type(incoming) == PLIST_DICT) {
            plist_t merged = plist_copy(current);
            if (!merged) { free(key); free(iterator); throw std::runtime_error("failed to copy nested entitlement dictionary"); }
            try { merge_plist_dict(merged, incoming, true); }
            catch (...) { plist_free(merged); free(key); free(iterator); throw; }
            plist_dict_set_item(destination, key, merged);
        } else {
            plist_dict_set_item(destination, key, plist_copy(incoming));
        }
        free(key);
    }
    free(iterator);
}

inline std::string merge_entitlements_xml(const std::string& base_xml, const std::string& overlay_xml, bool deep = false) {
    std::vector<uint8_t> base_bytes(base_xml.begin(), base_xml.end());
    std::vector<uint8_t> overlay_bytes(overlay_xml.begin(), overlay_xml.end());
    plist_t base = plist_from_xml_bytes(base_bytes);
    plist_t overlay = plist_from_xml_bytes(overlay_bytes);
    if (!base && overlay) { auto out = plist_xml_bytes(overlay); plist_free(overlay); return std::string(out.begin(), out.end()); }
    if (base && !overlay) { auto out = plist_xml_bytes(base); plist_free(base); return std::string(out.begin(), out.end()); }
    if (!base || !overlay) { if (base) plist_free(base); if (overlay) plist_free(overlay); throw std::invalid_argument("cannot merge invalid entitlement plist data"); }
    if (plist_get_node_type(base) != PLIST_DICT || plist_get_node_type(overlay) != PLIST_DICT) {
        plist_free(base); plist_free(overlay);
        throw std::invalid_argument("entitlement merge requires root dictionaries");
    }
    try { merge_plist_dict(base, overlay, deep); }
    catch (...) { plist_free(base); plist_free(overlay); throw; }
    auto merged = plist_xml_bytes(base);
    plist_free(base);
    plist_free(overlay);
    return std::string(merged.begin(), merged.end());
}
inline std::string resolve_team_id(const SignOptions& options) {
    if (!options.team_id.empty()) return options.team_id;
    if (!options.p12_path.empty()) {
        return crypto::extract_team_id_from_p12_impl(options.p12_path, options.key_password);
    }
    if (!options.certificate_path.empty()) {
        if (options.private_key_path.empty()) {
            auto from_p12 = crypto::extract_team_id_from_p12_impl(options.certificate_path, options.key_password);
            if (!from_p12.empty()) return from_p12;
        }
        return crypto::extract_team_id_from_certificate_file_impl(options.certificate_path);
    }
    return {};
}

inline std::string resolve_entitlements_xml(const SignOptions& options, const std::string& existing_xml) {
    std::string new_xml;
    if (!options.entitlements_path.empty()) {
        new_xml = read_text_local(options.entitlements_path);
    }
    if (!options.merge_entitlements_path.empty()) {
        std::string overlay = read_text_local(options.merge_entitlements_path);
        std::string base = existing_xml;
        if (base.empty()) base = new_xml;
        return merge_entitlements_xml(base, overlay, options.merge_entitlements_deep);
    }
    if (!new_xml.empty()) {
        if (options.preserve_entitlements && !existing_xml.empty()) {
            return merge_entitlements_xml(existing_xml, new_xml, options.merge_entitlements_deep);
        }
        return new_xml;
    }
    if (options.preserve_entitlements) return existing_xml;
    return {};
}

inline uint32_t resolve_cd_flags(const SignOptions& options) {
    uint32_t flags = options.cd_flags;
    // A signature without CMS signing material is an ad-hoc signature. Do not
    // emit an empty CMS blob while leaving CS_ADHOC clear; that creates a
    // structurally plausible but semantically invalid signature.
    if (options.adhoc || (options.p12_path.empty() && options.certificate_path.empty())) {
        flags |= static_cast<uint32_t>(CodeDirectoryFlag::ADHOC);
    }
    if (options.runtime) flags |= static_cast<uint32_t>(CodeDirectoryFlag::RUNTIME);
    if (options.library_validation) flags |= static_cast<uint32_t>(CodeDirectoryFlag::LIBRARY_VALIDATION);
    if (options.linker_signed) flags |= static_cast<uint32_t>(CodeDirectoryFlag::LINKER_SIGNED);
    return flags;
}

inline uint64_t resolve_exec_seg_flags(const macho::MachoAnalysis& analysis, const std::string& entitlements_xml) {
    // Values are from XNU cs_blobs.h. There is no CS_EXECSEG_PLATFORM_BINARY
    // or CS_EXECSEG_ALLOW_LV bit: 0x80 is the obsolete SKIP_LV bit, 0x100 and
    // 0x200 authorize cdhash load/exec and must not be inferred from a platform
    // identity claim. Those specialist bits remain opt-in through custom config.
    constexpr uint64_t CS_EXECSEG_MAIN_BINARY = 0x001ULL;
    constexpr uint64_t CS_EXECSEG_ALLOW_UNSIGNED = 0x010ULL;
    constexpr uint64_t CS_EXECSEG_DEBUGGER = 0x020ULL;
    constexpr uint64_t CS_EXECSEG_JIT = 0x040ULL;
    uint64_t flags = analysis.main_executable ? CS_EXECSEG_MAIN_BINARY : 0ULL;
    if (entitlements_xml.empty()) return flags;

    // Parse once: the previous implementation reparsed the same XML plist for
    // each entitlement, which is wasteful on large signing batches.
    const std::vector<uint8_t> bytes(entitlements_xml.begin(), entitlements_xml.end());
    plist_t entitlements = plist_from_xml_bytes(bytes);
    if (!entitlements) return flags;
    if (plist_get_node_type(entitlements) == PLIST_DICT) {
        const auto enabled = [&](const char* key) {
            plist_t item = plist_dict_get_item(entitlements, key);
            if (!item || plist_get_node_type(item) != PLIST_BOOLEAN) return false;
            uint8_t value = 0;
            plist_get_bool_val(item, &value);
            return value != 0;
        };
        if (enabled("com.apple.security.cs.allow-unsigned-executable-memory")) flags |= CS_EXECSEG_ALLOW_UNSIGNED;
        if (enabled("com.apple.security.cs.allow-jit")) flags |= CS_EXECSEG_JIT;
        if (enabled("com.apple.security.cs.debugger")) flags |= CS_EXECSEG_DEBUGGER;
    }
    plist_free(entitlements);
    return flags;
}

inline std::vector<uint8_t> embed_signature_placeholder(const std::vector<uint8_t>& data, size_t signature_size) {
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) throw std::invalid_argument("invalid Mach-O");
    std::vector<uint8_t> out = data;
    auto header = macho::parse_header(out, 0);
    auto commands = macho::enumerate_load_commands(out, header, 0);
    const macho::LoadCommandRef* existing = nullptr;
    size_t used_commands = 0;
    size_t max_header = out.size();
    for (const auto& command : commands) {
        used_commands += command.cmdsize;
        if (command.cmd == macho::kLC_CODE_SIGNATURE) existing = &command;
        if (command.cmd == macho::kLC_SEGMENT && command.cmdsize >= 40) {
            uint32_t fileoff = read_u32_file(out.data() + command.offset + 32, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = fileoff;
        }
        if (command.cmd == macho::kLC_SEGMENT_64 && command.cmdsize >= 56) {
            uint64_t fileoff = read_u64_file(out.data() + command.offset + 40, header.big);
            if (fileoff > analysis.header_end && fileoff < max_header) max_header = static_cast<size_t>(fileoff);
        }
    }
    if (existing) {
        size_t old_offset = read_u32_file(out.data() + existing->offset + 8, header.big);
        size_t old_size = read_u32_file(out.data() + existing->offset + 12, header.big);
        if (old_offset + old_size == out.size()) out.resize(old_offset);
        else if (old_offset + old_size <= out.size()) std::fill(out.begin() + static_cast<std::ptrdiff_t>(old_offset), out.begin() + static_cast<std::ptrdiff_t>(old_offset + old_size), 0);
        size_t new_offset = align_up64(out.size(), 16);
        macho::pad_to(out, new_offset);
        out.resize(new_offset + signature_size, 0);
        write_u32_file(out.data() + existing->offset + 8, static_cast<uint32_t>(new_offset), header.big);
        write_u32_file(out.data() + existing->offset + 12, static_cast<uint32_t>(signature_size), header.big);
        macho::update_linkedit_size(out, header, analysis.linkedit_fileoff);
        return out;
    }
    size_t insert_pos = analysis.load_commands_offset + used_commands;
    if (insert_pos + 16 > max_header || !macho::all_zero(out, insert_pos, 16)) throw std::runtime_error("no room for kLC_CODE_SIGNATURE");
    size_t new_offset = align_up64(out.size(), 16);
    macho::pad_to(out, new_offset);
    out.resize(new_offset + signature_size, 0);
    write_u32_file(out.data() + insert_pos, macho::kLC_CODE_SIGNATURE, header.big);
    write_u32_file(out.data() + insert_pos + 4, 16, header.big);
    write_u32_file(out.data() + insert_pos + 8, static_cast<uint32_t>(new_offset), header.big);
    write_u32_file(out.data() + insert_pos + 12, static_cast<uint32_t>(signature_size), header.big);
    write_u32_file(out.data() + 16, header.ncmds + 1, header.big);
    write_u32_file(out.data() + 20, header.sizeofcmds + 16, header.big);
    macho::update_linkedit_size(out, header, analysis.linkedit_fileoff);
    return out;
}

inline std::vector<uint8_t> sign_thin_memory_with_slots(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) return data;
    auto stripped = macho::strip_signature_impl(data);
    auto existing = macho::get_signature_info_impl(data);
    if (options.custom_signature.enabled && !options.custom_signature.raw_superblob.empty()) {
        const auto& raw = options.custom_signature.raw_superblob;
        if (raw.size() < 12 || raw.size() > std::numeric_limits<uint32_t>::max())
            throw std::invalid_argument("raw SuperBlob is too small or too large");
        const uint32_t magic = load_be32(raw.data());
        const uint32_t length = load_be32(raw.data() + 4);
        const uint32_t count = load_be32(raw.data() + 8);
        if ((magic != 0xfade0cc0U && magic != 0xfade0b02U) || length != raw.size() || count > (length - 12U) / 8U)
            throw std::invalid_argument("raw signature must be a complete embedded SuperBlob (0xfade0cc0 or legacy 0xfade0b02)");
        const uint64_t index_end = 12ULL + static_cast<uint64_t>(count) * 8ULL;
        std::set<uint32_t> seen_types;
        std::vector<std::pair<uint64_t, uint64_t>> raw_ranges;
        std::vector<uint8_t> raw_primary_cd;
        for (uint32_t i = 0; i < count; ++i) {
            const size_t index_pos = 12U + static_cast<size_t>(i) * 8U;
            const uint32_t type = load_be32(raw.data() + index_pos);
            const uint32_t offset = load_be32(raw.data() + index_pos + 4);
            if (!seen_types.insert(type).second || offset < index_end || offset > length || length - offset < 8)
                throw std::invalid_argument("raw SuperBlob contains duplicate types or an invalid index offset");
            const uint32_t blob_magic = load_be32(raw.data() + offset);
            const uint32_t blob_length = load_be32(raw.data() + offset + 4);
            if (blob_length < 8 || blob_length > length - offset)
                throw std::invalid_argument("raw SuperBlob contains an invalid component length");
            raw_ranges.emplace_back(offset, static_cast<uint64_t>(offset) + blob_length);
            if (type == 0U) {
                if (blob_magic != macho::CODEDIRECTORY_MAGIC || blob_length < 44)
                    throw std::invalid_argument("raw SuperBlob primary slot is not a complete CodeDirectory");
                raw_primary_cd.assign(raw.begin() + offset, raw.begin() + offset + blob_length);
            }
        }
        std::sort(raw_ranges.begin(), raw_ranges.end());
        for (size_t i = 1; i < raw_ranges.size(); ++i)
            if (raw_ranges[i].first < raw_ranges[i - 1].second)
                throw std::invalid_argument("raw SuperBlob components overlap");
        if (raw_primary_cd.empty()) throw std::invalid_argument("raw SuperBlob has no primary CodeDirectory at index 0");
        for (uint32_t i = 0; i < count; ++i) {
            const size_t index_pos = 12U + static_cast<size_t>(i) * 8U;
            if (load_be32(raw.data() + index_pos) != static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)) continue;
            const uint32_t cms_offset = load_be32(raw.data() + index_pos + 4);
            const uint32_t cms_blob_len = load_be32(raw.data() + cms_offset + 4);
            if (cms_blob_len < 8) throw std::invalid_argument("raw SuperBlob CMS wrapper is truncated");
            const auto* der_start = raw.data() + cms_offset + 8;
            const size_t der_length = cms_blob_len - 8;
            const unsigned char* cms_cursor = der_start;
            std::unique_ptr<PKCS7, decltype(&PKCS7_free)> imported_p7(
                d2i_PKCS7(nullptr, &cms_cursor, static_cast<long>(der_length)), PKCS7_free);
            if (!imported_p7 || cms_cursor != der_start + der_length)
                throw std::invalid_argument("raw SuperBlob CMS slot is not complete DER PKCS#7");
            STACK_OF(PKCS7_SIGNER_INFO)* signer_infos = PKCS7_get_signer_info(imported_p7.get());
            if (!signer_infos || sk_PKCS7_SIGNER_INFO_num(signer_infos) != 1)
                throw std::invalid_argument("raw SuperBlob application requires exactly one SignerInfo; multi-signer structures are inspection-only");
        }
        const uint32_t raw_cd_version = load_be32(raw_primary_cd.data() + 8);
        if (raw_cd_version < 0x20001U || raw_cd_version > 0x20600U)
            throw std::invalid_argument("raw CodeDirectory version is unsupported by this ldid build");
        if (raw_primary_cd.size() < (raw_cd_version >= 0x20600U ? 108U : raw_cd_version >= 0x20500U ? 96U : raw_cd_version >= 0x20400U ? 88U : raw_cd_version >= 0x20300U ? 64U : raw_cd_version >= 0x20200U ? 52U : raw_cd_version >= 0x20100U ? 48U : 44U))
            throw std::invalid_argument("raw primary CodeDirectory is truncated for its version");
        uint64_t raw_code_limit = load_be32(raw_primary_cd.data() + 32);
        if (raw_cd_version >= 0x20300U) raw_code_limit = load_be64(raw_primary_cd.data() + 56);
        auto final_image = embed_signature_placeholder(stripped, raw.size());
        auto final_analysis = macho::analyze_thin(final_image, 0);
        if (!final_analysis.valid || final_analysis.code_signature_offset == 0 ||
            final_analysis.code_signature_offset > final_image.size() || raw.size() > final_image.size() - final_analysis.code_signature_offset)
            throw std::runtime_error("failed to place custom raw SuperBlob");
        if (raw_code_limit != final_analysis.code_signature_offset)
            throw std::invalid_argument("raw CodeDirectory codeLimit does not match the final Mach-O signature offset");
        std::copy(raw.begin(), raw.end(), final_image.begin() + static_cast<std::ptrdiff_t>(final_analysis.code_signature_offset));
        const auto verify = Verifier::verify_memory(final_image);
        if (!verify.ok) {
            std::string joined;
            for (const auto& error : verify.errors) joined += (joined.empty() ? "" : "; ") + error;
            throw std::runtime_error("custom raw signature failed internal integrity validation: " + joined);
        }
        return final_image;
    }
    std::string identifier = options.identifier;
    if (identifier.empty()) identifier = existing.identifier;
    if (identifier.empty()) identifier = identifier_from_path(source_path);
    std::string team_id = resolve_team_id(options);
    if (team_id.empty() && options.preserve_entitlements) team_id = existing.team_id;
    std::string entitlements_xml = resolve_entitlements_xml(options, existing.entitlements_xml);
    const auto& custom = options.custom_signature;
    if (custom.enabled && !custom.entitlements_xml.empty()) entitlements_xml = custom.entitlements_xml;
    std::vector<uint8_t> requirements_blob;
    if (custom.enabled && !custom.requirements_blob.empty()) {
        requirements_blob = custom.requirements_blob;
    } else if (custom.enabled && !custom.requirements_expression.empty()) {
        requirements_blob = blob::compile_requirements_impl(custom.requirements_expression);
    } else if (!options.overall_requirements_path.empty()) {
        auto supplied = read_bytes_local(options.overall_requirements_path);
        if (supplied.size() >= 12 && load_be32(supplied.data()) == 0xfade0c01U) {
            requirements_blob = std::move(supplied);
        } else {
            requirements_blob = blob::compile_requirements_impl(std::string(supplied.begin(), supplied.end()));
        }
    } else if (!options.requirements_xml.empty()) {
        requirements_blob = blob::compile_requirements_impl(options.requirements_xml);
    } else if (!options.requirements_path.empty()) {
        // -Q denotes the designated requirement source.
        requirements_blob = blob::compile_requirements_impl(read_text_local(options.requirements_path));
    } else if (options.preserve_entitlements && !existing.requirements_blob.empty()) {
        requirements_blob = existing.requirements_blob;
    } else {
        requirements_blob = blob::build_requirements_blob_impl(identifier, team_id);
    }
    if (requirements_blob.empty()) throw std::runtime_error("failed to build designated requirement");
    std::vector<uint8_t> entitlements_blob;
    std::vector<uint8_t> der_entitlements_blob;
    if (!entitlements_xml.empty()) {
        entitlements_blob = blob::build_entitlements_blob_impl(entitlements_xml);
        bool emit_der = options.platform == Platform::IOS || options.platform == Platform::TVOS || options.platform == Platform::WATCHOS || options.platform == Platform::BRIDGEOS || options.platform == Platform::IOSSIMULATOR || options.platform == Platform::TVOSSIMULATOR || options.platform == Platform::WATCHOSSIMULATOR;
        if (options.platform == Platform::UNKNOWN && !existing.entitlements_der.empty()) emit_der = true;
        if (emit_der) der_entitlements_blob = blob::build_der_entitlements_blob_impl(entitlements_xml);
    }
    std::vector<std::vector<uint8_t>> special_slots(12);
    for (size_t i = 0; i < extra_special_slots.size() && i < special_slots.size(); ++i) special_slots[i] = extra_special_slots[i];
    if (special_slots[1].empty()) {
        std::filesystem::path cursor = source_path.parent_path();
        bool inside_bundle = false;
        std::filesystem::path bundle_root;
        for (size_t depth = 0; depth < 16 && !cursor.empty(); ++depth) {
            if (archive::is_signable_bundle_extension(cursor)) {
                inside_bundle = true;
                bundle_root = cursor;
                break;
            }
            if (cursor == cursor.parent_path()) break;
            cursor = cursor.parent_path();
        }
        if (inside_bundle) {
            auto candidate = bundle_root / "Info.plist";
            if (std::filesystem::is_regular_file(candidate)) special_slots[1] = read_bytes_local(candidate);
        }
    }
    special_slots[2] = requirements_blob;
    special_slots[5] = entitlements_blob;
    special_slots[7] = der_entitlements_blob;
    if (custom.enabled) {
        for (const auto& [slot, bytes] : custom.special_slot_data) {
            if (slot == 0 || slot > 11) throw std::invalid_argument("custom special slot must be in range 1..11");
            special_slots[slot] = bytes;
        }
        auto replace_blob_slot = [&](uint32_t slot, std::vector<uint8_t>& destination, uint32_t expected_magic, const char* label) {
            auto found = custom.special_slot_data.find(slot);
            if (found == custom.special_slot_data.end()) return;
            const auto& raw = found->second;
            if (raw.size() < 8 || load_be32(raw.data()) != expected_magic || load_be32(raw.data() + 4) != raw.size())
                throw std::invalid_argument(std::string("custom ") + label + " must be a complete Blob with the expected magic and exact length");
            destination = raw;
        };
        replace_blob_slot(2, requirements_blob, 0xfade0c01U, "Requirements slot");
        replace_blob_slot(5, entitlements_blob, 0xfade7171U, "XML Entitlements slot");
        replace_blob_slot(7, der_entitlements_blob, 0xfade7172U, "DER Entitlements slot");
        if (!requirements_blob.empty()) {
            const auto& raw = requirements_blob;
            if (raw.size() < 12 || load_be32(raw.data()) != 0xfade0c01U || load_be32(raw.data() + 4) != raw.size())
                throw std::invalid_argument("custom Requirements blob has an invalid header");
        }
    }
    HashType primary_hash = options.hash_type == HashType::ANY ? HashType::SHA256 : options.hash_type;
    std::vector<HashType> alternate_hashes;
    if (custom.enabled && !custom.alternate_code_directories.empty()) {
        if (custom.alternate_code_directories.size() > 5) throw std::invalid_argument("at most five alternate CodeDirectories are supported");
        std::set<uint32_t> unique_hashes;
        unique_hashes.insert(static_cast<uint32_t>(primary_hash));
        for (const auto& alt : custom.alternate_code_directories) {
            const HashType hash = alt.hash_type == HashType::ANY
                ? ((primary_hash == HashType::SHA1 || primary_hash == HashType::SHA256_TRUNCATED || primary_hash == HashType::SHA384) ? HashType::SHA256 : HashType::SHA1)
                : alt.hash_type;
            if (hash == primary_hash || !unique_hashes.insert(static_cast<uint32_t>(hash)).second)
                throw std::invalid_argument("alternate CodeDirectory hash types must be supported, unique, and different from the primary hash");
            alternate_hashes.push_back(hash);
        }
    } else if (custom.enabled && !custom.alternate_hash_types.empty()) {
        if (custom.alternate_hash_types.size() > 5) throw std::invalid_argument("at most five alternate CodeDirectories are supported");
        std::set<uint32_t> unique_hashes;
        unique_hashes.insert(static_cast<uint32_t>(primary_hash));
        for (HashType alt : custom.alternate_hash_types) {
            if (alt == HashType::ANY || alt == primary_hash || !unique_hashes.insert(static_cast<uint32_t>(alt)).second)
                throw std::invalid_argument("alternate CodeDirectory hash types must be supported, unique, and different from the primary hash");
            alternate_hashes.push_back(alt);
        }
    } else {
        alternate_hashes.push_back((primary_hash == HashType::SHA1 || primary_hash == HashType::SHA256_TRUNCATED || primary_hash == HashType::SHA384) ? HashType::SHA256 : HashType::SHA1);
    }
    bool has_certificate = !options.p12_path.empty() || !options.certificate_path.empty();
    std::string signing_certificate = !options.p12_path.empty() ? options.p12_path : options.certificate_path;
    std::string signing_key = !options.p12_path.empty() ? std::string() : options.private_key_path;
    std::vector<uint8_t> signature;
    for (size_t iteration = 0; iteration < 8; ++iteration) {
        size_t placeholder_size = signature.empty() ? 65536 : signature.size();
        auto signing_image = embed_signature_placeholder(stripped, placeholder_size);
        auto signing_analysis = macho::analyze_thin(signing_image, 0);
        if (!signing_analysis.valid || signing_analysis.code_signature_offset == 0) throw std::runtime_error("failed to prepare code signature command");
        size_t signing_limit = signing_analysis.code_signature_offset;
        blob::CodeDirectoryInputs inputs;
        inputs.code.assign(signing_image.begin(), signing_image.begin() + static_cast<std::ptrdiff_t>(signing_limit));
        inputs.identifier = identifier;
        inputs.team_id = team_id;
        inputs.hash_type = primary_hash;
        inputs.flags = resolve_cd_flags(options);
        if (custom.enabled) inputs.flags = (inputs.flags | custom.flags_set) & ~custom.flags_clear;
        inputs.version = custom.enabled && custom.code_directory_version ? *custom.code_directory_version : 0x20200;
        inputs.page_size = custom.enabled && custom.page_size && *custom.page_size != 0 ? *custom.page_size : 4096;
        inputs.infinite_page_size = custom.enabled && custom.page_size.has_value() && *custom.page_size == 0;
        inputs.platform = custom.enabled && custom.platform ? static_cast<Platform>(*custom.platform) : options.platform;
        inputs.special_slots = special_slots;
        inputs.exec_seg_base = custom.enabled && custom.exec_segment_base ? *custom.exec_segment_base : analysis.exec_seg_base;
        inputs.exec_seg_limit = custom.enabled && custom.exec_segment_limit ? *custom.exec_segment_limit : analysis.exec_seg_limit;
        inputs.exec_seg_flags = custom.enabled && custom.exec_segment_flags ? *custom.exec_segment_flags : resolve_exec_seg_flags(analysis, entitlements_xml);
        inputs.runtime_version = custom.enabled && custom.runtime_version ? *custom.runtime_version :
            (options.runtime ? (options.min_os_version != 0 ? options.min_os_version
               : (analysis.min_os_version != 0 ? analysis.min_os_version : 0x000A0E00U)) : 0U);
        if (custom.enabled && !custom.scatter_data.empty()) {
            if ((custom.scatter_data.size() % 24) != 0) throw std::invalid_argument("ScatterHex length must be a multiple of 24 bytes");
            for (size_t scatter_pos = 0; scatter_pos < custom.scatter_data.size(); scatter_pos += 24) {
                blob::CodeScatterRecord record;
                record.count = load_be32(custom.scatter_data.data() + scatter_pos);
                record.base = load_be32(custom.scatter_data.data() + scatter_pos + 4);
                record.target_offset = load_be64(custom.scatter_data.data() + scatter_pos + 8);
                record.spare = load_be64(custom.scatter_data.data() + scatter_pos + 16);
                inputs.scatter.push_back(record);
            }
        }
        if (custom.enabled) {
            inputs.pre_encrypt_hashes = custom.pre_encrypt_hashes;
            inputs.linkage_hash_type = custom.linkage_hash_type.value_or(0);
            inputs.linkage_application_type = custom.linkage_application_type.value_or(0);
            inputs.linkage_application_subtype = custom.linkage_application_subtype.value_or(0);
            inputs.linkage_data = custom.linkage_data;
        }
        auto primary_cd = blob::build_code_directory_full(inputs);
        std::map<uint32_t, std::vector<uint8_t>> slots;
        slots[static_cast<uint32_t>(CodeSignSlot::CODEDIRECTORY)] = primary_cd;
        std::vector<std::pair<HashType, std::vector<uint8_t>>> cd_hashes;
        cd_hashes.emplace_back(primary_hash, crypto::hash_impl(primary_hash, primary_cd));
        for (size_t alt_index = 0; alt_index < alternate_hashes.size(); ++alt_index) {
            blob::CodeDirectoryInputs alternate_inputs = inputs;
            alternate_inputs.hash_type = alternate_hashes[alt_index];
            if (custom.enabled && alt_index < custom.alternate_code_directories.size()) {
                const auto& alt = custom.alternate_code_directories[alt_index];
                if (alt.version) alternate_inputs.version = *alt.version;
                if (alt.page_size) {
                    alternate_inputs.page_size = *alt.page_size;
                    alternate_inputs.infinite_page_size = *alt.page_size == 0;
                }
                if (alt.platform) alternate_inputs.platform = static_cast<Platform>(*alt.platform);
                alternate_inputs.flags = (alternate_inputs.flags | alt.flags_set) & ~alt.flags_clear;
                if (!alt.identifier.empty()) alternate_inputs.identifier = alt.identifier;
                if (!alt.team_id.empty()) alternate_inputs.team_id = alt.team_id;
                if (alt.exec_segment_base) alternate_inputs.exec_seg_base = *alt.exec_segment_base;
                if (alt.exec_segment_limit) alternate_inputs.exec_seg_limit = *alt.exec_segment_limit;
                if (alt.exec_segment_flags) alternate_inputs.exec_seg_flags = *alt.exec_segment_flags;
                if (alt.runtime_version) alternate_inputs.runtime_version = *alt.runtime_version;
                if (!alt.scatter_data.empty()) {
                    if (alt.scatter_data.size() % 24 != 0) throw std::invalid_argument("alternate scatter data length must be a multiple of 24 bytes");
                    alternate_inputs.scatter.clear();
                    for (size_t scatter_pos = 0; scatter_pos < alt.scatter_data.size(); scatter_pos += 24) {
                        blob::CodeScatterRecord record;
                        record.count = load_be32(alt.scatter_data.data() + scatter_pos);
                        record.base = load_be32(alt.scatter_data.data() + scatter_pos + 4);
                        record.target_offset = load_be64(alt.scatter_data.data() + scatter_pos + 8);
                        record.spare = load_be64(alt.scatter_data.data() + scatter_pos + 16);
                        alternate_inputs.scatter.push_back(record);
                    }
                }
                if (!alt.pre_encrypt_hashes.empty()) alternate_inputs.pre_encrypt_hashes = alt.pre_encrypt_hashes;
                if (alt.linkage_hash_type) alternate_inputs.linkage_hash_type = *alt.linkage_hash_type;
                if (alt.linkage_application_type) alternate_inputs.linkage_application_type = *alt.linkage_application_type;
                if (alt.linkage_application_subtype) alternate_inputs.linkage_application_subtype = *alt.linkage_application_subtype;
                if (!alt.linkage_data.empty()) alternate_inputs.linkage_data = alt.linkage_data;
            }
            auto alternate_cd = blob::build_code_directory_full(alternate_inputs);
            const uint32_t alternate_slot = static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) + static_cast<uint32_t>(alt_index);
            slots[alternate_slot] = std::move(alternate_cd);
            cd_hashes.emplace_back(alternate_hashes[alt_index], crypto::hash_impl(alternate_hashes[alt_index], slots[alternate_slot]));
        }
        if (!requirements_blob.empty()) slots[static_cast<uint32_t>(CodeSignSlot::REQUIREMENTS)] = requirements_blob;
        if (!entitlements_blob.empty()) slots[static_cast<uint32_t>(CodeSignSlot::ENTITLEMENTS)] = entitlements_blob;
        if (!der_entitlements_blob.empty()) slots[static_cast<uint32_t>(CodeSignSlot::DER_ENTITLEMENTS)] = der_entitlements_blob;
        if (custom.enabled) {
            for (const auto& [slot, raw_blob] : custom.embedded_blobs) {
                if (slot == 0 || slot == 2 || slot == 5 || slot == 7 || slot == 0x10000 ||
                    (slot >= 0x1000 && slot < 0x1005))
                    throw std::invalid_argument("custom blob collides with a standard or generated SuperBlob slot: " + std::to_string(slot));
                if (raw_blob.size() < 8 || load_be32(raw_blob.data() + 4) != raw_blob.size())
                    throw std::invalid_argument("custom blob must include a valid 8-byte Blob header and matching length");
                slots[slot] = raw_blob;
            }
            for (uint32_t slot = 4; slot <= 11; ++slot) {
                const auto found = custom.embedded_blobs.find(slot);
                if (found != custom.embedded_blobs.end()) slots[slot] = found->second;
            }
            for (uint32_t slot : {4U, 6U, 8U, 9U, 10U, 11U}) {
                const auto found = custom.special_slot_data.find(slot);
                if (found == custom.special_slot_data.end()) continue;
                const auto& raw = found->second;
                if (raw.size() < 8 || load_be32(raw.data() + 4) != raw.size())
                    throw std::invalid_argument("custom special slot " + std::to_string(slot) + " must contain a complete Blob with exact length");
                if (slot >= 8U && load_be32(raw.data()) != 0xfade8181U)
                    throw std::invalid_argument("custom launch constraint slots require magic 0xfade8181");
                slots[slot] = raw;
            }
        }
        if (!custom.raw_cms_der.empty()) {
            const unsigned char* cms_cursor = custom.raw_cms_der.data();
            std::unique_ptr<PKCS7, decltype(&PKCS7_free)> custom_p7(
                d2i_PKCS7(nullptr, &cms_cursor, static_cast<long>(custom.raw_cms_der.size())), PKCS7_free);
            if (!custom_p7 || cms_cursor != custom.raw_cms_der.data() + custom.raw_cms_der.size())
                throw std::invalid_argument("custom CMS DER is not a complete PKCS#7 object");
            STACK_OF(PKCS7_SIGNER_INFO)* signer_infos = PKCS7_get_signer_info(custom_p7.get());
            if (!signer_infos || sk_PKCS7_SIGNER_INFO_num(signer_infos) != 1)
                throw std::invalid_argument("custom CMS application requires exactly one SignerInfo; multi-signer structures are inspection-only");
            if (!crypto::verify_pkcs7_impl(primary_cd, custom.raw_cms_der))
                throw std::runtime_error("custom CMS DER does not mathematically verify against the generated primary CodeDirectory (certificate-chain validation is a separate optional step)");
            slots[static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)] = blob::make_blob_impl(static_cast<uint32_t>(BlobMagic::CSMAGIC_BLOBWRAPPER), custom.raw_cms_der);
        } else if (!options.adhoc && has_certificate) {
            auto cms = crypto::sign_pkcs7_detached_impl(primary_cd, cd_hashes, signing_certificate, signing_key, options.key_password, options.emit_signing_time, options.true_sign, options.timestamp_enabled ? options.timestamp_url : std::string{}, options.timestamp_required, options.timestamp_policy, primary_hash,
                options.timestamp_ca_file, options.timestamp_ca_path, options.timestamp_require_root);
            if (cms.empty()) throw std::runtime_error("CMS signing failed");
            slots[static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)] = blob::make_blob_impl(static_cast<uint32_t>(BlobMagic::CSMAGIC_BLOBWRAPPER), cms);
        } else {
            slots[static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)] = blob::make_blob_impl(static_cast<uint32_t>(BlobMagic::CSMAGIC_BLOBWRAPPER), {});
        }
        auto superblob = blob::build_superblob_impl(slots);
        signature = superblob;
        if (signature.size() == placeholder_size) break;
        if (iteration == 7) throw std::runtime_error("code signature size did not converge");
    }
    auto final_image = embed_signature_placeholder(stripped, signature.size());
    auto final_analysis = macho::analyze_thin(final_image, 0);
    if (!final_analysis.valid || final_analysis.code_signature_offset + signature.size() > final_image.size()) throw std::runtime_error("final code signature placement failed");
    std::copy(signature.begin(), signature.end(), final_image.begin() + static_cast<std::ptrdiff_t>(final_analysis.code_signature_offset));
    return final_image;
}

inline std::vector<uint8_t> sign_thin_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path) {
    return sign_thin_memory_with_slots(data, options, source_path, {});
}

inline bool slice_matches_arch(const Slice& slice, const std::string& arch) {
    uint32_t subtype = 0;
    bool has_subtype = false;
    CPUType wanted = macho::cpu_type_from_arch(arch, subtype, has_subtype);
    if (wanted == CPUType::ANY) return true;
    if (slice.cpu_type != wanted) return false;
    if (has_subtype && slice.cpu_subtype != subtype) return false;
    return true;
}

inline size_t effective_sign_jobs(const SignOptions& options, size_t work_items) {
    if (work_items <= 1) return work_items;
    if (options.jobs != 0) return std::max<size_t>(1, std::min<size_t>(options.jobs, work_items));
    const unsigned int hardware = std::thread::hardware_concurrency();
    return std::min<size_t>(work_items, std::max<unsigned int>(1, std::min<unsigned int>(hardware ? hardware : 2, 4)));
}

inline std::vector<uint8_t> sign_macho_memory_impl(const std::vector<uint8_t>& data, const SignOptions& options, const std::filesystem::path& source_path, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    if (data.size() < 8) return data;
    uint32_t be_magic = load_be32(data.data());
    if (be_magic == macho::kFAT_MAGIC || be_magic == macho::kFAT_MAGIC_64 || be_magic == macho::kFAT_CIGAM || be_magic == macho::kFAT_CIGAM_64) {
        auto slices = macho::parse_slices_impl(data);
        std::vector<std::vector<uint8_t>> signed_slices(slices.size());
        std::vector<size_t> selected;
        selected.reserve(slices.size());
        for (size_t i = 0; i < slices.size(); ++i) {
            if (options.arch.empty() || slice_matches_arch(slices[i], options.arch)) selected.push_back(i);
            else {
                const auto& slice = slices[i];
                signed_slices[i].assign(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                        data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
            }
        }
        if (!options.arch.empty() && selected.empty()) throw std::invalid_argument("requested architecture not found: " + options.arch);
        if (!options.arch.empty() && selected.size() != slices.size()) {
            std::cerr << "ldid: warning: -A/--arch re-signs only matching slice(s); "
                      << (slices.size() - selected.size())
                      << " unselected Fat Mach-O slice(s) are preserved byte-for-byte with their existing signature state.\n";
        }
        const size_t jobs = effective_sign_jobs(options, selected.size());
        if (jobs <= 1) {
            for (size_t index : selected) {
                const auto& slice = slices[index];
                std::vector<uint8_t> slice_data(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                                data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
                signed_slices[index] = sign_thin_memory_with_slots(slice_data, options, source_path, extra_special_slots);
            }
        } else {
            std::atomic<size_t> next{0};
            std::vector<std::exception_ptr> failures(slices.size());
            std::vector<std::thread> workers;
            workers.reserve(jobs);
            for (size_t worker = 0; worker < jobs; ++worker) {
                workers.emplace_back([&] {
                    for (;;) {
                        const size_t task = next.fetch_add(1, std::memory_order_relaxed);
                        if (task >= selected.size()) break;
                        const size_t index = selected[task];
                        try {
                            const auto& slice = slices[index];
                            std::vector<uint8_t> slice_data(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                                            data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
                            signed_slices[index] = sign_thin_memory_with_slots(slice_data, options, source_path, extra_special_slots);
                        } catch (...) { failures[index] = std::current_exception(); }
                    }
                });
            }
            for (auto& worker : workers) worker.join();
            for (const auto& failure : failures) if (failure) std::rethrow_exception(failure);
        }
        auto original_slices = slices;
        bool fat64 = false;
        bool cigam = false;
        if (!original_slices.empty()) {
            fat64 = original_slices.front().fat64_container;
            cigam = original_slices.front().fat_cigam_container;
        }
        return macho::rebuild_fat_with_format_impl(signed_slices, fat64, cigam, original_slices);
    }
    if (!options.arch.empty()) {
        auto slices = macho::parse_slices_impl(data);
        if (slices.empty() || !slice_matches_arch(slices.front(), options.arch)) {
            throw std::invalid_argument("requested architecture not found: " + options.arch);
        }
    }
    return sign_thin_memory_impl(data, options, source_path);
}

inline std::filesystem::path resolve_output_path(const std::filesystem::path& input, const SignOptions& options) {
    if (!options.output_path.empty()) return options.output_path;
    if (options.output_stdout) return {};
    if (options.no_overwrite) {
        std::filesystem::path candidate = input;
        candidate += ".signed";
        int counter = 1;
        while (std::filesystem::exists(candidate)) {
            candidate = input;
            candidate += "-" + std::to_string(counter) + ".signed";
            ++counter;
        }
        return candidate;
    }
    // `-w` is the explicit in-place/write mode. The default path is also
    // in-place for historical compatibility with this ldid implementation.
    if (options.write_copy) return input;
    return input;
}

inline void write_result(const std::filesystem::path& input, const std::vector<uint8_t>& signed_data, const SignOptions& options) {
    if (options.output_stdout) {
        std::cout.write(reinterpret_cast<const char*>(signed_data.data()), static_cast<std::streamsize>(signed_data.size()));
        return;
    }
    auto output = resolve_output_path(input, options);
    if (output.empty()) output = input;
    std::error_code ec;
    auto original_permissions = std::filesystem::status(output, ec).permissions();
    bool changed_permissions = false;
    if (options.force && !ec) {
        auto writable = original_permissions | std::filesystem::perms::owner_write;
        if (writable != original_permissions) {
            std::filesystem::permissions(output, writable, std::filesystem::perm_options::replace, ec);
            changed_permissions = !ec;
        }
    }
    if (!write_bytes_atomic_local(output, signed_data)) throw std::runtime_error("failed to atomically write signed output: " + output.string());
    if (changed_permissions) {
        std::error_code restore_ec;
        std::filesystem::permissions(output, original_permissions, std::filesystem::perm_options::replace, restore_ec);
    }
}

inline void sign_file_with_slots_impl(const std::filesystem::path& path, const SignOptions& options, const std::vector<std::vector<uint8_t>>& extra_special_slots) {
    auto data = read_bytes_local(path);
    if (data.empty()) return;
    std::vector<uint8_t> signed_data;
    uint32_t be_magic = data.size() >= 8 ? load_be32(data.data()) : 0;
    if (be_magic == macho::kFAT_MAGIC || be_magic == macho::kFAT_MAGIC_64 || be_magic == macho::kFAT_CIGAM || be_magic == macho::kFAT_CIGAM_64) {
        signed_data = sign_macho_memory_impl(data, options, path, extra_special_slots);
    } else {
        signed_data = sign_thin_memory_with_slots(data, options, path, extra_special_slots);
    }
    write_result(path, signed_data, options);
}

inline void sign_file_impl(const std::filesystem::path& path, const SignOptions& options) {
    sign_file_with_slots_impl(path, options, {});
}

inline std::string requirement_display_string(const SignatureInfo& info) {
    // A synthesized identifier/OU expression is not necessarily the signed
    // designated requirement. CodeResources' requirement field is optional;
    // omit it until the original Requirements blob can be rendered losslessly.
    (void)info;
    return {};
}

inline std::vector<std::filesystem::path> outermost_nested_bundles(const std::filesystem::path& bundle);

inline std::unordered_set<std::string> make_nested_bundle_path_index(
        const std::vector<std::filesystem::path>& nested_bundles) {
    std::unordered_set<std::string> index;
    index.reserve(nested_bundles.size() * 2 + 1);
    for (const auto& nested : nested_bundles)
        index.insert(nested.lexically_normal().generic_string());
    return index;
}

inline bool has_indexed_bundle_ancestor(const std::filesystem::path& path,
                                       const std::unordered_set<std::string>& index,
                                       const std::filesystem::path* stop_at = nullptr) {
    const auto root = stop_at ? stop_at->lexically_normal() : std::filesystem::path();
    auto cursor = path.parent_path().lexically_normal();
    while (!cursor.empty()) {
        if (index.find(cursor.generic_string()) != index.end()) return true;
        if (stop_at && cursor == root) break;
        const auto parent = cursor.parent_path();
        if (parent == cursor) break;
        cursor = parent;
    }
    return false;
}

inline bool is_inside_indexed_nested_bundle(const std::filesystem::path& path,
                                           const std::filesystem::path& bundle,
                                           const std::unordered_set<std::string>& index) {
    return has_indexed_bundle_ancestor(path, index, &bundle);
}

inline void generate_code_resources_full_impl(const std::filesystem::path& bundle) {
    std::filesystem::path executable = archive::find_executable_in_bundle_impl(bundle);
    auto nested_bundles = outermost_nested_bundles(bundle);
    const auto nested_bundle_index = make_nested_bundle_path_index(nested_bundles);
    plist_t root = plist_new_dict();
    plist_t files = plist_new_dict();
    plist_t files2 = plist_new_dict();
    plist_t rules = plist_new_dict();
    plist_t rules2 = plist_new_dict();
    plist_dict_set_item(rules, ".*", plist_new_bool(1));
    plist_t lproj_rule = plist_new_dict();
    plist_dict_set_item(lproj_rule, "optional", plist_new_bool(1));
    plist_dict_set_item(lproj_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules, "^.*\\.lproj/", lproj_rule);
    plist_dict_set_item(rules2, ".*", plist_new_bool(1));
    plist_t ds_rule = plist_new_dict();
    plist_dict_set_item(ds_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(ds_rule, "weight", plist_new_uint(2000));
    plist_dict_set_item(rules2, "^(.*/)?\\.DS_Store$", ds_rule);
    plist_t info_rule = plist_new_dict();
    plist_dict_set_item(info_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(info_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^Info.plist$", info_rule);
    plist_t pkginfo_rule = plist_new_dict();
    plist_dict_set_item(pkginfo_rule, "omit", plist_new_bool(1));
    plist_dict_set_item(pkginfo_rule, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^PkgInfo$", pkginfo_rule);
    plist_t lproj_rule2 = plist_new_dict();
    plist_dict_set_item(lproj_rule2, "optional", plist_new_bool(1));
    plist_dict_set_item(lproj_rule2, "weight", plist_new_uint(1000));
    plist_dict_set_item(rules2, "^.*\\.lproj/", lproj_rule2);
    plist_t nested_rule = plist_new_dict();
    plist_dict_set_item(nested_rule, "nested", plist_new_bool(1));
    plist_dict_set_item(nested_rule, "weight", plist_new_uint(10));
    plist_dict_set_item(rules2, "^(Frameworks|SharedFrameworks|PlugIns|Plug-ins|XPCServices|Helpers|MacOS|Library/(Automator|Spotlight|LoginItems))/", nested_rule);
    plist_t top_rule = plist_new_dict();
    plist_dict_set_item(top_rule, "top", plist_new_bool(1));
    plist_dict_set_item(top_rule, "weight", plist_new_uint(0));
    plist_dict_set_item(rules2, "^[^/]+$", top_rule);
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        const auto path = iterator->path();
        if (!iterator->is_regular_file() && !iterator->is_symlink()) continue;
        if (path == executable || archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        if (is_inside_indexed_nested_bundle(path, bundle, nested_bundle_index)) continue;
        // Both paths are already rooted in this bundle; lexical relative avoids
        // filesystem canonicalization/stat work for every resource file.
        std::string relative = path.lexically_relative(bundle).generic_string();
        if (relative == ".DS_Store" || relative.rfind(".DS_Store/", 0) == 0) continue;
        bool optional = relative.find(".lproj/") != std::string::npos || (relative.size() >= 6 && relative.compare(relative.size() - 6, 6, ".lproj") == 0);
        plist_t v1 = nullptr;
        plist_t v2 = plist_new_dict();
        if (iterator->is_symlink()) {
            auto target = std::filesystem::read_symlink(path).generic_string();
            v1 = plist_new_dict();
            plist_dict_set_item(v1, "symlink", plist_new_string(target.c_str()));
            plist_dict_set_item(v2, "symlink", plist_new_string(target.c_str()));
        } else {
            auto data = read_bytes_local(path);
            auto sha1 = crypto::sha1_impl(data);
            auto sha256 = crypto::sha256_impl(data);
            v1 = plist_new_data(reinterpret_cast<const char*>(sha1.data()), static_cast<uint64_t>(sha1.size()));
            plist_dict_set_item(v2, "hash", plist_new_data(reinterpret_cast<const char*>(sha1.data()), static_cast<uint64_t>(sha1.size())));
            plist_dict_set_item(v2, "hash2", plist_new_data(reinterpret_cast<const char*>(sha256.data()), static_cast<uint64_t>(sha256.size())));
        }
        plist_dict_set_item(files, relative.c_str(), v1);
        if (optional) plist_dict_set_item(v2, "optional", plist_new_bool(1));
        if (relative != "Info.plist" && relative != "PkgInfo") plist_dict_set_item(files2, relative.c_str(), v2); else plist_free(v2);
    }
    for (const auto& nested : nested_bundles) {
            auto nested_exec = archive::find_executable_in_bundle_impl(nested);
            if (nested_exec.empty()) continue;
            auto nested_data = read_bytes_local(nested_exec);
            auto nested_info = macho::get_signature_info_impl(nested_data);
            if (nested_info.cd_hash.empty()) continue;
            auto relative = std::filesystem::relative(nested, bundle).generic_string();
            plist_t entry = plist_new_dict();
            plist_dict_set_item(entry, "cdhash", plist_new_data(reinterpret_cast<const char*>(nested_info.cd_hash.data()), static_cast<uint64_t>(nested_info.cd_hash.size())));
            auto requirement = requirement_display_string(nested_info);
            if (!requirement.empty()) plist_dict_set_item(entry, "requirement", plist_new_string(requirement.c_str()));
            plist_dict_set_item(files2, relative.c_str(), entry);
        }
    plist_dict_set_item(root, "files", files);
    plist_dict_set_item(root, "files2", files2);
    plist_dict_set_item(root, "rules", rules);
    plist_dict_set_item(root, "rules2", rules2);
    auto xml = plist_xml_bytes(root);
    plist_free(root);
    if (xml.empty()) throw std::runtime_error("failed to serialize CodeResources");
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    if (!write_bytes_local(code_resources, xml)) throw std::runtime_error("failed to write CodeResources");
}


inline bool validate_apple_internal_profile_file(const std::filesystem::path& profile_path,
                                                 bool require_der_encoded_profile,
                                                 std::string& diagnostic) {
    const auto bytes = read_bytes_local(profile_path);
    if (bytes.empty() || bytes.size() > static_cast<size_t>(LONG_MAX)) {
        diagnostic = "profile is empty or exceeds the supported DER size";
        return false;
    }
    const unsigned char* cursor = bytes.data();
    std::unique_ptr<PKCS7, decltype(&PKCS7_free)> p7(
        d2i_PKCS7(nullptr, &cursor, static_cast<long>(bytes.size())), PKCS7_free);
    if (!p7 || cursor != bytes.data() + bytes.size()) {
        diagnostic = "profile is not one complete DER PKCS#7 object";
        return false;
    }
    std::vector<uint8_t> plist_bytes;
    std::string cms_error;
    if (!crypto::verify_pkcs7_attached_impl(p7.get(), CertificateChainOptions{}, &plist_bytes, &cms_error)) {
        diagnostic = "profile CMS signature math check failed: " + cms_error;
        return false;
    }
    plist_t root = plist_from_xml_bytes(plist_bytes);
    if (!root || plist_get_node_type(root) != PLIST_DICT) {
        if (root) plist_free(root);
        diagnostic = "profile CMS content is not a plist dictionary";
        return false;
    }
    bool valid = true;
    plist_t internal = plist_dict_get_item(root, "AppleInternalProfile");
    uint8_t internal_flag = 0;
    if (!internal || plist_get_node_type(internal) != PLIST_BOOLEAN) {
        diagnostic = "profile does not contain a boolean AppleInternalProfile key";
        valid = false;
    } else {
        plist_get_bool_val(internal, &internal_flag);
        if (!internal_flag) {
            diagnostic = "AppleInternalProfile is not true";
            valid = false;
        }
    }
    plist_t expiration = plist_dict_get_item(root, "ExpirationDate");
    int64_t expiry = 0;
    if (!expiration || plist_get_node_type(expiration) != PLIST_DATE) {
        diagnostic = "profile has no valid ExpirationDate";
        valid = false;
    } else {
        plist_get_unix_date_val(expiration, &expiry);
        if (expiry <= static_cast<int64_t>(std::time(nullptr))) {
            diagnostic = "Apple internal provisioning profile has expired";
            valid = false;
        }
    }
    plist_t certs = plist_dict_get_item(root, "DeveloperCertificates");
    if (!certs || plist_get_node_type(certs) != PLIST_ARRAY || plist_array_get_size(certs) == 0) {
        diagnostic = "profile has no DeveloperCertificates entries";
        valid = false;
    }
    if (require_der_encoded_profile) {
        plist_t der = plist_dict_get_item(root, "DER-Encoded-Profile");
        char* der_bytes = nullptr;
        uint64_t der_length = 0;
        if (der && plist_get_node_type(der) == PLIST_DATA)
            plist_get_data_val(der, &der_bytes, &der_length);
        const bool has_der = der_bytes != nullptr && der_length != 0;
        if (der_bytes) free(der_bytes);
        if (!has_der) {
            diagnostic = "template requires DER-Encoded-Profile but profile does not contain it";
            valid = false;
        }
    }
    plist_free(root);
    if (valid) diagnostic = "CMS mathematics, AppleInternalProfile flag, expiration and DeveloperCertificates checks passed";
    return valid;
}

inline void prepare_apple_internal_profile_for_bundle(const std::filesystem::path& bundle,
                                                       const SignOptions& options) {
    if (!options.apple_internal_profile.enabled) return;
    std::string extension = bundle.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (extension != ".app" && extension != ".appex") return;

    const auto embedded_profile = bundle / "embedded.mobileprovision";
    // profilePath is the main .app profile source. Extensions are expected to
    // carry their own profile because their application-identifier is distinct.
    if (extension == ".app" && options.apple_internal_profile.embed_profile &&
        !options.apple_internal_profile.source_path.empty()) {
        const std::filesystem::path source(options.apple_internal_profile.source_path);
        std::string diagnostic;
        if (!validate_apple_internal_profile_file(source,
                options.apple_internal_profile.require_der_encoded_profile, diagnostic))
            throw std::runtime_error("Apple Internal profile source rejected: " + diagnostic);
        std::error_code source_ec, destination_ec;
        const auto source_absolute = std::filesystem::absolute(source, source_ec).lexically_normal();
        const auto destination_absolute = std::filesystem::absolute(embedded_profile, destination_ec).lexically_normal();
        if (source_ec || destination_ec)
            throw std::runtime_error("cannot normalize Apple Internal profile source/destination path");
        if (source_absolute != destination_absolute) {
            std::error_code copy_ec;
            std::filesystem::copy_file(source, embedded_profile,
                std::filesystem::copy_options::overwrite_existing, copy_ec);
            if (copy_ec) throw std::runtime_error("cannot embed Apple Internal profile: " + copy_ec.message());
        }
    }

    std::string diagnostic;
    if (!validate_apple_internal_profile_file(embedded_profile,
            options.apple_internal_profile.require_der_encoded_profile, diagnostic))
        throw std::runtime_error("Apple Internal profile required for " + bundle.string() + ": " + diagnostic);
}

inline std::vector<std::filesystem::path> outermost_nested_bundles(const std::filesystem::path& bundle) {
    std::vector<std::filesystem::path> candidates;
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        std::error_code ec;
        if (!iterator->is_directory(ec) || ec || iterator->path() == bundle ||
            !archive::is_signable_bundle_extension(iterator->path())) continue;
        candidates.push_back(iterator->path());
    }
    std::sort(candidates.begin(), candidates.end(), [](const auto& a, const auto& b) {
        const auto as = a.lexically_normal().generic_string();
        const auto bs = b.lexically_normal().generic_string();
        if (as.size() != bs.size()) return as.size() < bs.size();
        return as < bs;
    });
    std::vector<std::filesystem::path> selected;
    std::unordered_set<std::string> selected_index;
    selected_index.reserve(candidates.size() * 2 + 1);
    const auto root = bundle.lexically_normal();
    for (const auto& candidate : candidates) {
        bool nested = false;
        auto ancestor = candidate.parent_path().lexically_normal();
        while (!ancestor.empty()) {
            if (selected_index.find(ancestor.generic_string()) != selected_index.end()) {
                nested = true;
                break;
            }
            if (ancestor == root) break;
            const auto parent = ancestor.parent_path();
            if (parent == ancestor) break;
            ancestor = parent;
        }
        if (!nested) {
            selected.push_back(candidate);
            selected_index.insert(candidate.lexically_normal().generic_string());
        }
    }
    return selected;
}

inline SignOptions nested_sign_options_for_bundle(const std::filesystem::path& bundle, const SignOptions& options) {
    SignOptions nested = options;
    std::string extension = bundle.extension().string();
    std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    const bool carries_application_entitlements = extension == ".app" || extension == ".appex" || extension == ".xpc";
    if (!carries_application_entitlements) {
        nested.entitlements_path.clear();
        nested.merge_entitlements_path.clear();
        nested.preserve_entitlements = false;
    }
    return nested;
}

inline void sign_bundle_tree_impl_depth(const std::filesystem::path& bundle, const SignOptions& options, size_t remaining_depth) {
    prepare_apple_internal_profile_for_bundle(bundle, options);
    const SignOptions effective_options = nested_sign_options_for_bundle(bundle, options);
    // Use the same deterministic outermost-only bundle discovery as resource
    // sealing and verification; recursive_directory_iterator order is not stable.
    std::vector<std::filesystem::path> nested_bundles = outermost_nested_bundles(bundle);
    const auto nested_bundle_index = make_nested_bundle_path_index(nested_bundles);
    if (remaining_depth != 0) {
        const size_t child_depth = remaining_depth == std::numeric_limits<size_t>::max() ? remaining_depth : remaining_depth - 1;
        for (const auto& nested : nested_bundles) sign_bundle_tree_impl_depth(nested, options, child_depth);
    }
    std::filesystem::path executable = archive::find_executable_in_bundle_impl(bundle);
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); iterator != std::filesystem::recursive_directory_iterator(); ++iterator) {
        if (!iterator->is_regular_file()) continue;
        auto path = iterator->path();
        if (path == executable) continue;
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        if (is_inside_indexed_nested_bundle(path, bundle, nested_bundle_index)) continue;
        if (archive::is_macho_file_impl(path)) {
            if (options.sign_executables_only) {
                auto permissions = std::filesystem::status(path).permissions();
                if ((permissions & std::filesystem::perms::owner_exec) == std::filesystem::perms::none) continue;
            }
            sign_file_impl(path, effective_options);
        }
    }
    // CodeResources must be generated before the executable gets its final
    // signature, because its hash occupies special slot 3.
    generate_code_resources_full_impl(bundle);
    if (!executable.empty()) {
        std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
        std::vector<std::vector<uint8_t>> extra_slots(8);
        if (std::filesystem::exists(code_resources)) extra_slots[3] = read_bytes_local(code_resources);
        sign_file_with_slots_impl(executable, effective_options, extra_slots);
    }
}

inline void sign_bundle_tree_impl(const std::filesystem::path& bundle, const SignOptions& options) {
    const size_t remaining_depth = options.super_deep ? std::numeric_limits<size_t>::max() : (options.deep ? 1 : 0);
    sign_bundle_tree_impl_depth(bundle, options, remaining_depth);
}
inline ArchiveSignPlan build_sign_plan_impl(const std::filesystem::path& dir) {
    ArchiveSignPlan plan;
    plan.root_dir = dir.generic_string();
    auto entries = archive::scan_for_signables_impl(dir);
    for (auto& entry : entries) {
        std::filesystem::path path(entry.path);
        if (entry.is_directory) {
            auto extension = path.extension().string();
            std::transform(extension.begin(), extension.end(), extension.begin(), [](unsigned char c) {
                return static_cast<char>(std::tolower(c));
            });
            if (extension == ".app") {
                plan.bundle_paths.push_back(entry.path);
            } else if (extension == ".framework") {
                plan.framework_paths.push_back(entry.path);
            } else {
                plan.nested_bundle_paths.push_back(entry.path);
            }
        } else {
            plan.macho_paths.push_back(entry.path);
        }
    }
    return plan;
}

inline void sign_plan_impl(const ArchiveSignPlan& plan, const SignOptions& options) {
    std::unordered_set<std::string> signed_bundle_index;
    signed_bundle_index.reserve(plan.bundle_paths.size() + plan.framework_paths.size() + plan.nested_bundle_paths.size() + 1);
    const auto index_bundle_paths = [&](const std::vector<std::string>& paths) {
        for (const auto& path : paths) signed_bundle_index.insert(std::filesystem::path(path).lexically_normal().generic_string());
    };
    index_bundle_paths(plan.bundle_paths);
    index_bundle_paths(plan.framework_paths);
    index_bundle_paths(plan.nested_bundle_paths);
    for (auto& framework : plan.framework_paths) {
        sign_bundle_tree_impl(framework, options);
    }
    for (auto& nested : plan.nested_bundle_paths) {
        sign_bundle_tree_impl(nested, options);
    }
    for (auto& bundle : plan.bundle_paths) {
        sign_bundle_tree_impl(bundle, options);
    }
    std::vector<std::string> independent_machos;
    for (const auto& macho : plan.macho_paths) {
        if (has_indexed_bundle_ancestor(std::filesystem::path(macho), signed_bundle_index)) continue;
        if (options.sign_executables_only) {
            auto permissions = std::filesystem::status(macho).permissions();
            if ((permissions & std::filesystem::perms::owner_exec) == std::filesystem::perms::none) continue;
        }
        independent_machos.push_back(macho);
    }
    const size_t jobs = effective_sign_jobs(options, independent_machos.size());
    if (jobs <= 1) {
        for (const auto& macho : independent_machos) sign_file_impl(macho, options);
    } else {
        std::atomic<size_t> next{0};
        std::mutex failure_mutex;
        std::exception_ptr failure;
        std::vector<std::thread> workers;
        workers.reserve(jobs);
        for (size_t worker = 0; worker < jobs; ++worker) workers.emplace_back([&] {
            for (;;) {
                const size_t index = next.fetch_add(1, std::memory_order_relaxed);
                if (index >= independent_machos.size()) break;
                try { sign_file_impl(independent_machos[index], options); }
                catch (...) { std::lock_guard<std::mutex> lock(failure_mutex); if (!failure) failure = std::current_exception(); }
            }
        });
        for (auto& worker : workers) worker.join();
        if (failure) std::rethrow_exception(failure);
    }
}

inline void sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    if (options.merge_only) {
        if (std::filesystem::is_directory(path) || archive::is_archive_impl(path)) {
            SignOptions merged = options;
            merged.preserve_entitlements = true;
            merged.identifier.clear();
            merged.team_id.clear();
            merged.requirements_path.clear();
            merged.overall_requirements_path.clear();
            merged.requirements_xml.clear();
            if (!options.merge_entitlements_path.empty()) { merged.entitlements_path.clear(); }
            else if (!options.entitlements_path.empty()) { merged.merge_entitlements_path = options.entitlements_path; merged.entitlements_path.clear(); }
            merged.merge_only = false;
            if (std::filesystem::is_directory(path)) {
                if (archive::is_signable_bundle_extension(path)) sign_bundle_tree_impl(path, merged);
                else sign_plan_impl(build_sign_plan_impl(path), merged);
            } else if (archive::is_archive_impl(path)) {
                const auto output = resolve_output_path(path, merged);
                archive::stream_sign_impl(path, output.empty() ? path : output, merged);
            }
            return;
        }
        auto current = read_bytes_local(path);
        if (!macho::is_macho_impl(current)) {
            throw std::invalid_argument("-M requires a Mach-O input");
        }

        /*
         * Procursus/original ldid semantics:
         *
         *   -S -M -Kcert.p12 file
         *
         * with no entitlement file means: preserve the entitlements already
         * embedded in the input and re-sign it.  -M is a merge modifier; it
         * does not require an external entitlement source.
         *
         * When an explicit entitlement source is supplied, merge it over the
         * existing embedded entitlements.  Keeping this distinction here is
         * important because TrollStore invokes exactly the no-source form.
         */
        SignOptions merged = options;
        merged.preserve_entitlements = true;
        merged.identifier.clear();
        merged.team_id.clear();
        merged.requirements_path.clear();
        merged.overall_requirements_path.clear();
        merged.requirements_xml.clear();

        if (!options.merge_entitlements_path.empty()) {
            merged.merge_entitlements_path = options.merge_entitlements_path;
            merged.entitlements_path.clear();
        } else if (!options.entitlements_path.empty()) {
            merged.merge_entitlements_path = options.entitlements_path;
            merged.entitlements_path.clear();
        } else {
            // TrollStore: -S -M with no external entitlement file.
            // resolve_entitlements_xml() will return existing embedded XML.
            merged.merge_entitlements_path.clear();
            merged.entitlements_path.clear();
        }

        merged.merge_only = false;
        sign_file_impl(path, merged);
        return;
    }
    if (std::filesystem::is_directory(path)) {
        if (archive::is_signable_bundle_extension(path)) {
            sign_bundle_tree_impl(path, options);
        } else {
            auto plan = build_sign_plan_impl(path);
            sign_plan_impl(plan, options);
        }
        return;
    }
    if (archive::is_archive_impl(path)) {
        archive::stream_sign_impl(path, resolve_output_path(path, options), options);
        return;
    }
    sign_file_impl(path, options);
}

inline std::vector<uint8_t> unsign_memory_impl(const std::vector<uint8_t>& data) {
    return macho::strip_signature_impl(data);
}

inline void reset_cryptid_impl(const std::filesystem::path& path) {
    auto data = read_bytes_local(path);
    auto slices = macho::parse_slices_impl(data);
    if (slices.empty()) throw std::invalid_argument("invalid Mach-O");
    std::vector<std::vector<uint8_t>> rewritten;
    rewritten.reserve(slices.size());
    for (const auto& slice : slices) {
        auto slice_data = std::vector<uint8_t>(data.begin() + static_cast<std::ptrdiff_t>(slice.offset), data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        auto header = macho::parse_header(slice_data, 0);
        if (!header.valid) throw std::invalid_argument("invalid Mach-O slice");
        auto commands = macho::enumerate_load_commands(slice_data, header, 0);
        for (const auto& command : commands) {
            if (command.cmd == 0x21U && command.cmdsize >= 20) write_u32_file(slice_data.data() + command.offset + 16, 0, header.big);
            if (command.cmd == 0x2CU && command.cmdsize >= 24) write_u32_file(slice_data.data() + command.offset + 16, 0, header.big);
        }
        rewritten.push_back(std::move(slice_data));
    }
    std::vector<uint8_t> output;
    if (slices.size() == 1 && slices.front().offset == 0 && slices.front().size == data.size()) output = std::move(rewritten.front());
    else output = macho::rebuild_fat_with_format_impl(rewritten, slices.front().fat64_container, slices.front().fat_cigam_container, slices);
    if (!write_bytes_local(path, output)) throw std::runtime_error("failed to write cryptid reset");
}

inline void unsign_impl(const std::filesystem::path& path) {
    auto data = read_bytes_local(path);
    if (data.empty()) throw std::runtime_error("cannot read input for signature removal: " + path.string());
    auto stripped = unsign_memory_impl(data);
    if (!write_bytes_atomic_local(path, stripped)) throw std::runtime_error("failed to atomically write unsigned file: " + path.string());
}

inline void unsign_deep_impl(const std::filesystem::path& path) {
    if (std::filesystem::is_regular_file(path)) { unsign_impl(path); return; }
    if (!std::filesystem::is_directory(path)) throw std::invalid_argument("--strip-codesig --deep expects a Mach-O file or directory/Bundle");
    std::vector<std::filesystem::path> binaries;
    std::vector<std::filesystem::path> signature_dirs;
    for (auto it = std::filesystem::recursive_directory_iterator(path, std::filesystem::directory_options::skip_permission_denied);
         it != std::filesystem::recursive_directory_iterator(); ++it) {
        std::error_code ec;
        if (it->is_symlink(ec)) { if (it->is_directory(ec)) it.disable_recursion_pending(); continue; }
        if (it->is_directory(ec) && it->path().filename() == "_CodeSignature") {
            signature_dirs.push_back(it->path());
            it.disable_recursion_pending();
            continue;
        }
        if (it->is_regular_file(ec) && archive::is_macho_file_impl(it->path())) binaries.push_back(it->path());
    }
    std::sort(binaries.begin(), binaries.end());
    for (const auto& binary : binaries) unsign_impl(binary);
    std::sort(signature_dirs.begin(), signature_dirs.end(), [](const auto& a, const auto& b) { return a.native().size() > b.native().size(); });
    for (const auto& directory : signature_dirs) {
        std::error_code ec;
        std::filesystem::remove_all(directory, ec);
        if (ec) throw std::runtime_error("failed to remove signature resources '" + directory.string() + "': " + ec.message());
    }
}

inline void deep_sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    sign_impl(path, options);
}

inline void super_deep_sign_impl(const std::filesystem::path& path, const SignOptions& options) {
    SignOptions adjusted = options;
    adjusted.deep = true;
    adjusted.super_deep = true;
    sign_impl(path, adjusted);
}

inline void merge_entitlements_impl(const std::filesystem::path& path, const SignOptions& options) {
    SignOptions adjusted = options;
    adjusted.preserve_entitlements = true;
    adjusted.merge_only = true;
    sign_impl(path, adjusted);
}

inline void replace_path_transactionally(const std::filesystem::path& staged, const std::filesystem::path& target) {
    static std::atomic<uint64_t> sequence{0};
    std::error_code ec;
    if (target.has_parent_path()) std::filesystem::create_directories(target.parent_path(), ec);
    if (ec) throw std::runtime_error("cannot create output directory: " + ec.message());
    const auto backup = target.string() + ".ldid-backup-" + std::to_string(sequence.fetch_add(1, std::memory_order_relaxed));
    const bool had_target = std::filesystem::exists(target, ec) && !ec;
    if (had_target) {
        std::filesystem::rename(target, backup, ec);
        if (ec) throw std::runtime_error("cannot move existing output to transaction backup: " + ec.message());
    }
    std::filesystem::rename(staged, target, ec);
    if (ec) {
        const std::string failure = ec.message();
        if (had_target) {
            std::error_code restore;
            std::filesystem::rename(backup, target, restore);
            if (restore) throw std::runtime_error("output commit failed and backup restore also failed: " + failure + "; restore: " + restore.message());
        }
        throw std::runtime_error("output transaction commit failed: " + failure);
    }
    if (had_target) std::filesystem::remove_all(backup, ec);
}

inline void sign_ipa_impl(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options) {
    const auto final_output = out.empty() ? ipa : out;
    const auto work_dir = make_temp_dir();
    const auto staged_output = make_unique_temp_path(final_output, ".ldid-staged");
    try {
        archive::extract_ipa_impl(ipa, work_dir);
        auto plan = build_sign_plan_impl(work_dir);
        sign_plan_impl(plan, options);
        archive::repack_ipa_impl(work_dir, staged_output);
        replace_path_transactionally(staged_output, final_output);
        std::error_code ec;
        std::filesystem::remove_all(work_dir, ec);
    } catch (...) {
        std::error_code ec;
        std::filesystem::remove_all(work_dir, ec);
        std::filesystem::remove(staged_output, ec);
        throw;
    }
}

inline void sign_archive_impl(const std::filesystem::path& archive_path, const std::filesystem::path& out, const SignOptions& options) {
    const auto final_output = out.empty() ? archive_path : out;
    const auto work_dir = make_temp_dir();
    const auto staged_output = make_unique_temp_path(final_output, ".ldid-staged");
    try {
        archive::extract_archive_impl(archive_path, work_dir);
        auto plan = build_sign_plan_impl(work_dir);
        sign_plan_impl(plan, options);
        archive::create_archive_impl(work_dir, staged_output, archive::detect_format_impl(archive_path));
        replace_path_transactionally(staged_output, final_output);
        std::error_code ec;
        std::filesystem::remove_all(work_dir, ec);
    } catch (...) {
        std::error_code ec;
        std::filesystem::remove_all(work_dir, ec);
        std::filesystem::remove(staged_output, ec);
        throw;
    }
}

inline void sign_bundle_impl(const std::filesystem::path& bundle, const SignOptions& options) {
    sign_bundle_tree_impl(bundle, options);
}

}

}
#include "ldid.hpp"
#include <openssl/x509_vfy.h>

namespace ldid {

namespace verifier {

struct SuperBlobParseResult {
    bool valid = false;
    uint32_t magic = 0;
    uint32_t length = 0;
    std::map<uint32_t, std::vector<uint8_t>> slots;
    std::vector<uint8_t> cms;
};

inline SuperBlobParseResult parse_superblob(const std::vector<uint8_t>& signature) {
    SuperBlobParseResult result;
    if (signature.size() < 12) return result;
    const uint32_t magic = load_be32(signature.data());
    if (magic != macho::SUPERBLOB_MAGIC && magic != 0xfade0b02U && magic != 0xfade0cc1U) return result;
    result.magic = magic;
    const uint32_t length = load_be32(signature.data() + 4);
    const uint32_t count = load_be32(signature.data() + 8);
    if (length < 12 || length > signature.size() || count > (length - 12) / 8) return result;
    const uint64_t index_end = 12ULL + static_cast<uint64_t>(count) * 8ULL;
    std::vector<std::pair<uint64_t, uint64_t>> ranges;
    std::set<uint32_t> types;
    std::set<uint32_t> offsets;
    for (uint32_t i = 0; i < count; ++i) {
        const size_t index_pos = 12U + static_cast<size_t>(i) * 8U;
        const uint32_t type = load_be32(signature.data() + index_pos);
        const uint32_t offset = load_be32(signature.data() + index_pos + 4);
        if (!types.insert(type).second || !offsets.insert(offset).second) return result;
        if (offset < index_end || offset > length || length - offset < 8) return result;
        const uint32_t blob_magic = load_be32(signature.data() + offset);
        const uint32_t blob_length = load_be32(signature.data() + offset + 4);
        if (blob_length < 8 || blob_length > length - offset) return result;
        if (type == 0 && blob_magic != macho::CODEDIRECTORY_MAGIC) return result;
        if (type >= static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) &&
            type < static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) + 5U && blob_magic != macho::CODEDIRECTORY_MAGIC) return result;
        if (type == 2 && blob_magic != 0xfade0c01U) return result;
        if (type == 5 && blob_magic != 0xfade7171U) return result;
        if (type == 7 && blob_magic != 0xfade7172U) return result;
        if (type >= 8 && type <= 11 && blob_magic != 0xfade8181U) return result;
        if (type == static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE) && blob_magic != 0xfade0b01U) return result;
        ranges.emplace_back(offset, static_cast<uint64_t>(offset) + blob_length);
        auto whole = macho::whole_blob(signature, offset);
        if (whole.size() != blob_length) return result;
        result.slots.emplace(type, std::move(whole));
        if (type == static_cast<uint32_t>(CodeSignSlot::CMS_SIGNATURE)) result.cms = macho::blob_content(signature, offset);
    }
    std::sort(ranges.begin(), ranges.end());
    for (size_t i = 1; i < ranges.size(); ++i) {
        if (ranges[i].first < ranges[i - 1].second) return result;
    }
    result.length = length;
    result.valid = true;
    return result;
}

struct CodeDirectoryView {
    std::vector<uint8_t> blob;
    uint32_t version = 0;
    uint32_t flags = 0;
    uint32_t hash_offset = 0;
    uint32_t ident_offset = 0;
    uint32_t n_special = 0;
    uint32_t n_code = 0;
    uint64_t code_limit = 0;
    uint8_t hash_size = 0;
    uint8_t hash_type = 0;
    uint8_t platform = 0;
    uint8_t page_size_exp = 0;
    uint32_t scatter_offset = 0;
    uint32_t team_offset = 0;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint64_t exec_seg_flags = 0;
    uint32_t runtime = 0;
    uint32_t pre_encrypt_offset = 0;
    uint8_t linkage_hash_type = 0;
    uint8_t linkage_application_type = 0;
    uint16_t linkage_application_subtype = 0;
    uint32_t linkage_offset = 0;
    uint32_t linkage_size = 0;
    std::string identifier;
    std::string team_id;
};

inline std::optional<CodeDirectoryView> parse_code_directory(const std::vector<uint8_t>& blob) {
    if (blob.size() < 44 || load_be32(blob.data()) != macho::CODEDIRECTORY_MAGIC) return std::nullopt;
    CodeDirectoryView view;
    view.blob = blob;
    const uint32_t declared_length = load_be32(blob.data() + 4);
    view.version = load_be32(blob.data() + 8);
    if (declared_length != blob.size() || view.version < 0x20001 || view.version > 0x20600) return std::nullopt;
    view.flags = load_be32(blob.data() + 12);
    view.hash_offset = load_be32(blob.data() + 16);
    view.ident_offset = load_be32(blob.data() + 20);
    view.n_special = load_be32(blob.data() + 24);
    view.n_code = load_be32(blob.data() + 28);
    view.code_limit = load_be32(blob.data() + 32);
    view.hash_size = blob[36];
    view.hash_type = blob[37];
    view.platform = blob[38];
    view.page_size_exp = blob[39];
    if (view.version >= 0x20100) {
        if (blob.size() < 48) return std::nullopt;
        view.scatter_offset = load_be32(blob.data() + 44);
    }
    if (view.version >= 0x20200) {
        if (blob.size() < 52) return std::nullopt;
        view.team_offset = load_be32(blob.data() + 48);
    }
    if (view.version >= 0x20300) {
        if (blob.size() < 64) return std::nullopt;
        view.code_limit = load_be64(blob.data() + 56);
    }
    if (view.version >= 0x20400) {
        if (blob.size() < 88) return std::nullopt;
        view.exec_seg_base = load_be64(blob.data() + 64);
        view.exec_seg_limit = load_be64(blob.data() + 72);
        view.exec_seg_flags = load_be64(blob.data() + 80);
    }
    if (view.version >= 0x20500) {
        if (blob.size() < 96) return std::nullopt;
        view.runtime = load_be32(blob.data() + 88);
        view.pre_encrypt_offset = load_be32(blob.data() + 92);
    }
    if (view.version >= 0x20600) {
        if (blob.size() < 108) return std::nullopt;
        view.linkage_hash_type = blob[96];
        view.linkage_application_type = blob[97];
        view.linkage_application_subtype = static_cast<uint16_t>((static_cast<uint16_t>(blob[98]) << 8) | blob[99]);
        view.linkage_offset = load_be32(blob.data() + 100);
        view.linkage_size = load_be32(blob.data() + 104);
    }
    const uint8_t expected_hash_size = view.hash_type == 1 ? 20 : (view.hash_type == 2 ? 32 : (view.hash_type == 3 ? 20 : (view.hash_type == 4 ? 48 : 0)));
    if (expected_hash_size == 0 || view.hash_size != expected_hash_size) return std::nullopt;
    if (view.page_size_exp > 20) return std::nullopt;
    const size_t minimum_header = view.version >= 0x20600 ? 108 : (view.version >= 0x20500 ? 96 : (view.version >= 0x20400 ? 88 : (view.version >= 0x20300 ? 64 : (view.version >= 0x20200 ? 52 : (view.version >= 0x20100 ? 48 : 44)))));
    if (blob.size() < minimum_header || view.hash_offset < minimum_header || view.hash_offset > blob.size()) return std::nullopt;
    if (load_be32(blob.data() + 40) != 0) return std::nullopt; // spare2 is reserved
    if (view.version >= 0x20300 && load_be32(blob.data() + 52) != 0) return std::nullopt; // spare3 is reserved
    const uint64_t special_bytes = static_cast<uint64_t>(view.n_special) * view.hash_size;
    const uint64_t code_bytes = static_cast<uint64_t>(view.n_code) * view.hash_size;
    if (special_bytes > view.hash_offset || code_bytes > blob.size() - view.hash_offset) return std::nullopt;
    const uint64_t special_start = static_cast<uint64_t>(view.hash_offset) - special_bytes;
    if (view.ident_offset < minimum_header || view.ident_offset >= special_start) return std::nullopt;
    const size_t ident_end = std::find(blob.begin() + view.ident_offset, blob.begin() + static_cast<std::ptrdiff_t>(special_start), static_cast<uint8_t>(0)) - blob.begin();
    if (ident_end >= special_start) return std::nullopt;
    view.identifier.assign(reinterpret_cast<const char*>(blob.data() + view.ident_offset), ident_end - view.ident_offset);
    if (view.team_offset != 0) {
        if (view.version < 0x20200 || view.team_offset < minimum_header || view.team_offset >= special_start || view.team_offset <= ident_end) return std::nullopt;
        const void* end = std::memchr(blob.data() + view.team_offset, 0, static_cast<size_t>(special_start - view.team_offset));
        if (!end) return std::nullopt;
        view.team_id.assign(reinterpret_cast<const char*>(blob.data() + view.team_offset), static_cast<const uint8_t*>(end) - (blob.data() + view.team_offset));
    }
    if (view.scatter_offset != 0) {
        if (view.version < 0x20100 || view.page_size_exp == 0 || view.scatter_offset < minimum_header || view.scatter_offset >= special_start) return std::nullopt;
        bool sentinel = false;
        size_t pos = view.scatter_offset;
        std::set<uint64_t> scatter_slots;
        while (pos <= special_start && special_start - pos >= 24) {
            const uint32_t count = load_be32(blob.data() + pos);
            const uint32_t base = load_be32(blob.data() + pos + 4);
            const uint64_t target = load_be64(blob.data() + pos + 8);
            const uint64_t spare = load_be64(blob.data() + pos + 16);
            if (spare != 0) return std::nullopt;
            pos += 24;
            if (count == 0) { sentinel = true; break; }
            if (static_cast<uint64_t>(base) + count > view.n_code || target > view.code_limit) return std::nullopt;
            for (uint32_t i = 0; i < count; ++i) if (!scatter_slots.insert(static_cast<uint64_t>(base) + i).second) return std::nullopt;
        }
        if (!sentinel || pos > special_start) return std::nullopt;
        if (!scatter_slots.empty() && *scatter_slots.rbegin() + 1 != view.n_code) return std::nullopt;
    }
    const uint64_t code_hash_end = static_cast<uint64_t>(view.hash_offset) + code_bytes;
    uint64_t pre_encrypt_end = code_hash_end;
    if (view.pre_encrypt_offset != 0) {
        const uint64_t pre_size = static_cast<uint64_t>(view.n_code) * view.hash_size;
        if (view.version < 0x20500 || view.pre_encrypt_offset < code_hash_end ||
            view.pre_encrypt_offset > blob.size() || pre_size > blob.size() - view.pre_encrypt_offset) return std::nullopt;
        pre_encrypt_end = static_cast<uint64_t>(view.pre_encrypt_offset) + pre_size;
    }
    if (view.linkage_size != 0) {
        if (view.version < 0x20600 || view.linkage_offset < pre_encrypt_end ||
            view.linkage_offset > blob.size() || view.linkage_size > blob.size() - view.linkage_offset) return std::nullopt;
    } else if (view.linkage_offset != 0) {
        return std::nullopt;
    }
    return view;
}

inline bool stored_hash_is_zero(const std::vector<uint8_t>& blob, size_t offset, size_t size) {
    if (offset + size > blob.size()) return true;
    for (size_t i = 0; i < size; ++i) {
        if (blob[offset + i] != 0) return false;
    }
    return true;
}

struct RequirementFacts {
    bool valid = false;
    bool has_identifier = false;
    bool has_team = false;
    std::string identifier;
    std::string team_id;
};

inline bool parse_requirement_expression_facts(const std::vector<uint8_t>& data, size_t& pos, RequirementFacts& facts) {
    if (pos > data.size() || data.size() - pos < 4) return false;
    const uint32_t op = load_be32(data.data() + pos);
    pos += 4;
    auto has = [op](RequirementOpcode value) { return op == requirement_opcode_value(value); };
    auto read_string = [&](std::string& out) -> bool {
        if (pos > data.size() || data.size() - pos < 4) return false;
        const uint32_t len = load_be32(data.data() + pos);
        pos += 4;
        if (len > data.size() - pos) return false;
        out.assign(reinterpret_cast<const char*>(data.data() + pos), len);
        pos += len;
        while ((pos & 3U) != 0) {
            if (pos >= data.size()) return false;
            ++pos;
        }
        return true;
    };
    if (has(RequirementOpcode::FALSE_EXPR) || has(RequirementOpcode::TRUE_EXPR) ||
        has(RequirementOpcode::APPLE_ANCHOR) || has(RequirementOpcode::APPLE_GENERIC_ANCHOR) ||
        has(RequirementOpcode::TRUSTED_CERTS) || has(RequirementOpcode::NOTARIZED) ||
        has(RequirementOpcode::LEGACY_DEVID)) return true;
    if (has(RequirementOpcode::IDENTIFIER)) {
        std::string value;
        if (!read_string(value)) return false;
        facts.identifier = value;
        facts.has_identifier = true;
        return true;
    }
    if (has(RequirementOpcode::ANCHOR_HASH) || has(RequirementOpcode::CDHASH)) {
        if (data.size() - pos < 20) return false;
        pos += 20;
        return true;
    }
    if (has(RequirementOpcode::AND_EXPR) || has(RequirementOpcode::OR_EXPR)) {
        RequirementFacts left, right;
        if (!parse_requirement_expression_facts(data, pos, left) ||
            !parse_requirement_expression_facts(data, pos, right)) return false;
        if (has(RequirementOpcode::AND_EXPR)) {
            if (left.has_identifier) { facts.identifier = left.identifier; facts.has_identifier = true; }
            if (right.has_identifier) { facts.identifier = right.identifier; facts.has_identifier = true; }
            if (left.has_team) { facts.team_id = left.team_id; facts.has_team = true; }
            if (right.has_team) { facts.team_id = right.team_id; facts.has_team = true; }
        } else {
            if (left.has_identifier && right.has_identifier && left.identifier == right.identifier) {
                facts.identifier = left.identifier; facts.has_identifier = true;
            }
            if (left.has_team && right.has_team && left.team_id == right.team_id) {
                facts.team_id = left.team_id; facts.has_team = true;
            }
        }
        return true;
    }
    if (has(RequirementOpcode::NOT_EXPR)) {
        // Facts inside a negated expression are not positive constraints on
        // the signing identifier/team, so parse for structural validity only.
        RequirementFacts ignored;
        return parse_requirement_expression_facts(data, pos, ignored);
    }
    if (has(RequirementOpcode::INFO_KEY_VALUE)) {
        std::string key, value;
        return read_string(key) && read_string(value);
    }
    if (has(RequirementOpcode::INFO_KEY_FIELD) || has(RequirementOpcode::ENTITLEMENT_FIELD)) {
        std::string field;
        if (!read_string(field) || data.size() - pos < 4) return false;
        const uint32_t match = load_be32(data.data() + pos);
        pos += 4;
        if (match != 0 && match != 14) {
            std::string value;
            if (!read_string(value)) return false;
        }
        return true;
    }
    if (has(RequirementOpcode::CERT_FIELD) || has(RequirementOpcode::CERT_FIELD_DATE)) {
        if (data.size() - pos < 4) return false;
        const uint32_t cert_index = load_be32(data.data() + pos);
        pos += 4;
        std::string field;
        if (!read_string(field) || data.size() - pos < 4) return false;
        const uint32_t match = load_be32(data.data() + pos);
        pos += 4;
        std::string value;
        if (match != 0 && match != 14 && !read_string(value)) return false;
        if (cert_index == 0 && field == "subject.OU" && match == 1) {
            facts.team_id = value;
            facts.has_team = true;
        }
        return true;
    }
    if (has(RequirementOpcode::TRUSTED_CERT)) {
        if (data.size() - pos < 4) return false;
        pos += 4;
        return true;
    }
    if (has(RequirementOpcode::CERT_GENERIC) || has(RequirementOpcode::CERT_POLICY)) {
        if (data.size() - pos < 4) return false;
        pos += 4; // certificate index
        std::string oid;
        if (!read_string(oid) || data.size() - pos < 4) return false;
        const uint32_t match = load_be32(data.data() + pos);
        pos += 4;
        if (match != 0 && match != 14) {
            std::string value;
            if (!read_string(value)) return false;
        }
        return true;
    }
    if (has(RequirementOpcode::NAMED_ANCHOR) || has(RequirementOpcode::NAMED_CODE)) {
        std::string name;
        return read_string(name);
    }
    if (has(RequirementOpcode::PLATFORM)) {
        if (data.size() - pos < 4) return false;
        pos += 4;
        return true;
    }
    return false;
}
inline RequirementFacts parse_designated_requirement_facts(const std::vector<uint8_t>& blob) {
    RequirementFacts facts;
    if (blob.size() < 20 || load_be32(blob.data()) != macho::REQUIREMENTS_MAGIC) return facts;
    const uint32_t count = load_be32(blob.data() + 8);
    if (count == 0 || static_cast<uint64_t>(count) > (blob.size() - 12) / 8) return facts;
    bool found = false;
    for (uint32_t i = 0; i < count; ++i) {
        const size_t entry = 12 + static_cast<size_t>(i) * 8;
        if (entry > blob.size() || blob.size() - entry < 8) return facts;
        const uint32_t type = load_be32(blob.data() + entry);
        const size_t offset = load_be32(blob.data() + entry + 4);
        if (type != 3) continue;
        if (offset > blob.size() || blob.size() - offset < 12) return facts;
        const uint32_t magic = load_be32(blob.data() + offset);
        const size_t length = load_be32(blob.data() + offset + 4);
        const uint32_t kind = load_be32(blob.data() + offset + 8);
        if (magic != 0xfade0c00U || kind != 1 || length < 12 || length > blob.size() - offset) return facts;
        const size_t expression_end = offset + length;
        size_t pos = offset + 12;
        if (!parse_requirement_expression_facts(blob, pos, facts) || pos != expression_end) return facts;
        found = true;
        break;
    }
    facts.valid = found;
    return facts;
}

inline VerificationResult verify_thin_memory(const std::vector<uint8_t>& data, const VerificationOptions& verify_options = {}) {
    VerificationResult result;
    result.ok = false;
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid) {
        result.message = "invalid Mach-O";
        result.errors.push_back("invalid Mach-O");
        return result;
    }
    if (analysis.code_signature_size == 0 || analysis.code_signature_offset == 0) {
        result.message = "no embedded signature";
        result.errors.push_back("no embedded signature");
        return result;
    }
    if (analysis.code_signature_offset + analysis.code_signature_size > data.size()) {
        result.message = "signature out of bounds";
        result.errors.push_back("signature out of bounds");
        return result;
    }
    std::vector<uint8_t> signature(data.begin() + analysis.code_signature_offset,
                                   data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    auto parsed = parse_superblob(signature);
    if (!parsed.valid) {
        result.message = "invalid superblob";
        result.errors.push_back("invalid superblob");
        return result;
    }
    auto cd_iterator = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
    if (cd_iterator == parsed.slots.end()) {
        result.message = "missing CodeDirectory";
        result.errors.push_back("missing CodeDirectory");
        return result;
    }
    auto cd_optional = parse_code_directory(cd_iterator->second);
    if (!cd_optional) {
        result.message = "invalid CodeDirectory";
        result.errors.push_back("invalid CodeDirectory");
        return result;
    }
    auto cd = *cd_optional;
    auto hash_type_for_view = [](const CodeDirectoryView& view) -> HashType {
        switch (view.hash_type) {
            case 1: return HashType::SHA1;
            case 2: return HashType::SHA256;
            case 3: return HashType::SHA256_TRUNCATED;
            case 4: return HashType::SHA384;
            default: throw std::runtime_error("unsupported CodeDirectory hash type");
        }
    };
    auto verify_code_directory = [&](const CodeDirectoryView& view, std::string& error) -> bool {
        if (view.code_limit > analysis.code_signature_offset || view.code_limit > data.size()) {
            error = "CodeDirectory codeLimit out of bounds";
            return false;
        }
        const HashType hash_type_local = hash_type_for_view(view);
        const uint64_t page_size = view.page_size_exp == 0 ? std::max<uint64_t>(view.code_limit, 1ULL) : (1ULL << view.page_size_exp);
        if (view.page_size_exp == 0 && view.n_code != (view.code_limit == 0 ? 0U : 1U)) {
            error = "infinite-page CodeDirectory must contain exactly one code slot for non-empty code";
            return false;
        }
        if (view.scatter_offset == 0) {
            const uint64_t expected_slots = view.code_limit == 0 ? 0 : (view.code_limit + page_size - 1) / page_size;
            if (expected_slots != view.n_code) {
                error = "CodeDirectory code slot count mismatch";
                return false;
            }
            for (uint64_t slot = 0; slot < view.n_code; ++slot) {
                const uint64_t start64 = slot * page_size;
                const uint64_t length64 = std::min<uint64_t>(page_size, view.code_limit - start64);
                if (start64 > data.size() || length64 > data.size() - start64) {
                    error = "CodeDirectory page range out of bounds";
                    return false;
                }
                const auto digest = crypto::hash_impl(hash_type_local,
                    std::vector<uint8_t>(data.begin() + static_cast<std::ptrdiff_t>(start64),
                                         data.begin() + static_cast<std::ptrdiff_t>(start64 + length64)));
                const uint64_t offset64 = static_cast<uint64_t>(view.hash_offset) + slot * view.hash_size;
                if (offset64 > view.blob.size() || view.hash_size > view.blob.size() - offset64 || digest.size() < view.hash_size ||
                    !std::equal(digest.begin(), digest.begin() + view.hash_size, view.blob.begin() + static_cast<std::ptrdiff_t>(offset64))) {
                    error = "code hash mismatch at slot " + std::to_string(slot);
                    return false;
                }
            }
        } else {
            if (view.page_size_exp == 0) {
                error = "scatter CodeDirectory cannot use infinite page size";
                return false;
            }
            std::set<uint64_t> assigned;
            uint64_t max_slot = 0;
            size_t pos = view.scatter_offset;
            bool sentinel = false;
            const uint64_t hash_table_end = static_cast<uint64_t>(view.hash_offset) - static_cast<uint64_t>(view.n_special) * view.hash_size;
            while (pos <= view.blob.size() && view.blob.size() - pos >= 24) {
                const uint32_t count = load_be32(view.blob.data() + pos);
                const uint32_t base = load_be32(view.blob.data() + pos + 4);
                const uint64_t target = load_be64(view.blob.data() + pos + 8);
                const uint64_t spare = load_be64(view.blob.data() + pos + 16);
                pos += 24;
                if (count == 0) { sentinel = true; break; }
                if (spare != 0 || static_cast<uint64_t>(base) + count > view.n_code) {
                    error = "invalid CodeDirectory scatter record";
                    return false;
                }
                if (target > view.code_limit) {
                    error = "scatter target offset exceeds codeLimit";
                    return false;
                }
                for (uint32_t i = 0; i < count; ++i) {
                    const uint64_t slot = static_cast<uint64_t>(base) + i;
                    const uint64_t start = target + static_cast<uint64_t>(i) * page_size;
                    if (!assigned.insert(slot).second || start > view.code_limit || start > data.size()) {
                        error = "overlapping or out-of-range scatter page";
                        return false;
                    }
                    const uint64_t length = std::min<uint64_t>(page_size, view.code_limit - start);
                    if (length > data.size() - start) {
                        error = "scatter page range exceeds Mach-O";
                        return false;
                    }
                    const auto digest = crypto::hash_impl(hash_type_local,
                        std::vector<uint8_t>(data.begin() + static_cast<std::ptrdiff_t>(start),
                                             data.begin() + static_cast<std::ptrdiff_t>(start + length)));
                    const uint64_t hash_pos = static_cast<uint64_t>(view.hash_offset) + slot * view.hash_size;
                    if (hash_pos > view.blob.size() || view.hash_size > view.blob.size() - hash_pos || digest.size() < view.hash_size ||
                        !std::equal(digest.begin(), digest.begin() + view.hash_size, view.blob.begin() + static_cast<std::ptrdiff_t>(hash_pos))) {
                        error = "scatter code hash mismatch at slot " + std::to_string(slot);
                        return false;
                    }
                    max_slot = std::max(max_slot, slot + 1);
                }
            }
            if (!sentinel || pos > hash_table_end || max_slot != view.n_code) {
                error = "invalid or incomplete CodeDirectory scatter vector";
                return false;
            }
            for (uint64_t slot = 0; slot < view.n_code; ++slot) {
                if (!assigned.count(slot)) {
                    const uint64_t hash_pos = static_cast<uint64_t>(view.hash_offset) + slot * view.hash_size;
                    if (!stored_hash_is_zero(view.blob, static_cast<size_t>(hash_pos), view.hash_size)) {
                        error = "unassigned scatter slot contains a nonzero digest";
                        return false;
                    }
                }
            }
        }
        if (view.pre_encrypt_offset != 0) {
            const uint64_t pre_bytes = static_cast<uint64_t>(view.n_code) * view.hash_size;
            if (pre_bytes > view.blob.size() - view.pre_encrypt_offset) {
                error = "pre-encrypt hash table out of bounds";
                return false;
            }
        }
        const std::array<std::pair<uint32_t, uint32_t>, 9> blob_specials{{
            {macho::SLOT_REQUIREMENTS, 2}, {static_cast<uint32_t>(CodeSignSlot::APPLICATION), 4},
            {macho::SLOT_ENTITLEMENTS, 5}, {static_cast<uint32_t>(CodeSignSlot::REPSPECIFIC), 6},
            {macho::SLOT_DER_ENTITLEMENTS, 7}, {8U, 8U}, {9U, 9U}, {10U, 10U}, {11U, 11U}
        }};
        for (const auto& special : blob_specials) {
            auto found = parsed.slots.find(special.first);
            if (found == parsed.slots.end()) continue;
            if (special.second > view.n_special || view.hash_offset < static_cast<uint64_t>(special.second) * view.hash_size) {
                error = "CodeDirectory does not allocate a required special slot";
                return false;
            }
            const uint64_t hash_pos = static_cast<uint64_t>(view.hash_offset) - static_cast<uint64_t>(special.second) * view.hash_size;
            if (hash_pos > view.blob.size() || view.hash_size > view.blob.size() - hash_pos) {
                error = "CodeDirectory special hash slot out of bounds";
                return false;
            }
            const auto digest = crypto::hash_impl(hash_type_local, found->second);
            if (digest.size() < view.hash_size ||
                !std::equal(digest.begin(), digest.begin() + view.hash_size, view.blob.begin() + static_cast<std::ptrdiff_t>(hash_pos))) {
                error = "CodeDirectory special hash mismatch for slot " + std::to_string(special.second);
                return false;
            }
        }
        if (view.linkage_size != 0) {
            if (view.version < 0x20600 || view.linkage_offset > view.blob.size() ||
                view.linkage_size > view.blob.size() - view.linkage_offset) {
                error = "linkage metadata out of bounds";
                return false;
            }
        }
        return true;
    };
    std::string primary_error;
    if (!verify_code_directory(cd, primary_error)) {
        result.message = primary_error;
        result.errors.push_back(primary_error);
        return result;
    }
    // A Mach-O's embedded signature must use an embedded SuperBlob magic.
    if (parsed.magic != 0xfade0cc0U && parsed.magic != 0xfade0b02U) {
        result.message = "unexpected detached signature container in LC_CODE_SIGNATURE";
        result.errors.push_back(result.message);
        return result;
    }
    for (const auto& [slot_type, alternate_blob] : parsed.slots) {
        if (slot_type < static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) ||
            slot_type >= static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) + 5U) continue;
        auto alternate = parse_code_directory(alternate_blob);
        if (!alternate) {
            result.message = "invalid alternate CodeDirectory at slot " + std::to_string(slot_type);
            result.errors.push_back(result.message);
            return result;
        }
        std::string alt_error;
        if (!verify_code_directory(*alternate, alt_error)) {
            result.message = "alternate CodeDirectory verification failed at slot " + std::to_string(slot_type) + ": " + alt_error;
            result.errors.push_back(result.message);
            return result;
        }
    }
    if (std::count_if(parsed.slots.begin(), parsed.slots.end(), [](const auto& entry) {
            return entry.first >= static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) &&
                   entry.first < static_cast<uint32_t>(CodeSignSlot::ALTERNATE_BASE) + 5U;
        }) > 5) {
        result.message = "too many alternate CodeDirectories";
        result.errors.push_back(result.message);
        return result;
    }
    const HashType hash_type = hash_type_for_view(cd);
    auto req_iterator = parsed.slots.find(macho::SLOT_REQUIREMENTS);
    if (req_iterator != parsed.slots.end()) {
        auto facts = parse_designated_requirement_facts(req_iterator->second);
        auto signature_info = macho::get_signature_info_impl(data);
        if (!facts.valid) {
            result.message = "invalid designated requirement";
            result.errors.push_back("invalid designated requirement");
            return result;
        }
        if (facts.has_identifier && facts.identifier != signature_info.identifier) {
            result.message = "designated requirement identifier mismatch";
            result.errors.push_back("designated requirement identifier mismatch");
            return result;
        }
        if (!signature_info.team_id.empty() && facts.has_team && facts.team_id != signature_info.team_id) {
            result.message = "designated requirement team mismatch";
            result.errors.push_back("designated requirement team mismatch");
            return result;
        }
    }

    auto check_special = [&](uint32_t slot_type, uint32_t special_index) {
        auto iterator = parsed.slots.find(slot_type);
        if (iterator == parsed.slots.end()) return;
        if (special_index == 0 || special_index > cd.n_special || cd.hash_size == 0 ||
            cd.hash_offset < static_cast<uint64_t>(special_index) * cd.hash_size) {
            result.message = "special slot missing";
            result.errors.push_back("special slot missing for type " + std::to_string(slot_type));
            return;
        }
        size_t offset = cd.hash_offset - static_cast<size_t>(special_index) * cd.hash_size;
        if (offset > cd.blob.size() || cd.hash_size > cd.blob.size() - offset) {
            result.message = "special slot out of bounds";
            result.errors.push_back("special slot out of bounds for type " + std::to_string(slot_type));
            return;
        }
        if (stored_hash_is_zero(cd.blob, offset, cd.hash_size)) {
            result.message = "present special blob has an empty CodeDirectory digest";
            result.errors.push_back("present special blob has an empty digest for slot " + std::to_string(special_index));
            return;
        }
        auto digest = crypto::hash_impl(hash_type, iterator->second);
        if (digest.size() < cd.hash_size ||
            !std::equal(digest.begin(), digest.begin() + cd.hash_size, cd.blob.begin() + offset)) {
            result.message = "special slot hash mismatch";
            result.errors.push_back("special slot hash mismatch for type " + std::to_string(slot_type));
        }
    };
    check_special(macho::SLOT_REQUIREMENTS, 2);
    check_special(static_cast<uint32_t>(CodeSignSlot::APPLICATION), 4);
    check_special(macho::SLOT_ENTITLEMENTS, 5);
    check_special(static_cast<uint32_t>(CodeSignSlot::REPSPECIFIC), 6);
    check_special(macho::SLOT_DER_ENTITLEMENTS, 7);
    check_special(8U, 8U);
    check_special(9U, 9U);
    check_special(10U, 10U);
    check_special(11U, 11U);

    // XML and DER entitlement payloads must describe the same plist when both are present.
    const auto xml_entitlements = parsed.slots.find(macho::SLOT_ENTITLEMENTS);
    const auto der_entitlements = parsed.slots.find(macho::SLOT_DER_ENTITLEMENTS);
    const auto macho_build = macho::analyze_thin(data, 0);
    const bool ios_family_platform = cd.platform == static_cast<uint8_t>(Platform::IOS) ||
        cd.platform == static_cast<uint8_t>(Platform::TVOS) ||
        cd.platform == static_cast<uint8_t>(Platform::WATCHOS) ||
        cd.platform == static_cast<uint8_t>(Platform::BRIDGEOS) ||
        cd.platform == static_cast<uint8_t>(Platform::IOSSIMULATOR) ||
        cd.platform == static_cast<uint8_t>(Platform::TVOSSIMULATOR) ||
        cd.platform == static_cast<uint8_t>(Platform::WATCHOSSIMULATOR);
    uint32_t der_minimum_os = 0x000F0000U; // iOS/tvOS 15.0
    if (cd.platform == static_cast<uint8_t>(Platform::WATCHOS) || cd.platform == static_cast<uint8_t>(Platform::WATCHOSSIMULATOR))
        der_minimum_os = 0x00080000U; // watchOS 8.0
    else if (cd.platform == static_cast<uint8_t>(Platform::BRIDGEOS))
        der_minimum_os = 0x00060000U; // bridgeOS 6.0
    const bool platform_requires_der = ios_family_platform && macho_build.min_os_version != 0 &&
                                       macho_build.min_os_version >= der_minimum_os;
    if (xml_entitlements != parsed.slots.end()) {
        if (xml_entitlements->second.size() < 8 || load_be32(xml_entitlements->second.data()) != 0xfade7171U ||
            load_be32(xml_entitlements->second.data() + 4) != xml_entitlements->second.size()) {
            result.errors.push_back("XML Entitlements Blob is truncated or has an invalid header/length");
        } else {
            std::vector<uint8_t> xml_bytes(xml_entitlements->second.begin() + 8, xml_entitlements->second.end());
            auto xml_plist = plist_from_xml_bytes(xml_bytes);
            if (!xml_plist || plist_get_node_type(xml_plist) != PLIST_DICT) {
                result.errors.push_back("XML Entitlements payload is not a valid plist dictionary");
                if (xml_plist) plist_free(xml_plist);
            } else {
                // Apple documents DER entitlements as required for modern
                // iOS-family signatures when XML entitlements are present.
                // Older platform identifiers are not inferred as iOS.
                const bool der_required = platform_requires_der || (ios_family_platform && macho_build.min_os_version == 0 && cd.version >= 0x20500U);
                if (der_required && der_entitlements == parsed.slots.end())
                    result.errors.push_back("iOS-family CodeDirectory with XML Entitlements is missing DER Entitlements (SLOT_DER_ENTITLEMENTS)");
                if (der_entitlements != parsed.slots.end()) {
                    const auto& der_blob = der_entitlements->second;
                    if (der_blob.size() <= 8 || load_be32(der_blob.data()) != 0xfade7172U ||
                        load_be32(der_blob.data() + 4) != der_blob.size()) {
                        result.errors.push_back("DER Entitlements Blob has an invalid header, length or empty payload");
                    } else {
                        std::vector<uint8_t> der_payload(der_blob.begin() + 8, der_blob.end());
                        if (cd.version >= 0x20500U && std::all_of(der_payload.begin(), der_payload.end(), [](uint8_t b) { return b == 0; }))
                            result.errors.push_back("CodeDirectory v2.5+ has an all-zero DER Entitlements payload");
                        size_t der_pos = 0;
                        ASN1Node der_root;
                        if (!asn1_parse_node(der_payload, der_pos, der_root) || der_pos != der_payload.size() || der_root.tag != 0x31) {
                            result.errors.push_back("DER Entitlements payload is not one complete DER SET dictionary");
                        }
                    }
                    std::string xml_text(xml_bytes.begin(), xml_bytes.end());
                    const auto expected_der_blob = blob::build_der_entitlements_blob_impl(xml_text);
                    if (expected_der_blob != der_blob)
                        result.errors.push_back("XML and DER Entitlements payloads do not encode the same plist");
                }
                plist_free(xml_plist);
            }
        }
    } else if (der_entitlements != parsed.slots.end()) {
        const auto& der_blob = der_entitlements->second;
        if (der_blob.size() <= 8 || load_be32(der_blob.data()) != 0xfade7172U ||
            load_be32(der_blob.data() + 4) != der_blob.size()) {
            result.errors.push_back("DER Entitlements Blob has an invalid header, length or empty payload");
        } else {
            std::vector<uint8_t> der_payload(der_blob.begin() + 8, der_blob.end());
            if (cd.version >= 0x20500U && std::all_of(der_payload.begin(), der_payload.end(), [](uint8_t b) { return b == 0; }))
                result.errors.push_back("CodeDirectory v2.5+ has an all-zero DER Entitlements payload");
            size_t der_pos = 0; ASN1Node der_root;
            if (!asn1_parse_node(der_payload, der_pos, der_root) || der_pos != der_payload.size() || der_root.tag != 0x31)
                result.errors.push_back("DER Entitlements payload is not one complete DER SET dictionary");
        }
    }
    if (!result.errors.empty()) {
        result.ok = false;
        return result;
    }
    if (!parsed.cms.empty()) {
        std::string cms_error;
        if (!crypto::verify_pkcs7_impl(cd.blob, parsed.cms, verify_options.certificate_chain, &cms_error)) {
            result.message = "CMS verification failed";
            result.errors.push_back(cms_error.empty() ? "CMS verification failed" : cms_error);
            return result;
        }
        result.message = verify_options.certificate_chain.enabled
            ? "valid; CMS mathematics and configured certificate-chain policy passed"
            : "valid; CMS mathematics passed; certificate chain not checked (default)";
    } else {
        result.message = verify_options.certificate_chain.enabled
            ? "valid; no CMS signer (ad-hoc/no-CMS); certificate-chain verification not applicable"
            : "valid; no CMS signer (ad-hoc/no-CMS)";
    }
    result.ok = true;
    return result;
}

inline VerificationResult verify_memory_impl(const std::vector<uint8_t>& data, const VerificationOptions& verify_options = {}) {
    VerificationResult result;
    result.ok = true;
    result.message = "valid";
    if (data.size() < 8) {
        result.ok = false;
        result.message = "file too small";
        result.errors.push_back("file too small");
        return result;
    }
    uint32_t be_magic = load_be32(data.data());
    if (be_magic == macho::kFAT_MAGIC || be_magic == macho::kFAT_MAGIC_64 || be_magic == macho::kFAT_CIGAM || be_magic == macho::kFAT_CIGAM_64) {
        auto slices = macho::parse_slices_impl(data);
        if (slices.empty()) {
            result.ok = false;
            result.message = "no slices";
            result.errors.push_back("no slices");
            return result;
        }
        size_t index = 0;
        for (auto& slice : slices) {
            std::vector<uint8_t> slice_data(data.begin() + slice.offset, data.begin() + slice.offset + slice.size);
            auto slice_result = verify_thin_memory(slice_data, verify_options);
            if (!slice_result.ok) {
                result.ok = false;
                result.message = "fat verification failed";
                for (auto& error : slice_result.errors) {
                    result.errors.push_back("slice " + std::to_string(index) + ": " + error);
                }
            }
            ++index;
        }
        return result;
    }
    return verify_thin_memory(data, verify_options);
}

inline bool verify_bundle_resources_impl(const std::filesystem::path& bundle, const std::vector<uint8_t>& executable_data, std::vector<std::string>& errors) {
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    auto resource_data = read_file(code_resources);
    if (resource_data.empty()) { errors.push_back("CodeResources unreadable"); return false; }
    auto plist = plist_from_xml_bytes(resource_data);
    if (!plist || plist_get_node_type(plist) != PLIST_DICT) { if (plist) plist_free(plist); errors.push_back("invalid CodeResources plist"); return false; }
    plist_t files_v1 = plist_dict_get_item(plist, "files");
    plist_t files2 = plist_dict_get_item(plist, "files2");
    const bool have_v1 = files_v1 && plist_get_node_type(files_v1) == PLIST_DICT;
    const bool have_v2 = files2 && plist_get_node_type(files2) == PLIST_DICT;
    if (!have_v1 && !have_v2) { plist_free(plist); errors.push_back("CodeResources files/files2 missing"); return false; }
    auto signature_info = macho::get_signature_info_impl(executable_data);
    bool ok = true;
    auto add_error = [&](const std::string& value) { ok = false; errors.push_back(value); };
    std::set<std::string> sealed_resources;
    const auto bundle_executable = archive::find_executable_in_bundle_impl(bundle);
    // Legacy `files` entries are SHA-1 blobs or symlink dictionaries. Verify
    // them independently of files2 so older seals cannot pass unchecked.
    if (have_v1) {
        plist_dict_iter v1_iterator = nullptr;
        plist_dict_new_iter(files_v1, &v1_iterator);
        if (v1_iterator) {
            for (;;) {
                char* key = nullptr;
                plist_t value = nullptr;
                plist_dict_next_item(files_v1, v1_iterator, &key, &value);
                if (!key || !value) { free(key); break; }
                const std::string relative_string(key);
                sealed_resources.insert(relative_string);
                const std::filesystem::path relative(relative_string);
                const auto target = bundle / relative;
                if (!std::filesystem::exists(target) && !std::filesystem::is_symlink(target)) {
                    add_error("missing v1 sealed resource: " + relative_string);
                } else if (plist_get_node_type(value) == PLIST_DATA) {
                    char* bytes = nullptr; uint64_t length = 0;
                    plist_get_data_val(value, &bytes, &length);
                    if (!bytes || length != 20) {
                        add_error("invalid v1 SHA-1: " + relative_string);
                    } else {
                        const auto actual = crypto::sha1_impl(read_file(target));
                        if (actual.size() != length || !std::equal(actual.begin(), actual.end(), reinterpret_cast<uint8_t*>(bytes)))
                            add_error("v1 resource SHA-1 mismatch: " + relative_string);
                    }
                    if (bytes) free(bytes);
                } else if (plist_get_node_type(value) == PLIST_DICT) {
                    plist_t symlink = plist_dict_get_item(value, "symlink");
                    if (symlink) {
                        char* expected = nullptr; plist_get_string_val(symlink, &expected);
                        if (!expected || !std::filesystem::is_symlink(target) || std::filesystem::read_symlink(target).generic_string() != expected)
                            add_error("v1 symlink mismatch: " + relative_string);
                        if (expected) free(expected);
                    }
                }
                free(key);
            }
            free(v1_iterator);
        }
    }
    plist_dict_iter iterator = nullptr;
    if (have_v2) plist_dict_new_iter(files2, &iterator);
    if (iterator) {
        for (;;) {
            char* key = nullptr;
            plist_t value = nullptr;
            plist_dict_next_item(files2, iterator, &key, &value);
            if (!key || !value) {
                free(key);
                break;
            }
            std::filesystem::path relative(key);
            sealed_resources.insert(relative.generic_string());
            std::filesystem::path target = bundle / relative;
            bool optional = false;
            if (plist_get_node_type(value) == PLIST_DICT) optional = plist_dict_bool(value, "optional");
            if (!std::filesystem::exists(target) && !std::filesystem::is_symlink(target)) {
                if (!optional) add_error("missing sealed resource: " + relative.generic_string());
                free(key);
                continue;
            }
            if (plist_get_node_type(value) == PLIST_DICT) {
                plist_t hash = plist_dict_get_item(value, "hash");
                if (hash) {
                    char* bytes = nullptr; uint64_t length = 0;
                    plist_get_data_val(hash, &bytes, &length);
                    if (!bytes || length != 20) add_error("invalid hash: " + relative.generic_string());
                    else {
                        auto actual = crypto::sha1_impl(read_file(target));
                        if (!std::equal(actual.begin(), actual.end(), reinterpret_cast<uint8_t*>(bytes))) add_error("resource SHA-1 mismatch: " + relative.generic_string());
                    }
                    if (bytes) free(bytes);
                }
                plist_t hash2 = plist_dict_get_item(value, "hash2");
                if (hash2) {
                    char* bytes = nullptr; uint64_t length = 0;
                    plist_get_data_val(hash2, &bytes, &length);
                    if (!bytes || length != 32) add_error("invalid hash2: " + relative.generic_string());
                    else {
                        auto actual = crypto::sha256_impl(read_file(target));
                        if (!std::equal(actual.begin(), actual.end(), reinterpret_cast<uint8_t*>(bytes))) add_error("resource SHA-256 mismatch: " + relative.generic_string());
                    }
                    if (bytes) free(bytes);
                }
                plist_t symlink = plist_dict_get_item(value, "symlink");
                if (symlink) {
                    char* expected = nullptr; plist_get_string_val(symlink, &expected);
                    if (!expected || !std::filesystem::is_symlink(target) || std::filesystem::read_symlink(target).generic_string() != expected) add_error("symlink mismatch: " + relative.generic_string());
                    if (expected) free(expected);
                }
                plist_t cdhash = plist_dict_get_item(value, "cdhash");
                if (cdhash) {
                    char* bytes = nullptr; uint64_t length = 0; plist_get_data_val(cdhash, &bytes, &length);
                    auto nested_exec = std::filesystem::is_directory(target) ? archive::find_executable_in_bundle_impl(target) : target;
                    auto nested_info = nested_exec.empty() ? SignatureInfo{} : macho::get_signature_info_impl(read_file(nested_exec));
                    if (!bytes || length != nested_info.cd_hash.size() || (!nested_info.cd_hash.empty() && !std::equal(nested_info.cd_hash.begin(), nested_info.cd_hash.end(), reinterpret_cast<uint8_t*>(bytes)))) add_error("nested code hash mismatch: " + relative.generic_string());
                    if (bytes) free(bytes);
                }
            }
            free(key);
        }
        free(iterator);
    }
    for (auto it = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied); it != std::filesystem::recursive_directory_iterator(); ++it) {
        if (!it->is_regular_file() && !it->is_symlink()) continue;
        const auto path = it->path();
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        if (path == bundle / "Info.plist" || path == bundle / "PkgInfo") continue;
        const auto relative = std::filesystem::relative(path, bundle).generic_string();
        if (relative == ".DS_Store" || relative.rfind(".DS_Store/", 0) == 0) continue;
        bool inside_nested = false;
        for (const auto& entry : sealed_resources) {
            std::filesystem::path sealed(entry);
            if (archive::path_is_under(path, bundle / sealed) && std::filesystem::is_directory(bundle / sealed)) { inside_nested = true; break; }
        }
        if (inside_nested) continue;
        if (path != bundle_executable && sealed_resources.find(relative) == sealed_resources.end()) {
            add_error("unsealed resource: " + relative);
        }
    }
    plist_free(plist);
    auto signature = macho::get_signature_info_impl(executable_data);
    if (signature.cd_hash.empty()) add_error("executable CodeDirectory missing");
    const auto info_data = read_file(bundle / "Info.plist");
    if (info_data.empty()) add_error("bundle Info.plist missing or unreadable");
    const auto slices = macho::parse_slices_impl(executable_data);
    if (slices.empty()) {
        add_error("bundle executable has no parseable Mach-O slices for special-slot verification");
    } else {
    for (size_t slice_index = 0; slice_index < slices.size(); ++slice_index) {
        const auto& slice = slices[slice_index];
        std::vector<uint8_t> thin(executable_data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                  executable_data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        const auto analysis = macho::analyze_thin(thin, 0);
        if (!analysis.valid || analysis.code_signature_size == 0 ||
            analysis.code_signature_offset > thin.size() || analysis.code_signature_size > thin.size() - analysis.code_signature_offset) {
            add_error("bundle executable slice " + std::to_string(slice_index) + " has no valid embedded signature");
            continue;
        }
        std::vector<uint8_t> sig(thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
                                 thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
        const auto parsed = parse_superblob(sig);
        const auto cd = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
        if (!parsed.valid || cd == parsed.slots.end()) {
            add_error("bundle executable slice " + std::to_string(slice_index) + " has an invalid SuperBlob or missing CodeDirectory");
            continue;
        }
        const auto view = parse_code_directory(cd->second);
        if (!view) {
            add_error("bundle executable slice " + std::to_string(slice_index) + " CodeDirectory is unsupported or malformed");
            continue;
        }
        const HashType resource_hash_type = view->hash_type == 1 ? HashType::SHA1 :
            (view->hash_type == 2 ? HashType::SHA256 :
            (view->hash_type == 3 ? HashType::SHA256_TRUNCATED : HashType::SHA384));
        auto verify_bundle_special = [&](uint32_t special_slot, const std::vector<uint8_t>& bytes, const char* label) {
            if (view->n_special < special_slot || view->hash_offset < static_cast<uint64_t>(special_slot) * view->hash_size) {
                add_error(std::string(label) + " special slot layout invalid in slice " + std::to_string(slice_index));
                return;
            }
            const size_t offset = view->hash_offset - static_cast<size_t>(special_slot) * view->hash_size;
            const auto expected = crypto::hash_impl(resource_hash_type, bytes);
            if (offset > cd->second.size() || view->hash_size > cd->second.size() - offset ||
                expected.size() < view->hash_size ||
                !std::equal(expected.begin(), expected.begin() + view->hash_size, cd->second.begin() + static_cast<std::ptrdiff_t>(offset)))
                add_error(std::string(label) + " special slot mismatch in slice " + std::to_string(slice_index));
        };
        verify_bundle_special(1, info_data, "Info.plist");
        verify_bundle_special(3, resource_data, "CodeResources");
    }
    }
    return ok;
}

inline VerificationResult verify_bundle_impl_depth(const std::filesystem::path& bundle, size_t depth, const VerificationOptions& verify_options = {}) {
    VerificationResult result;
    if (depth > 64) {
        result.ok = false;
        result.message = "nested bundle depth exceeded";
        result.errors.push_back("nested bundle depth exceeded");
        return result;
    }
    result.ok = true;
    result.message = "valid";
    if (!std::filesystem::exists(bundle) || !std::filesystem::is_directory(bundle)) {
        result.ok = false;
        result.message = "bundle missing";
        result.errors.push_back("bundle missing");
        return result;
    }
    std::filesystem::path code_resources = bundle / "_CodeSignature" / "CodeResources";
    if (!std::filesystem::exists(code_resources)) {
        result.ok = false;
        result.message = "CodeResources missing";
        result.errors.push_back("CodeResources missing");
        return result;
    }
    auto executable = archive::find_executable_in_bundle_impl(bundle);
    if (executable.empty()) {
        result.ok = false;
        result.message = "executable missing";
        result.errors.push_back("executable missing");
        return result;
    }
    auto nested_bundles = signer::outermost_nested_bundles(bundle);
    for (auto& nested : nested_bundles) {
        auto nested_result = verify_bundle_impl_depth(nested, depth + 1, verify_options);
        if (!nested_result.ok) {
            result.ok = false;
            result.message = "nested bundle verification failed";
            for (auto& error : nested_result.errors) {
                result.errors.push_back(nested.generic_string() + ": " + error);
            }
        }
    }
    for (auto iterator = std::filesystem::recursive_directory_iterator(bundle, std::filesystem::directory_options::skip_permission_denied);
         iterator != std::filesystem::recursive_directory_iterator();
         ++iterator) {
        if (!iterator->is_regular_file()) continue;
        auto path = iterator->path();
        if (path == executable) continue;
        if (archive::path_is_under(path, bundle / "_CodeSignature")) continue;
        bool inside_nested = false;
        for (auto& nested : nested_bundles) {
            if (archive::path_is_under(path, nested)) {
                inside_nested = true;
                break;
            }
        }
        if (inside_nested) continue;
        if (archive::is_macho_file_impl(path)) {
            std::ifstream input(path, std::ios::binary);
            std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            auto file_result = verify_memory_impl(data, verify_options);
            if (!file_result.ok) {
                result.ok = false;
                result.message = "bundle member verification failed";
                for (auto& error : file_result.errors) {
                    result.errors.push_back(path.generic_string() + ": " + error);
                }
            }
        }
    }
    std::ifstream executable_input(executable, std::ios::binary);
    std::vector<uint8_t> executable_data((std::istreambuf_iterator<char>(executable_input)), std::istreambuf_iterator<char>());
    auto executable_result = verify_memory_impl(executable_data, verify_options);
    if (!executable_result.ok) {
        result.ok = false;
        result.message = "executable verification failed";
        for (auto& error : executable_result.errors) result.errors.push_back(executable.generic_string() + ": " + error);
    }
    std::vector<std::string> resource_errors;
    if (!verify_bundle_resources_impl(bundle, executable_data, resource_errors)) {
        result.ok = false;
        result.message = "resource seal verification failed";
        for (auto& error : resource_errors) result.errors.push_back(bundle.generic_string() + ": " + error);
    }
    return result;
}

inline VerificationResult verify_bundle_impl(const std::filesystem::path& bundle, const VerificationOptions& verify_options = {}) {
    return verify_bundle_impl_depth(bundle, 0, verify_options);
}

inline VerificationResult verify_archive_impl(const std::filesystem::path& archive_path, const VerificationOptions& verify_options = {}) {
    VerificationResult result;
    result.ok = true;
    result.message = "valid";
    std::string work_dir = make_temp_dir();
    try {
        archive::extract_archive_impl(archive_path, work_dir);
    } catch (const std::exception& e) {
        result.ok = false;
        result.message = "archive extraction failed";
        result.errors.push_back(e.what());
        return result;
    }
    auto entries = archive::scan_for_signables_impl(work_dir);
    for (auto& entry : entries) {
        std::filesystem::path path(entry.path);
        VerificationResult entry_result;
        if (entry.is_directory) {
            entry_result = verify_bundle_impl(path, verify_options);
        } else {
            std::ifstream input(path, std::ios::binary);
            std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
            entry_result = verify_memory_impl(data, verify_options);
        }
        if (!entry_result.ok) {
            result.ok = false;
            result.message = "archive verification failed";
            for (auto& error : entry_result.errors) {
                result.errors.push_back(entry.path + ": " + error);
            }
        }
    }
    std::error_code ec;
    std::filesystem::remove_all(work_dir, ec);
    return result;
}

inline VerificationResult verify_path_impl(const std::filesystem::path& path, const VerificationOptions& verify_options = {}) {
    if (!std::filesystem::exists(path)) {
        VerificationResult result;
        result.ok = false;
        result.message = "path missing";
        result.errors.push_back("path missing");
        return result;
    }
    if (std::filesystem::is_directory(path)) {
        if (archive::is_signable_bundle_extension(path)) {
            return verify_bundle_impl(path, verify_options);
        }
        VerificationResult result;
        result.ok = true;
        result.message = "valid";
        auto entries = archive::scan_for_signables_impl(path);
        for (auto& entry : entries) {
            std::filesystem::path entry_path(entry.path);
            VerificationResult entry_result;
            if (entry.is_directory) {
                entry_result = verify_bundle_impl(entry_path, verify_options);
            } else {
                std::ifstream input(entry_path, std::ios::binary);
                std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
                entry_result = verify_memory_impl(data, verify_options);
            }
            if (!entry_result.ok) {
                result.ok = false;
                result.message = "directory verification failed";
                for (auto& error : entry_result.errors) {
                    result.errors.push_back(entry.path + ": " + error);
                }
            }
        }
        return result;
    }
    if (archive::is_archive_impl(path)) {
        return verify_archive_impl(path, verify_options);
    }
    std::ifstream input(path, std::ios::binary);
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    return verify_memory_impl(data, verify_options);
}

inline bool verify_cms_with_system(const std::vector<uint8_t>& cd_blob, const std::vector<uint8_t>& cms) {
    const unsigned char* p = cms.data();
    Pkcs7Ptr p7(d2i_PKCS7(nullptr, &p, static_cast<long>(cms.size())));
    if (!p7.get()) return false;
    BioPtr data_bio(BIO_new_mem_buf(cd_blob.data(), static_cast<int>(cd_blob.size())));
    if (!data_bio.get()) return false;
    X509_STORE* store = X509_STORE_new();
    if (!store) return false;
    const bool store_ok = X509_STORE_set_default_paths(store) == 1;
    int result = store_ok ? PKCS7_verify(p7.get(), nullptr, store, data_bio.get(), nullptr, PKCS7_BINARY | PKCS7_DETACHED) : 0;
    X509_STORE_free(store);
    return result == 1;
}

#if defined(__APPLE__) && TARGET_OS_OSX
inline bool verify_with_apple_system(const std::filesystem::path& path) {
    const std::string native = path.string();
    CFURLRef url = CFURLCreateFromFileSystemRepresentation(kCFAllocatorDefault, reinterpret_cast<const UInt8*>(native.data()), native.size(), std::filesystem::is_directory(path));
    if (!url) return false;
    SecStaticCodeRef code = nullptr;
    OSStatus status = SecStaticCodeCreateWithPath(url, kSecCSDefaultFlags, &code);
    CFRelease(url);
    if (status != errSecSuccess || !code) return false;
    status = SecStaticCodeCheckValidity(code, kSecCSStrictValidate, nullptr);
    CFRelease(code);
    return status == errSecSuccess;
}
#endif

inline VerificationResult verify_with_system_impl(const std::filesystem::path& path) {
#if defined(__APPLE__) && TARGET_OS_OSX
    VerificationResult result;
    result.ok = verify_with_apple_system(path);
    result.message = result.ok ? "valid" : "Apple system trust/validation failed";
    if (!result.ok) result.errors.push_back(result.message);
    return result;
#else
    auto result = verify_path_impl(path);
    if (!result.ok) return result;
    if (!std::filesystem::is_regular_file(path) || archive::is_archive_impl(path)) return result;
    std::ifstream input(path, std::ios::binary);
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    if (!macho::is_macho_impl(data)) return result;
    auto analysis = macho::analyze_thin(data, 0);
    if (!analysis.valid || analysis.code_signature_size == 0) return result;
    std::vector<uint8_t> signature(data.begin() + analysis.code_signature_offset, data.begin() + analysis.code_signature_offset + analysis.code_signature_size);
    auto parsed = parse_superblob(signature);
    if (!parsed.valid || parsed.cms.empty()) return result;
    auto cd_iterator = parsed.slots.find(macho::SLOT_CODEDIRECTORY);
    if (cd_iterator == parsed.slots.end()) return result;
    if (!verify_cms_with_system(cd_iterator->second, parsed.cms)) {
        result.ok = false;
        result.message = "system CMS verification failed";
        result.errors.push_back("system CMS verification failed");
    }
    return result;
#endif
}

}

std::vector<uint8_t> CryptoEngine::sha1(const std::vector<uint8_t>& data) {
    return crypto::sha1_impl(data);
}

std::vector<uint8_t> CryptoEngine::sha256(const std::vector<uint8_t>& data) {
    return crypto::sha256_impl(data);
}

std::vector<uint8_t> CryptoEngine::hash(HashType type, const std::vector<uint8_t>& data) {
    return crypto::hash_impl(type, data);
}

std::vector<uint8_t> CryptoEngine::sign_pkcs7(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password) {
    return crypto::sign_pkcs7_impl(data, cert_path, key_path, password);
}

bool CryptoEngine::verify_pkcs7(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    return crypto::verify_pkcs7_impl(data, signature);
}

std::vector<uint8_t> CryptoEngine::build_apple_cdhash_attr(const std::vector<uint8_t>& cd_hash, HashType hash_type) {
    return crypto::build_apple_cdhash_attr_impl(cd_hash, hash_type);
}

std::vector<std::vector<uint8_t>> CryptoEngine::extract_certs_raw(const std::string& cert_path) {
    return crypto::extract_certs_raw_impl(cert_path);
}

bool KeychainManager::load_p12(const std::string& path, const std::string& password, std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der) {
    return crypto::load_p12_impl(path, password, cert_der, key_der);
}

std::string KeychainManager::extract_team_id_from_certificate_file(const std::string& cert_path) {
    return crypto::extract_team_id_from_certificate_file_impl(cert_path);
}

std::string KeychainManager::extract_team_id_from_p12(const std::string& p12_path, const std::string& password) {
    return crypto::extract_team_id_from_p12_impl(p12_path, password);
}

std::vector<uint8_t> KeychainManager::get_public_key_hash(const std::string& cert_path) {
    return crypto::get_public_key_hash_impl(cert_path);
}

bool MachOParser::is_macho(const std::vector<uint8_t>& data) {
    return macho::is_macho_impl(data);
}

std::vector<Slice> MachOParser::parse_slices(const std::vector<uint8_t>& data) {
    return macho::parse_slices_impl(data);
}

std::vector<uint8_t> MachOParser::select_slice(const std::vector<uint8_t>& data, const std::string& arch) {
    return macho::select_slice_impl(data, arch);
}

SignatureInfo MachOParser::get_signature_info(const std::vector<uint8_t>& data) {
    return macho::get_signature_info_impl(data);
}

std::vector<uint8_t> MachOParser::strip_signature(const std::vector<uint8_t>& data) {
    return macho::strip_signature_impl(data);
}

std::vector<uint8_t> MachOParser::embed_signature(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature) {
    return macho::embed_signature_impl(data, signature);
}

std::vector<uint8_t> MachOParser::rebuild_fat(const std::vector<std::vector<uint8_t>>& slices) {
    return macho::rebuild_fat_impl(slices);
}

std::vector<uint8_t> BlobBuilder::make_blob(BlobMagic magic, const std::vector<uint8_t>& data) {
    return blob::make_blob_impl(static_cast<uint32_t>(magic), data);
}

std::vector<uint8_t> BlobBuilder::build_superblob(const std::map<uint32_t, std::vector<uint8_t>>& blobs) {
    return blob::build_superblob_impl(blobs);
}

std::vector<uint8_t> BlobBuilder::build_code_directory(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags) {
    return blob::build_code_directory_impl(code, identifier, team_id, hash_type, flags);
}

std::vector<uint8_t> BlobBuilder::build_cd_versioned(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version) {
    return blob::build_cd_versioned_impl(code, identifier, team_id, hash_type, flags, version);
}

std::vector<uint8_t> BlobBuilder::build_entitlements_blob(const std::string& xml) {
    return blob::build_entitlements_blob_impl(xml);
}

std::vector<uint8_t> BlobBuilder::build_der_entitlements_blob(const std::string& xml) {
    return blob::build_der_entitlements_blob_impl(xml);
}

std::vector<uint8_t> BlobBuilder::build_requirements_blob(const std::string& identifier, const std::string& team_id) {
    return blob::build_requirements_blob_impl(identifier, team_id);
}

std::vector<uint8_t> BlobBuilder::build_dr(const std::string& identifier, const std::string& team_id) {
    return blob::build_dr_impl(identifier, team_id);
}

std::vector<uint8_t> BlobBuilder::compile_requirements(const std::string& xml) {
    return blob::compile_requirements_impl(xml);
}

std::vector<uint8_t> BlobBuilder::der_encode_plist_xml(const std::string& xml) {
    std::vector<uint8_t> xml_bytes(xml.begin(), xml.end());
    plist_t root = plist_from_xml_bytes(xml_bytes);
    if (!root) return {};
    std::vector<uint8_t> der = der_encode_plist_node(root);
    plist_free(root);
    return der;
}

bool ArchiveEngine::is_archive(const std::filesystem::path& path) {
    return archive::is_archive_impl(path);
}

ArchiveFormat ArchiveEngine::detect_format(const std::filesystem::path& path) {
    return archive::detect_format_impl(path);
}

std::vector<ArchiveEntryInfo> ArchiveEngine::list_contents(const std::filesystem::path& path) {
    return archive::list_contents_impl(path);
}

std::vector<ArchiveEntryInfo> ArchiveEngine::scan_for_signables(const std::filesystem::path& dir) {
    return archive::scan_for_signables_impl(dir);
}

void ArchiveEngine::extract_archive(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir) {
    archive::extract_archive_impl(archive_path, out_dir);
}

void ArchiveEngine::create_archive(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format) {
    archive::create_archive_impl(dir, out, format);
}

void ArchiveEngine::create_ipa(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_ipa_impl(dir, out);
}

void ArchiveEngine::create_zip(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_zip_impl(dir, out);
}

void ArchiveEngine::create_tar(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::create_tar_impl(dir, out);
}

void ArchiveEngine::extract_ipa(const std::filesystem::path& ipa, const std::filesystem::path& dir) {
    archive::extract_ipa_impl(ipa, dir);
}

void ArchiveEngine::repack_ipa(const std::filesystem::path& dir, const std::filesystem::path& out) {
    archive::repack_ipa_impl(dir, out);
}

std::filesystem::path ArchiveEngine::find_app_bundle(const std::filesystem::path& dir) {
    return archive::find_app_bundle_impl(dir);
}

std::filesystem::path ArchiveEngine::find_executable_in_bundle(const std::filesystem::path& bundle) {
    return archive::find_executable_in_bundle_impl(bundle);
}

void ArchiveEngine::stream_sign(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options) {
    archive::stream_sign_impl(in, out, options);
}

void Signer::sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::sign_impl(path, options);
}

std::vector<uint8_t> Signer::sign_memory(const std::vector<uint8_t>& data, const SignOptions& options) {
    return signer::sign_macho_memory_impl(data, options, {}, {});
}

void Signer::unsign(const std::filesystem::path& path) {
    signer::unsign_impl(path);
}

void Signer::unsign_deep(const std::filesystem::path& path) {
    signer::unsign_deep_impl(path);
}

void Signer::reset_cryptid(const std::filesystem::path& path) {
    signer::reset_cryptid_impl(path);
}

std::vector<uint8_t> Signer::unsign_memory(const std::vector<uint8_t>& data) {
    return signer::unsign_memory_impl(data);
}

void Signer::deep_sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::deep_sign_impl(path, options);
}

void Signer::super_deep_sign(const std::filesystem::path& path, const SignOptions& options) {
    signer::super_deep_sign_impl(path, options);
}

void Signer::merge_entitlements(const std::filesystem::path& path, const SignOptions& options) {
    signer::merge_entitlements_impl(path, options);
}

void Signer::sign_ipa(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options) {
    signer::sign_ipa_impl(ipa, out, options);
}

void Signer::sign_archive(const std::filesystem::path& archive, const std::filesystem::path& out, const SignOptions& options) {
    signer::sign_archive_impl(archive, out, options);
}

void Signer::sign_bundle(const std::filesystem::path& bundle, const SignOptions& options) {
    signer::sign_bundle_impl(bundle, options);
}

void Signer::sign_plan(const ArchiveSignPlan& plan, const SignOptions& options) {
    signer::sign_plan_impl(plan, options);
}

VerificationResult Verifier::verify(const std::filesystem::path& path) {
    return verifier::verify_path_impl(path, VerificationOptions{});
}

VerificationResult Verifier::verify(const std::filesystem::path& path, const VerificationOptions& options) {
    return verifier::verify_path_impl(path, options);
}

VerificationResult Verifier::verify_memory(const std::vector<uint8_t>& data) {
    return verifier::verify_memory_impl(data, VerificationOptions{});
}

VerificationResult Verifier::verify_memory(const std::vector<uint8_t>& data, const VerificationOptions& options) {
    return verifier::verify_memory_impl(data, options);
}

VerificationResult Verifier::verify_with_system(const std::filesystem::path& path) {
    return verifier::verify_with_system_impl(path);
}

VerificationResult Verifier::verify_bundle(const std::filesystem::path& bundle) {
    return verifier::verify_bundle_impl(bundle, VerificationOptions{});
}

VerificationResult Verifier::verify_bundle(const std::filesystem::path& bundle, const VerificationOptions& options) {
    return verifier::verify_bundle_impl(bundle, options);
}

VerificationResult Verifier::verify_archive(const std::filesystem::path& archive) {
    return verifier::verify_archive_impl(archive, VerificationOptions{});
}

VerificationResult Verifier::verify_archive(const std::filesystem::path& archive, const VerificationOptions& options) {
    return verifier::verify_archive_impl(archive, options);
}

void Display::display_info(const std::filesystem::path& path) {
    if (!std::filesystem::exists(path)) {
        std::cout << path.generic_string() << ": missing" << std::endl;
        return;
    }
    if (std::filesystem::is_directory(path)) {
        std::cout << path.generic_string() << ": directory" << std::endl;
        auto entries = ArchiveEngine::scan_for_signables(path);
        std::cout << "signables: " << entries.size() << std::endl;
        return;
    }
    if (ArchiveEngine::is_archive(path)) {
        std::cout << path.generic_string() << ": archive" << std::endl;
        auto entries = ArchiveEngine::list_contents(path);
        std::cout << "entries: " << entries.size() << std::endl;
        return;
    }
    auto data = read_file(path);
    std::cout << path.generic_string() << ": file" << std::endl;
    std::cout << "size: " << data.size() << std::endl;
    if (MachOParser::is_macho(data)) {
        auto slices = MachOParser::parse_slices(data);
        std::cout << "macho: true" << std::endl;
        std::cout << "slices: " << slices.size() << std::endl;
        for (size_t index = 0; index < slices.size(); ++index) {
            const auto& slice = slices[index];
            std::vector<uint8_t> slice_data(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                            data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
            auto info = MachOParser::get_signature_info(slice_data);
            std::cout << "architecture[" << index << "]: cpu=" << static_cast<uint32_t>(slice.cpu_type)
                      << " subtype=" << slice.cpu_subtype << std::endl;
            if (!info.identifier.empty()) std::cout << "  identifier: " << info.identifier << std::endl;
            if (!info.team_id.empty()) std::cout << "  team: " << info.team_id << std::endl;
            if (!info.cd_hash.empty()) std::cout << "  cdhash: " << to_hex(info.cd_hash) << std::endl;
        }
    } else {
        std::cout << "macho: false" << std::endl;
    }
}

void Display::display_signature(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) {
        std::cout << path.generic_string() << ": not a Mach-O" << std::endl;
        return;
    }
    auto slices = MachOParser::parse_slices(data);
    std::cout << "path: " << path.generic_string() << std::endl;
    for (size_t index = 0; index < slices.size(); ++index) {
        const auto& slice = slices[index];
        std::vector<uint8_t> slice_data(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                        data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        auto info = MachOParser::get_signature_info(slice_data);
        const char* hash_name = info.hash_type == HashType::SHA1 ? "sha1" : (info.hash_type == HashType::SHA256 ? "sha256" : (info.hash_type == HashType::SHA256_TRUNCATED ? "sha256-truncated" : "sha384"));
        std::cout << "architecture[" << index << "]: cpu=" << static_cast<uint32_t>(slice.cpu_type)
                  << " subtype=" << slice.cpu_subtype << std::endl;
        std::cout << "  identifier: " << info.identifier << std::endl;
        std::cout << "  team: " << info.team_id << std::endl;
        std::cout << "  hash: " << hash_name << std::endl;
        std::cout << "  cdhash: " << to_hex(info.cd_hash) << std::endl;
        std::cout << "  flags: 0x" << std::hex << info.flags << std::dec << std::endl;
        std::cout << "  version: 0x" << std::hex << info.version << std::dec << std::endl;
        std::cout << "  adhoc: " << (info.adhoc ? "true" : "false") << std::endl;
        std::cout << "  cms: " << (info.cms_signature.empty() ? "false" : "true") << std::endl;
        std::cout << "  entitlements: " << (info.entitlements_xml.empty() ? "false" : "true") << std::endl;
        std::cout << "  der-entitlements: " << (info.entitlements_der.empty() ? "false" : "true") << std::endl;
        std::cout << "  requirements: " << (info.requirements_blob.empty() ? "false" : "true") << std::endl;
    }
}

void Display::display_entitlements(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.entitlements_xml.empty()) {
        std::cout << info.entitlements_xml;
    }
}

std::string decode_requirement_expression(const std::vector<uint8_t>& data, size_t& pos, unsigned depth = 0) {
    if (depth > 128 || pos > data.size() || data.size() - pos < 4) return {};
    auto has = [](uint32_t op, RequirementOpcode value) {
        return op == requirement_opcode_value(value);
    };
    auto read_string = [&](std::string& out) -> bool {
        if (pos > data.size() || data.size() - pos < 4) return false;
        const uint32_t length = load_be32(data.data() + pos);
        pos += 4;
        if (length > data.size() - pos) return false;
        out.assign(reinterpret_cast<const char*>(data.data() + pos), length);
        pos += length;
        while ((pos & 3U) != 0) {
            if (pos >= data.size()) return false;
            ++pos;
        }
        return true;
    };
    auto read_u32 = [&](uint32_t& value) -> bool {
        if (pos > data.size() || data.size() - pos < 4) return false;
        value = load_be32(data.data() + pos);
        pos += 4;
        return true;
    };
    auto cert_name = [](uint32_t cert) {
        return cert == 0 ? std::string("leaf") :
               cert == 0xFFFFFFFFU ? std::string("root") : std::to_string(cert);
    };
    auto match_suffix = [](uint32_t match) -> const char* {
        switch (match) {
            case 1: return "=";
            case 2: return "*=";
            case 3: return "^=";
            case 4: return "$=";
            case 5: return "<";
            case 6: return ">";
            case 7: return "<=";
            case 8: return ">=";
            case 9: return "on";
            case 10: return "before";
            case 11: return "after";
            case 12: return "on-or-before";
            case 13: return "on-or-after";
            default: return "=";
        }
    };

    const uint32_t op = load_be32(data.data() + pos);
    pos += 4;
    if (has(op, RequirementOpcode::FALSE_EXPR)) return "false";
    if (has(op, RequirementOpcode::TRUE_EXPR)) return "true";
    if (has(op, RequirementOpcode::IDENTIFIER)) {
        std::string value;
        return read_string(value) ? "identifier \"" + value + "\"" : std::string();
    }
    if (has(op, RequirementOpcode::APPLE_ANCHOR)) return "anchor apple";
    if (has(op, RequirementOpcode::ANCHOR_HASH)) {
        if (pos > data.size() || data.size() - pos < 20) return {};
        std::vector<uint8_t> hash(data.begin() + static_cast<std::ptrdiff_t>(pos), data.begin() + static_cast<std::ptrdiff_t>(pos + 20));
        pos += 20;
        return "anchor = H\"" + hex_encode(hash) + "\"";
    }
    if (has(op, RequirementOpcode::CDHASH)) {
        if (pos > data.size() || data.size() - pos < 20) return {};
        std::vector<uint8_t> hash(data.begin() + static_cast<std::ptrdiff_t>(pos), data.begin() + static_cast<std::ptrdiff_t>(pos + 20));
        pos += 20;
        return "cdhash H\"" + hex_encode(hash) + "\"";
    }
    if (has(op, RequirementOpcode::INFO_KEY_VALUE)) {
        std::string key, value;
        if (!read_string(key) || !read_string(value)) return {};
        return "info[\"" + key + "\"] = \"" + value + "\"";
    }
    if (has(op, RequirementOpcode::AND_EXPR) || has(op, RequirementOpcode::OR_EXPR)) {
        auto lhs = decode_requirement_expression(data, pos, depth + 1);
        auto rhs = decode_requirement_expression(data, pos, depth + 1);
        if (lhs.empty() || rhs.empty()) return {};
        return "(" + lhs + ") " + (has(op, RequirementOpcode::AND_EXPR) ? "and" : "or") + " (" + rhs + ")";
    }
    if (has(op, RequirementOpcode::NOT_EXPR)) {
        auto child = decode_requirement_expression(data, pos, depth + 1);
        return child.empty() ? std::string() : "not (" + child + ")";
    }
    if (has(op, RequirementOpcode::INFO_KEY_FIELD) || has(op, RequirementOpcode::ENTITLEMENT_FIELD)) {
        std::string field;
        uint32_t match = 0;
        if (!read_string(field) || !read_u32(match)) return {};
        const std::string prefix = has(op, RequirementOpcode::INFO_KEY_FIELD) ? "info" : "entitlement";
        if (match == 0) return prefix + "[\"" + field + "\"] exists";
        if (match == 14) return prefix + "[\"" + field + "\"] absent";
        std::string value;
        if (!read_string(value)) return {};
        return prefix + "[\"" + field + "\"] " + match_suffix(match) + " \"" + value + "\"";
    }
    if (has(op, RequirementOpcode::CERT_FIELD) || has(op, RequirementOpcode::CERT_FIELD_DATE)) {
        uint32_t cert = 0, match = 0;
        std::string field, value;
        if (!read_u32(cert) || !read_string(field) || !read_u32(match)) return {};
        const std::string prefix = "certificate " + cert_name(cert) + "[" + field + "]";
        if (match == 0) return prefix + " exists";
        if (match == 14) return prefix + " absent";
        if (!read_string(value)) return {};
        return prefix + " " + match_suffix(match) + " \"" + value + "\"";
    }
    if (has(op, RequirementOpcode::TRUSTED_CERT)) {
        uint32_t cert = 0;
        if (!read_u32(cert)) return {};
        return "trusted certificate " + cert_name(cert);
    }
    if (has(op, RequirementOpcode::TRUSTED_CERTS)) return "trusted certificate chain";
    if (has(op, RequirementOpcode::CERT_GENERIC) || has(op, RequirementOpcode::CERT_POLICY)) {
        uint32_t cert = 0, match = 0;
        std::string oid_bytes, value;
        if (!read_u32(cert) || !read_string(oid_bytes) || !read_u32(match)) return {};
        std::vector<uint8_t> oid(oid_bytes.begin(), oid_bytes.end());
        const std::string prefix = "certificate " + cert_name(cert) +
            (has(op, RequirementOpcode::CERT_POLICY) ? "[policy." : "[field.") + hex_encode(oid) + "]";
        if (match == 0) return prefix + " exists";
        if (match == 14) return prefix + " absent";
        if (!read_string(value)) return {};
        return prefix + " " + match_suffix(match) + " \"" + value + "\"";
    }
    if (has(op, RequirementOpcode::APPLE_GENERIC_ANCHOR)) return "anchor apple generic";
    if (has(op, RequirementOpcode::NAMED_ANCHOR) || has(op, RequirementOpcode::NAMED_CODE)) {
        std::string name;
        if (!read_string(name)) return {};
        return std::string(has(op, RequirementOpcode::NAMED_ANCHOR) ? "named-anchor \"" : "named-code \"") + name + "\"";
    }
    if (has(op, RequirementOpcode::PLATFORM)) {
        uint32_t platform = 0;
        if (!read_u32(platform)) return {};
        return "platform = " + std::to_string(platform);
    }
    if (has(op, RequirementOpcode::NOTARIZED)) return "notarized";
    if (has(op, RequirementOpcode::LEGACY_DEVID)) return "legacy developer ID";
    return "<unsupported opcode " + std::to_string(op) + ">";
}

std::string format_requirements_blob(const std::vector<uint8_t>& blob) {
    if (blob.size() < 20 || load_be32(blob.data()) != 0xfade0c01U) return {};
    const uint32_t count = load_be32(blob.data() + 8);
    if (count == 0 || static_cast<uint64_t>(count) > (blob.size() - 12) / 8) return {};
    for (uint32_t i = 0; i < count; ++i) {
        const size_t entry = 12 + static_cast<size_t>(i) * 8;
        if (entry > blob.size() || blob.size() - entry < 8) return {};
        const uint32_t type = load_be32(blob.data() + entry);
        const size_t offset = load_be32(blob.data() + entry + 4);
        if (type != 3) continue;
        if (offset > blob.size() || blob.size() - offset < 12) return {};
        const size_t length = load_be32(blob.data() + offset + 4);
        if (load_be32(blob.data() + offset) != 0xfade0c00U || length < 12 || length > blob.size() - offset) return {};
        if (load_be32(blob.data() + offset + 8) != 1) return {};
        std::vector<uint8_t> expression(blob.begin() + static_cast<std::ptrdiff_t>(offset + 12),
                                        blob.begin() + static_cast<std::ptrdiff_t>(offset + length));
        size_t pos = 0;
        auto result = decode_requirement_expression(expression, pos);
        if (result.empty() || pos != expression.size()) return {};
        return result;
    }
    return {};
}

void Display::display_requirements(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.requirements_blob.empty()) {
        auto readable = format_requirements_blob(info.requirements_blob);
        if (!readable.empty()) std::cout << readable << std::endl;
        else std::cout << to_hex(info.requirements_blob) << std::endl;
    }
}

void Display::display_cdhash(const std::filesystem::path& path) {
    auto data = read_file(path);
    if (!MachOParser::is_macho(data)) return;
    auto info = MachOParser::get_signature_info(data);
    if (!info.cd_hash.empty()) {
        std::cout << to_hex(info.cd_hash) << std::endl;
    }
}

void Display::display_archive_contents(const std::filesystem::path& path) {
    auto entries = ArchiveEngine::list_contents(path);
    for (auto& entry : entries) {
        std::cout << entry.path;
        if (entry.is_directory) std::cout << "/";
        std::cout << " " << entry.size << std::endl;
    }
}

std::string x509_name_string(X509_NAME* name) {
    if (!name) return {};
    BIO* bio = BIO_new(BIO_s_mem());
    if (!bio) return {};
    if (X509_NAME_print_ex(bio, name, 0, XN_FLAG_RFC2253) < 0) { BIO_free(bio); return {}; }
    char* buffer = nullptr; long length = BIO_get_mem_data(bio, &buffer);
    std::string result = (buffer && length > 0) ? std::string(buffer, static_cast<size_t>(length)) : std::string();
    BIO_free(bio);
    return result;
}

void Display::display_certificates(const std::filesystem::path& path) {
    auto certs = CryptoEngine::extract_certs_raw(path.string());
    std::cout << "certificates: " << certs.size() << std::endl;
    size_t index = 0;
    for (auto& cert : certs) {
        const unsigned char* cursor = cert.data();
        X509Ptr certificate(d2i_X509(nullptr, &cursor, static_cast<long>(cert.size())));
        if (!certificate.get()) {
            std::cout << "certificate " << index << ": invalid" << std::endl;
        } else {
            std::cout << "certificate " << index << std::endl;
            std::cout << "  subject: " << x509_name_string(X509_get_subject_name(certificate.get())) << std::endl;
            std::cout << "  issuer: " << x509_name_string(X509_get_issuer_name(certificate.get())) << std::endl;
            std::cout << "  size: " << cert.size() << std::endl;
        }
        ++index;
    }
}

std::vector<uint8_t> read_file(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
}

bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data) {
    if (path.has_parent_path()) {
        std::error_code ec;
        std::filesystem::create_directories(path.parent_path(), ec);
    }
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return false;
    output.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    return static_cast<bool>(output);
}

std::string read_text(const std::filesystem::path& path) {
    auto bytes = read_file(path);
    return std::string(bytes.begin(), bytes.end());
}

bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::vector<uint8_t> bytes(text.begin(), text.end());
    return write_file(path, bytes);
}

std::string to_hex(const std::vector<uint8_t>& data) {
    return hex_encode(data);
}

std::vector<uint8_t> from_hex(const std::string& hex) {
    return hex_decode(hex);
}

std::string default_identifier_from_path(const std::filesystem::path& path) {
    auto stem = path.stem().string();
    if (stem.empty()) return "ldid-binary";
    return stem;
}

}

namespace {

std::string required_option_value(const std::string& arg, const std::string& prefix, int argc, char** argv, int& index) {
    if (arg.size() > prefix.size()) return arg.substr(prefix.size());
    if (index + 1 < argc) {
        ++index;
        return argv[index];
    }
    return {};
}

std::string optional_option_value(const std::string& arg, const std::string& prefix, int argc, char** argv, int& index) {
    if (arg.size() > prefix.size()) return arg.substr(prefix.size());
    if (index + 1 < argc && argv[index + 1][0] != '-') {
        ++index;
        return argv[index];
    }
    return {};
}

std::pair<uint32_t, bool> cd_flag_from_name(const std::string& raw_name) {
    std::string name = raw_name;
    std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    bool clear = false;
    if (name.rfind("no-", 0) == 0) {
        clear = true;
        name = name.substr(3);
    }
    uint32_t bit = 0;
    if (name == "host") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::VALID);
    else if (name == "adhoc") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC);
    else if (name == "hard") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::HARD);
    else if (name == "kill") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::KILL);
    else if (name == "expires" || name == "check-expiration") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::CHECK_EXPIRATION);
    else if (name == "restrict") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::RESTRICT);
    else if (name == "enforcement") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::ENFORCEMENT);
    else if (name == "library-validation") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::LIBRARY_VALIDATION);
    else if (name == "runtime") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::RUNTIME);
    else if (name == "linker-signed") bit = static_cast<uint32_t>(ldid::CodeDirectoryFlag::LINKER_SIGNED);
    return {bit, clear};
}

void apply_cd_flags(const std::string& text, uint32_t& flags) {
    size_t start = 0;
    while (start < text.size()) {
        size_t end = text.find_first_of(", ", start);
        if (end == std::string::npos) end = text.size();
        std::string token = text.substr(start, end - start);
        if (!token.empty()) {
            auto parsed = cd_flag_from_name(token);
            uint32_t bit = parsed.first;
            if (bit != 0) {
                if (parsed.second) flags &= ~bit;
                else flags |= bit;
            }
        }
        start = end + 1;
    }
}

uint32_t parse_version_value(const std::string& value) {
    if (value.empty()) throw std::invalid_argument("invalid version");
    std::stringstream stream(value);
    std::string part;
    uint32_t components[3] = {0, 0, 0};
    size_t count = 0;
    while (std::getline(stream, part, '.')) {
        if (part.empty() || count >= 3) throw std::invalid_argument("invalid version");
        try {
            size_t parsed = 0;
            unsigned long component = std::stoul(part, &parsed, 10);
            if (parsed != part.size() || component > 0xFFUL) throw std::invalid_argument("invalid version: " + value);
            components[count++] = static_cast<uint32_t>(component);
        } catch (const std::exception&) {
            throw std::invalid_argument("invalid version: " + value);
        }
    }
    return (components[0] << 16) | (components[1] << 8) | components[2];
}

ldid::HashType parse_hash_type(const std::string& value) {
    std::string lowered = value;
    std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    if (lowered == "sha1" || lowered == "1") return ldid::HashType::SHA1;
    if (lowered == "sha256" || lowered == "2") return ldid::HashType::SHA256;
    if (lowered == "sha256-truncated" || lowered == "sha256_160" || lowered == "3") return ldid::HashType::SHA256_TRUNCATED;
    if (lowered == "sha384" || lowered == "4") return ldid::HashType::SHA384;
    return ldid::HashType::ANY;
}

ldid::Platform parse_platform(const std::string& value) {
    std::string v = value;
    std::transform(v.begin(), v.end(), v.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (v == "macos" || v == "macosx") return ldid::Platform::MACOS;
    if (v == "ios") return ldid::Platform::IOS;
    if (v == "tvos") return ldid::Platform::TVOS;
    if (v == "watchos") return ldid::Platform::WATCHOS;
    if (v == "bridgeos") return ldid::Platform::BRIDGEOS;
    if (v == "maccatalyst") return ldid::Platform::MACCATALYST;
    if (v == "iossimulator") return ldid::Platform::IOSSIMULATOR;
    if (v == "tvossimulator") return ldid::Platform::TVOSSIMULATOR;
    if (v == "watchossimulator") return ldid::Platform::WATCHOSSIMULATOR;
    if (v == "driverkit") return ldid::Platform::DRIVERKIT;
    try {
        size_t parsed = 0;
        unsigned long numeric = std::stoul(v, &parsed, 10);
        if (parsed != v.size()) throw std::invalid_argument("invalid platform");
        return static_cast<ldid::Platform>(numeric);
    } catch (...) {
        std::cerr << "ldid: unknown platform: " << value << std::endl;
        return ldid::Platform::UNKNOWN;
    }
}

// Custom signature CLI: JSON template, inspection, classification and one-pass validation.
struct CustomTemplateLoad {
    ldid::SignOptions options;
    ldid::VerificationOptions verification;
    std::vector<std::string> errors;
    std::vector<std::string> warnings;
    std::string classification_hint;
};

std::string plist_scalar_string(plist_t node) {
    if (!node) return {};
    switch (plist_get_node_type(node)) {
        case PLIST_STRING: {
            char* value = nullptr; plist_get_string_val(node, &value);
            std::string out = value ? value : ""; free(value); return out;
        }
        case PLIST_UINT: {
            uint64_t value = 0; plist_get_uint_val(node, &value); return std::to_string(value);
        }
        case PLIST_BOOLEAN: {
            uint8_t value = 0; plist_get_bool_val(node, &value); return value ? "true" : "false";
        }
        default: return {};
    }
}

plist_t plist_child(plist_t dict, const char* key) {
    return dict && plist_get_node_type(dict) == PLIST_DICT ? plist_dict_get_item(dict, key) : nullptr;
}

std::string cfg_string(plist_t dict, const char* key) {
    return plist_scalar_string(plist_child(dict, key));
}

bool cfg_bool(plist_t dict, const char* key, bool fallback = false) {
    plist_t node = plist_child(dict, key);
    if (!node || plist_get_node_type(node) != PLIST_BOOLEAN) return fallback;
    uint8_t value = 0; plist_get_bool_val(node, &value); return value != 0;
}

uint64_t parse_cfg_uint(const std::string& value, const std::string& label, bool allow_dotted = false) {
    if (value.empty()) throw std::invalid_argument(label + " is empty");
    if (allow_dotted && value.find('.') != std::string::npos) return parse_version_value(value);
    size_t used = 0;
    unsigned long long parsed = 0;
    try { parsed = std::stoull(value, &used, 0); }
    catch (...) { throw std::invalid_argument("invalid " + label + ": " + value); }
    if (used != value.size()) throw std::invalid_argument("invalid " + label + ": " + value);
    return static_cast<uint64_t>(parsed);
}

std::vector<uint8_t> parse_cfg_hex(const std::string& text, const std::string& label) {
    if (text.empty()) return {};
    std::string compact;
    compact.reserve(text.size());
    for (unsigned char c : text) {
        if (std::isspace(c) || c == ':' || c == '-') continue;
        compact.push_back(static_cast<char>(c));
    }
    if (compact.size() % 2 != 0) throw std::invalid_argument(label + " must contain an even number of hexadecimal digits");
    auto bytes = ldid::from_hex(compact);
    if (bytes.size() != compact.size() / 2) throw std::invalid_argument(label + " contains invalid hexadecimal characters");
    return bytes;
}

// Optional per-user defaults and named signing profiles. CLI arguments are parsed
// afterwards and therefore always override these values.
std::string json_escape(const std::string& input) {
    std::string out;
    out.reserve(input.size() + 16);
    static const char hex[] = "0123456789abcdef";
    for (unsigned char c : input) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) { out += "\\u00"; out.push_back(hex[c >> 4]); out.push_back(hex[c & 0xf]); }
                else out.push_back(static_cast<char>(c));
        }
    }
    return out;
}

void apply_ldidrc_section(plist_t section, ldid::SignOptions& options,
                          ldid::VerificationOptions& verification) {
    if (!section || plist_get_node_type(section) != PLIST_DICT) return;
    auto assign_string = [&](const char* key, std::string& target) {
        const auto value = cfg_string(section, key);
        if (!value.empty()) target = value;
    };
    assign_string("identifier", options.identifier);
    assign_string("teamID", options.team_id);
    assign_string("entitlements", options.entitlements_path);
    assign_string("mergeEntitlements", options.merge_entitlements_path);
    assign_string("certificate", options.certificate_path);
    assign_string("privateKey", options.private_key_path);
    assign_string("p12", options.p12_path);
    assign_string("password", options.key_password);
    assign_string("timestampURL", options.timestamp_url);
    assign_string("timestampPolicy", options.timestamp_policy);
    assign_string("timestampCAFile", options.timestamp_ca_file);
    assign_string("timestampCAPath", options.timestamp_ca_path);
    const auto hash = cfg_string(section, "hashType");
    if (!hash.empty()) {
        const auto parsed = parse_hash_type(hash);
        if (parsed == ldid::HashType::ANY) throw std::invalid_argument("ldidrc: invalid hashType: " + hash);
        options.hash_type = parsed;
    }
    const auto platform = cfg_string(section, "platform");
    if (!platform.empty()) {
        const auto parsed = parse_platform(platform);
        if (parsed == ldid::Platform::UNKNOWN) throw std::invalid_argument("ldidrc: invalid platform: " + platform);
        options.platform = parsed;
    }
    const auto min_os = cfg_string(section, "minOS");
    if (!min_os.empty()) options.min_os_version = parse_version_value(min_os);
    const auto sdk = cfg_string(section, "sdkVersion");
    if (!sdk.empty()) options.sdk_version = parse_version_value(sdk);
    const auto flags = cfg_string(section, "flags");
    if (!flags.empty()) apply_cd_flags(flags, options.cd_flags);
    const auto jobs = cfg_string(section, "jobs");
    if (!jobs.empty()) {
        const auto parsed = parse_cfg_uint(jobs, "jobs");
        if (parsed > 64) throw std::invalid_argument("ldidrc jobs must be <= 64");
        options.jobs = static_cast<uint32_t>(parsed);
    }
    options.adhoc = cfg_bool(section, "adhoc", options.adhoc);
    options.deep = cfg_bool(section, "deep", options.deep);
    options.super_deep = cfg_bool(section, "superDeep", options.super_deep);
    options.force = cfg_bool(section, "force", options.force);
    options.preserve_entitlements = cfg_bool(section, "preserveEntitlements", options.preserve_entitlements);
    options.merge_only = cfg_bool(section, "mergeOnly", options.merge_only);
    options.merge_entitlements_deep = cfg_bool(section, "mergeDeep", options.merge_entitlements_deep);
    options.runtime = cfg_bool(section, "runtime", options.runtime);
    options.library_validation = cfg_bool(section, "libraryValidation", options.library_validation);
    options.linker_signed = cfg_bool(section, "linkerSigned", options.linker_signed);
    options.timestamp_enabled = cfg_bool(section, "timestamp", options.timestamp_enabled);
    options.timestamp_required = cfg_bool(section, "timestampRequired", options.timestamp_required);
    options.timestamp_require_root = cfg_bool(section, "timestampRequireRoot", options.timestamp_require_root);
    options.emit_signing_time = cfg_bool(section, "signingTime", options.emit_signing_time);
    verification.certificate_chain.enabled = cfg_bool(section, "verifyChain", verification.certificate_chain.enabled);
    verification.certificate_chain.require_root = cfg_bool(section, "verifyChainRoot", verification.certificate_chain.require_root);
    assign_string("caFile", verification.certificate_chain.ca_file);
    assign_string("caPath", verification.certificate_chain.ca_path);
    const auto verify_time = cfg_string(section, "verifyTime");
    if (!verify_time.empty()) verification.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(verify_time, "verifyTime"));
    if (verification.certificate_chain.require_root) verification.certificate_chain.enabled = true;
}

std::filesystem::path resolve_ldid_config_path() {
    if (const char* explicit_path = std::getenv("LDID_CONFIG")) {
        if (*explicit_path) return explicit_path;
    }
    if (const char* home = std::getenv("HOME")) {
        if (*home) return std::filesystem::path(home) / ".ldidrc";
    }
    return {};
}

void load_ldid_config(ldid::SignOptions& options, ldid::VerificationOptions& verification,
                      const std::string& profile_name, const std::filesystem::path& explicit_config = {}) {
    const auto path = explicit_config.empty() ? resolve_ldid_config_path() : explicit_config;
    if (path.empty()) return;
    std::error_code ec;
    if (!std::filesystem::exists(path, ec)) {
        const char* env_config = std::getenv("LDID_CONFIG");
        if (!explicit_config.empty() || (env_config && *env_config) || !profile_name.empty())
            throw std::runtime_error("configured LDID_CONFIG file does not exist: " + path.string());
        return;
    }
    const auto text = ldid::read_text(path);
    if (text.empty() || text.size() > 1024U * 1024U) throw std::runtime_error("ldid config is empty or exceeds 1 MiB: " + path.string());
    plist_t root = nullptr;
    if (plist_from_json(text.data(), static_cast<uint32_t>(text.size()), &root) != PLIST_ERR_SUCCESS || !root)
        throw std::runtime_error("cannot parse ldid config JSON: " + path.string());
    struct Guard { plist_t p; ~Guard() { if (p) plist_free(p); } } guard{root};
    if (plist_get_node_type(root) != PLIST_DICT) throw std::runtime_error("ldid config root must be a JSON object");
    apply_ldidrc_section(plist_child(root, "defaults"), options, verification);
    if (!profile_name.empty()) {
        plist_t profiles = plist_child(root, "profiles");
        plist_t profile = plist_child(profiles, profile_name.c_str());
        if (!profile) throw std::invalid_argument("ldid config profile not found: " + profile_name);
        apply_ldidrc_section(profile, options, verification);
    }
}

const char* custom_signature_template_json() {
    return R"JSON({
  "schema": "ldid.custom-signature",
  "schemaVersion": 1,
  "classification": { "requested": "auto" },
  "signing": {
    "identifier": "", "teamID": "", "hashType": "", "adhoc": "",
    "flagsSet": "", "flagsClear": "", "platformIdentifier": ""
  },
  "codeDirectory": {
    "version": "", "pageSize": "", "identifier": "", "teamID": "",
    "platform": "", "flagsSet": "", "flagsClear": "",
    "execSegBase": "", "execSegLimit": "", "execSegFlags": "", "runtime": "",
    "scatterHex": "", "preEncryptHashesHex": "",
    "linkage": { "hashType": "", "applicationType": "", "applicationSubType": "", "dataHex": "" }
  },
  "alternateCodeDirectories": [],
  "requirements": { "designatedExpression": "", "overallBlobHex": "" },
  "entitlements": { "xml": "" },
  "appleInternalProfile": {
    "enabled": false, "profilePath": "", "embed": true,
    "requireDEREncodedProfile": false
  },
  "specialSlots": {
    "infoPlistHex": "", "requirementsBlobHex": "", "codeResourcesHex": "",
    "applicationDataHex": "", "entitlementsBlobHex": "", "repSpecificHex": "",
    "derEntitlementsBlobHex": "", "launchConstraintSelfBlobHex": "",
    "launchConstraintParentBlobHex": "", "launchConstraintResponsibleBlobHex": "",
    "libraryConstraintBlobHex": ""
  },
  "cms": {
    "rawDERHex": "", "emitSigningTime": true,
    "timestampEnabled": false, "timestampRequired": false,
    "timestampURL": "", "timestampPolicy": "", "timestampCAFile": "", "timestampCAPath": "", "timestampRequireRoot": false
  },
  "customBlobs": [],
  "raw": { "embeddedSuperBlobHex": "" },
  "validation": {
    "checkStructure": true, "checkPageHashes": true, "checkSpecialSlots": true,
    "checkCMSMath": true, "checkEntitlementsDER": true, "checkResources": true,
    "checkAllArchitectures": true, "checkCertificateChain": false,
    "requireChainToRoot": false, "caFile": "", "caPath": "", "verificationTime": ""
  }
})JSON";
}

std::string apple_internal_signature_template_json() {
    std::string json = custom_signature_template_json();
    const auto replace_once = [&](const std::string& from, const std::string& to) {
        const auto position = json.find(from);
        if (position == std::string::npos) throw std::logic_error("cannot construct Apple Internal template: missing schema fragment");
        json.replace(position, from.size(), to);
    };
    replace_once("\"requested\": \"auto\"", "\"requested\": \"apple-internal-profile\"");
    replace_once("\"identifier\": \"\", \"teamID\": \"\", \"hashType\": \"\", \"adhoc\": \"\"",
                 "\"identifier\": \"\", \"teamID\": \"\", \"hashType\": \"sha256\", \"adhoc\": false");
    replace_once("\"enabled\": false, \"profilePath\": \"\", \"embed\": true,",
                 "\"enabled\": true, \"profilePath\": \"\", \"embed\": true,");
    replace_once("\"checkCertificateChain\": false,\n    \"requireChainToRoot\": false",
                 "\"checkCertificateChain\": true,\n    \"requireChainToRoot\": true");
    return json;
}

CustomTemplateLoad load_custom_template(const std::filesystem::path& path) {
    CustomTemplateLoad loaded;
    loaded.options.custom_signature.enabled = true;
    const std::string json = ldid::read_text(path);
    if (json.empty() || json.size() > 16U * 1024U * 1024U) throw std::runtime_error("custom signature template is empty or exceeds 16 MiB");
    plist_t root = nullptr;
    if (plist_from_json(json.data(), static_cast<uint32_t>(json.size()), &root) != PLIST_ERR_SUCCESS || !root)
        throw std::invalid_argument("invalid custom signature JSON");
    struct PlistGuard { plist_t p; ~PlistGuard() { if (p) plist_free(p); } } guard{root};
    if (plist_get_node_type(root) != PLIST_DICT) throw std::invalid_argument("custom signature template root must be an object");
    if (cfg_string(root, "schema") != "ldid.custom-signature") loaded.errors.push_back("schema must equal 'ldid.custom-signature'");
    const std::string schema_version = cfg_string(root, "schemaVersion");
    if (schema_version != "1") loaded.errors.push_back("unsupported schemaVersion (expected 1)");

    plist_t classification = plist_child(root, "classification");
    loaded.classification_hint = cfg_string(classification, "requested");
    if (loaded.classification_hint.empty()) loaded.classification_hint = "auto";
    if (loaded.classification_hint != "auto" && loaded.classification_hint != "adhoc" &&
        loaded.classification_hint != "development" && loaded.classification_hint != "ad-hoc" &&
        loaded.classification_hint != "app-store-connect" && loaded.classification_hint != "app-store-managed" &&
        loaded.classification_hint != "testflight" && loaded.classification_hint != "developer-distribution" &&
        loaded.classification_hint != "ad-hoc" && loaded.classification_hint != "enterprise" &&
        loaded.classification_hint != "apple-system" && loaded.classification_hint != "apple-internal-profile" &&
        loaded.classification_hint != "macos-developer-id") {
        loaded.errors.push_back("classification.requested has an unknown value; use auto or a documented label");
    }
    if (loaded.classification_hint != "auto") loaded.warnings.push_back("classification.requested is descriptive only; it cannot manufacture Apple trust, certificates, provisioning profiles, or system platform status");

    plist_t signing = plist_child(root, "signing");
    loaded.options.identifier = cfg_string(signing, "identifier");
    loaded.options.team_id = cfg_string(signing, "teamID");
    loaded.options.adhoc = cfg_bool(signing, "adhoc", false);
    const auto sign_hash = cfg_string(signing, "hashType");
    if (!sign_hash.empty()) {
        loaded.options.hash_type = parse_hash_type(sign_hash);
        if (loaded.options.hash_type == ldid::HashType::ANY) loaded.errors.push_back("signing.hashType must be sha1, sha256, sha256-truncated, or sha384");
    }
    auto optional_flag = [&](plist_t dict, const char* key, uint32_t& out) {
        const auto value = cfg_string(dict, key);
        if (!value.empty()) {
            try { const auto parsed = parse_cfg_uint(value, key); if (parsed > UINT32_MAX) throw std::out_of_range(key); out = static_cast<uint32_t>(parsed); }
            catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
        }
    };
    optional_flag(signing, "flagsSet", loaded.options.custom_signature.flags_set);
    optional_flag(signing, "flagsClear", loaded.options.custom_signature.flags_clear);
    const auto signing_platform = cfg_string(signing, "platformIdentifier");
    if (!signing_platform.empty()) {
        try { auto n = parse_cfg_uint(signing_platform, "signing.platformIdentifier"); if (n > 255) throw std::out_of_range("signing.platformIdentifier exceeds 255"); loaded.options.custom_signature.platform = static_cast<uint8_t>(n); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    }

    plist_t internal_profile = plist_child(root, "appleInternalProfile");
    loaded.options.apple_internal_profile.enabled = cfg_bool(internal_profile, "enabled", false);
    loaded.options.apple_internal_profile.embed_profile = cfg_bool(internal_profile, "embed", true);
    loaded.options.apple_internal_profile.require_der_encoded_profile = cfg_bool(internal_profile, "requireDEREncodedProfile", false);
    const auto profile_source = cfg_string(internal_profile, "profilePath");
    if (!profile_source.empty()) {
        std::filesystem::path source_path(profile_source);
        if (source_path.is_relative()) source_path = path.parent_path() / source_path;
        loaded.options.apple_internal_profile.source_path = source_path.lexically_normal().string();
    }
    if (loaded.options.apple_internal_profile.enabled) {
        if (loaded.options.adhoc)
            loaded.errors.push_back("Apple Internal profile policy does not permit ad-hoc signing");
        if (!loaded.options.apple_internal_profile.embed_profile && !loaded.options.apple_internal_profile.source_path.empty())
            loaded.errors.push_back("appleInternalProfile.profilePath requires embed=true; otherwise place embedded.mobileprovision in the app bundle");
    }

    plist_t cd = plist_child(root, "codeDirectory");
    auto set_u32 = [&](const char* key, std::optional<uint32_t>& target, bool dotted = false) {
        const auto value = cfg_string(cd, key); if (value.empty()) return;
        try { const auto number = parse_cfg_uint(value, std::string("codeDirectory.") + key, dotted); if (number > UINT32_MAX) throw std::out_of_range(key); target = static_cast<uint32_t>(number); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    };
    auto set_u64 = [&](const char* key, std::optional<uint64_t>& target) {
        const auto value = cfg_string(cd, key); if (value.empty()) return;
        try { target = parse_cfg_uint(value, std::string("codeDirectory.") + key); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    };
    set_u32("version", loaded.options.custom_signature.code_directory_version, true);
    set_u32("pageSize", loaded.options.custom_signature.page_size);
    set_u32("runtime", loaded.options.custom_signature.runtime_version, true);
    set_u64("execSegBase", loaded.options.custom_signature.exec_segment_base);
    set_u64("execSegLimit", loaded.options.custom_signature.exec_segment_limit);
    set_u64("execSegFlags", loaded.options.custom_signature.exec_segment_flags);
    optional_flag(cd, "flagsSet", loaded.options.custom_signature.flags_set);
    optional_flag(cd, "flagsClear", loaded.options.custom_signature.flags_clear);
    const auto cd_identifier = cfg_string(cd, "identifier");
    if (!cd_identifier.empty()) loaded.options.identifier = cd_identifier;
    const auto cd_team = cfg_string(cd, "teamID");
    if (!cd_team.empty()) loaded.options.team_id = cd_team;
    const auto cd_hash_type = cfg_string(cd, "hashType");
    if (!cd_hash_type.empty()) {
        const auto parsed_hash = parse_hash_type(cd_hash_type);
        if (parsed_hash == ldid::HashType::ANY) loaded.errors.push_back("codeDirectory.hashType must be sha1, sha256, sha256-truncated, or sha384");
        else loaded.options.hash_type = parsed_hash;
    }
    const auto cd_platform = cfg_string(cd, "platform");
    if (!cd_platform.empty()) {
        const auto plat = parse_platform(cd_platform);
        if (plat == ldid::Platform::UNKNOWN && cd_platform != "0") loaded.errors.push_back("unknown codeDirectory.platform");
        else loaded.options.custom_signature.platform = static_cast<uint8_t>(plat);
    }
    try {
        const auto scatter = cfg_string(cd, "scatterHex"); if (!scatter.empty()) loaded.options.custom_signature.scatter_data = parse_cfg_hex(scatter, "codeDirectory.scatterHex");
        const auto pre = cfg_string(cd, "preEncryptHashesHex"); if (!pre.empty()) loaded.options.custom_signature.pre_encrypt_hashes = parse_cfg_hex(pre, "codeDirectory.preEncryptHashesHex");
    } catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    plist_t linkage = plist_child(cd, "linkage");
    auto link_u8 = [&](const char* key, std::optional<uint8_t>& target) {
        const auto value = cfg_string(linkage, key); if (value.empty()) return;
        try { auto n = parse_cfg_uint(value, key); if (n > UINT8_MAX) throw std::out_of_range(key); target = static_cast<uint8_t>(n); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    };
    link_u8("hashType", loaded.options.custom_signature.linkage_hash_type);
    link_u8("applicationType", loaded.options.custom_signature.linkage_application_type);
    const auto link_sub = cfg_string(linkage, "applicationSubType");
    if (!link_sub.empty()) { try { auto n = parse_cfg_uint(link_sub, "linkage.applicationSubType"); if (n > UINT16_MAX) throw std::out_of_range("linkage.applicationSubType"); loaded.options.custom_signature.linkage_application_subtype = static_cast<uint16_t>(n); } catch (const std::exception& e) { loaded.errors.push_back(e.what()); } }
    try { const auto data = cfg_string(linkage, "dataHex"); if (!data.empty()) loaded.options.custom_signature.linkage_data = parse_cfg_hex(data, "linkage.dataHex"); }
    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }

    plist_t alternates = plist_child(root, "alternateCodeDirectories");
    if (alternates) {
        if (plist_get_node_type(alternates) != PLIST_ARRAY) loaded.errors.push_back("alternateCodeDirectories must be an array");
        else {
            const uint32_t n = plist_array_get_size(alternates);
            if (n > 5) loaded.errors.push_back("at most five alternate CodeDirectories are supported");
            for (uint32_t i = 0; i < n && i < 5; ++i) {
                plist_t entry = plist_array_get_item(alternates, i);
                ldid::AlternateCodeDirectoryOptions alt;
                const auto hash_text = cfg_string(entry, "hashType");
                if (!hash_text.empty()) {
                    alt.hash_type = parse_hash_type(hash_text);
                    if (alt.hash_type == ldid::HashType::ANY) loaded.errors.push_back("alternateCodeDirectories[" + std::to_string(i) + "].hashType is invalid");
                }
                auto alt_u32 = [&](const char* key, std::optional<uint32_t>& target, bool dotted = false) {
                    const auto value = cfg_string(entry, key); if (value.empty()) return;
                    try { auto number = parse_cfg_uint(value, std::string("alternateCodeDirectories[") + std::to_string(i) + "]." + key, dotted); if (number > UINT32_MAX) throw std::out_of_range(key); target = static_cast<uint32_t>(number); }
                    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                };
                auto alt_u64 = [&](const char* key, std::optional<uint64_t>& target) {
                    const auto value = cfg_string(entry, key); if (value.empty()) return;
                    try { target = parse_cfg_uint(value, std::string("alternateCodeDirectories[") + std::to_string(i) + "]." + key); }
                    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                };
                alt_u32("version", alt.version, true);
                alt_u32("pageSize", alt.page_size);
                alt_u32("runtime", alt.runtime_version, true);
                alt_u64("execSegBase", alt.exec_segment_base);
                alt_u64("execSegLimit", alt.exec_segment_limit);
                alt_u64("execSegFlags", alt.exec_segment_flags);
                const auto p = cfg_string(entry, "platform");
                if (!p.empty()) {
                    const auto platform_value = parse_platform(p);
                    if (platform_value == ldid::Platform::UNKNOWN && p != "0") loaded.errors.push_back("alternateCodeDirectories[" + std::to_string(i) + "].platform is invalid");
                    else alt.platform = static_cast<uint8_t>(platform_value);
                }
                auto alt_flags = [&](const char* key, uint32_t& target) {
                    const auto value = cfg_string(entry, key); if (value.empty()) return;
                    try { auto number = parse_cfg_uint(value, key); if (number > UINT32_MAX) throw std::out_of_range(key); target = static_cast<uint32_t>(number); }
                    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                };
                alt_flags("flagsSet", alt.flags_set); alt_flags("flagsClear", alt.flags_clear);
                alt.identifier = cfg_string(entry, "identifier"); alt.team_id = cfg_string(entry, "teamID");
                if ((alt.flags_set & alt.flags_clear) != 0) loaded.errors.push_back("alternateCodeDirectories[" + std::to_string(i) + "] sets and clears the same flags");
                try {
                    const auto scatter = cfg_string(entry, "scatterHex"); if (!scatter.empty()) alt.scatter_data = parse_cfg_hex(scatter, "alternate.scatterHex");
                    const auto pre = cfg_string(entry, "preEncryptHashesHex"); if (!pre.empty()) alt.pre_encrypt_hashes = parse_cfg_hex(pre, "alternate.preEncryptHashesHex");
                    if (!alt.scatter_data.empty() && alt.scatter_data.size() % 24 != 0) loaded.errors.push_back("alternate scatterHex must be a multiple of 24 bytes");
                } catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                plist_t alt_link = plist_child(entry, "linkage");
                auto alt_link_u8 = [&](const char* key, std::optional<uint8_t>& target) {
                    const auto value = cfg_string(alt_link, key); if (value.empty()) return;
                    try { auto number = parse_cfg_uint(value, key); if (number > UINT8_MAX) throw std::out_of_range(key); target = static_cast<uint8_t>(number); }
                    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                };
                alt_link_u8("hashType", alt.linkage_hash_type); alt_link_u8("applicationType", alt.linkage_application_type);
                const auto subtype = cfg_string(alt_link, "applicationSubType");
                if (!subtype.empty()) { try { auto number = parse_cfg_uint(subtype, "alternate.linkage.applicationSubType"); if (number > UINT16_MAX) throw std::out_of_range("applicationSubType"); alt.linkage_application_subtype = static_cast<uint16_t>(number); } catch (const std::exception& e) { loaded.errors.push_back(e.what()); } }
                try { const auto data = cfg_string(alt_link, "dataHex"); if (!data.empty()) alt.linkage_data = parse_cfg_hex(data, "alternate.linkage.dataHex"); }
                catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
                loaded.options.custom_signature.alternate_code_directories.push_back(std::move(alt));
            }
        }
    }

    plist_t requirements = plist_child(root, "requirements");
    loaded.options.custom_signature.requirements_expression = cfg_string(requirements, "designatedExpression");
    try { const auto hex = cfg_string(requirements, "overallBlobHex"); if (!hex.empty()) loaded.options.custom_signature.requirements_blob = parse_cfg_hex(hex, "requirements.overallBlobHex"); }
    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    plist_t entitlements = plist_child(root, "entitlements");
    loaded.options.custom_signature.entitlements_xml = cfg_string(entitlements, "xml");

    plist_t special = plist_child(root, "specialSlots");
    const std::array<std::pair<const char*, uint32_t>, 11> special_fields{{
        {"infoPlistHex",1}, {"requirementsBlobHex",2}, {"codeResourcesHex",3},
        {"applicationDataHex",4}, {"entitlementsBlobHex",5}, {"repSpecificHex",6},
        {"derEntitlementsBlobHex",7}, {"launchConstraintSelfBlobHex",8},
        {"launchConstraintParentBlobHex",9}, {"launchConstraintResponsibleBlobHex",10},
        {"libraryConstraintBlobHex",11}
    }};
    for (const auto& field : special_fields) {
        const auto value = cfg_string(special, field.first);
        if (value.empty()) continue;
        try { loaded.options.custom_signature.special_slot_data[field.second] = parse_cfg_hex(value, std::string("specialSlots.") + field.first); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    }
    plist_t cms = plist_child(root, "cms");
    try { const auto raw = cfg_string(cms, "rawDERHex"); if (!raw.empty()) loaded.options.custom_signature.raw_cms_der = parse_cfg_hex(raw, "cms.rawDERHex"); }
    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    loaded.options.emit_signing_time = cfg_bool(cms, "emitSigningTime", true);
    loaded.options.timestamp_enabled = cfg_bool(cms, "timestampEnabled", false);
    loaded.options.timestamp_required = cfg_bool(cms, "timestampRequired", false);
    loaded.options.timestamp_url = cfg_string(cms, "timestampURL");
    loaded.options.timestamp_policy = cfg_string(cms, "timestampPolicy");
    loaded.options.timestamp_ca_file = cfg_string(cms, "timestampCAFile");
    loaded.options.timestamp_ca_path = cfg_string(cms, "timestampCAPath");
    loaded.options.timestamp_require_root = cfg_bool(cms, "timestampRequireRoot", false);
    if ((loaded.options.timestamp_required || loaded.options.timestamp_require_root) && !loaded.options.timestamp_enabled)
        loaded.errors.push_back("cms.timestampRequired/timestampRequireRoot cannot be true when timestampEnabled is false");
    if ((!loaded.options.timestamp_ca_file.empty() || !loaded.options.timestamp_ca_path.empty()) && !loaded.options.timestamp_enabled)
        loaded.errors.push_back("cms.timestampCAFile/timestampCAPath requires timestampEnabled=true");
    if (loaded.options.timestamp_enabled && loaded.options.timestamp_url.empty())
        loaded.errors.push_back("cms.timestampURL is required when timestampEnabled is true");
    plist_t custom_blobs = plist_child(root, "customBlobs");
    if (custom_blobs) {
        if (plist_get_node_type(custom_blobs) != PLIST_ARRAY) loaded.errors.push_back("customBlobs must be an array");
        else {
            const uint32_t n = plist_array_get_size(custom_blobs);
            if (n > 4096) loaded.errors.push_back("customBlobs exceeds the maximum of 4096 entries");
            for (uint32_t i = 0; i < n && i < 4096; ++i) {
                plist_t entry = plist_array_get_item(custom_blobs, i);
                try {
                    auto slot_text = cfg_string(entry, "slot");
                    auto blob_hex = cfg_string(entry, "blobHex");
                    const uint64_t slot = parse_cfg_uint(slot_text, "customBlobs.slot");
                    if (slot > UINT32_MAX) throw std::out_of_range("customBlobs.slot exceeds uint32");
                    loaded.options.custom_signature.embedded_blobs[static_cast<uint32_t>(slot)] = parse_cfg_hex(blob_hex, "customBlobs.blobHex");
                } catch (const std::exception& e) { loaded.errors.push_back(std::string("customBlobs[") + std::to_string(i) + "]: " + e.what()); }
            }
        }
    }
    plist_t raw = plist_child(root, "raw");
    try { const auto full = cfg_string(raw, "embeddedSuperBlobHex"); if (!full.empty()) loaded.options.custom_signature.raw_superblob = parse_cfg_hex(full, "raw.embeddedSuperBlobHex"); }
    catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    plist_t validation = plist_child(root, "validation");
    loaded.verification.certificate_chain.enabled = cfg_bool(validation, "checkCertificateChain", false);
    loaded.verification.certificate_chain.require_root = cfg_bool(validation, "requireChainToRoot", false);
    loaded.verification.certificate_chain.ca_file = cfg_string(validation, "caFile");
    loaded.verification.certificate_chain.ca_path = cfg_string(validation, "caPath");
    const auto verify_time = cfg_string(validation, "verificationTime");
    if (!verify_time.empty()) {
        try { loaded.verification.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(verify_time, "validation.verificationTime")); }
        catch (const std::exception& e) { loaded.errors.push_back(e.what()); }
    }
    if (loaded.verification.certificate_chain.require_root)
        loaded.verification.certificate_chain.enabled = true;
    if (!loaded.verification.certificate_chain.enabled &&
        (!loaded.verification.certificate_chain.ca_file.empty() || !loaded.verification.certificate_chain.ca_path.empty()))
        loaded.warnings.push_back("CA sources are configured but certificate-chain checking is disabled");
    if (loaded.options.apple_internal_profile.enabled) {
        if (!loaded.verification.certificate_chain.enabled)
            loaded.errors.push_back("Apple Internal policy requires validation.checkCertificateChain=true");
        if (!loaded.verification.certificate_chain.require_root)
            loaded.errors.push_back("Apple Internal policy requires validation.requireChainToRoot=true");
    }
    const std::array<const char*, 7> mandatory_checks{{
        "checkStructure", "checkPageHashes", "checkSpecialSlots", "checkCMSMath",
        "checkEntitlementsDER", "checkResources", "checkAllArchitectures"
    }};
    for (const char* key : mandatory_checks) {
        if (!cfg_bool(validation, key, true))
            loaded.errors.push_back(std::string("validation.") + key + " cannot be disabled; signature-apply always runs the complete local validation pass");
    }

    if (loaded.options.custom_signature.flags_set & loaded.options.custom_signature.flags_clear)
        loaded.errors.push_back("the same CodeDirectory flag cannot be both set and cleared");
    if (loaded.options.custom_signature.code_directory_version &&
        (*loaded.options.custom_signature.code_directory_version < 0x20001 || *loaded.options.custom_signature.code_directory_version > 0x20600))
        loaded.errors.push_back("CodeDirectory generation version must be between 0x20001 and 0x20600; use raw SuperBlob import for newer variants");
    if (!loaded.options.custom_signature.scatter_data.empty() && loaded.options.custom_signature.scatter_data.size() % 24 != 0)
        loaded.errors.push_back("scatterHex must be a sequence of 24-byte SC_Scatter records including a zero-count sentinel");
    if (loaded.options.custom_signature.linkage_data.empty() &&
        (loaded.options.custom_signature.linkage_hash_type || loaded.options.custom_signature.linkage_application_type || loaded.options.custom_signature.linkage_application_subtype))
        loaded.warnings.push_back("CodeDirectory linkage fields are specified without linkage data; the output may contain only an empty linkage extension");
    for (const auto& [slot, bytes] : loaded.options.custom_signature.special_slot_data) {
        if (slot == 2 || slot == 4 || slot == 5 || slot == 6 || slot == 7 || (slot >= 8 && slot <= 11)) {
            const uint32_t magic = bytes.size() >= 4 ? (static_cast<uint32_t>(bytes[0]) << 24 | static_cast<uint32_t>(bytes[1]) << 16 | static_cast<uint32_t>(bytes[2]) << 8 | bytes[3]) : 0;
            const uint32_t declared = bytes.size() >= 8 ? (static_cast<uint32_t>(bytes[4]) << 24 | static_cast<uint32_t>(bytes[5]) << 16 | static_cast<uint32_t>(bytes[6]) << 8 | bytes[7]) : 0;
            const uint32_t expected = slot == 2 ? 0xfade0c01U : (slot == 5 ? 0xfade7171U : (slot == 7 ? 0xfade7172U : ((slot >= 8 && slot <= 11) ? 0xfade8181U : 0U)));
            if (bytes.size() < 8 || declared != bytes.size() || (expected != 0 && magic != expected))
                loaded.errors.push_back("special slot " + std::to_string(slot) + " requires a complete Blob with the correct magic and exact length");
        }
    }
    for (const auto& [slot, raw_blob] : loaded.options.custom_signature.embedded_blobs) {
        if (slot == 0 || slot == 2 || slot == 5 || slot == 7 || slot == 0x10000 || (slot >= 0x1000 && slot < 0x1005))
            loaded.errors.push_back("custom blob slot collides with a generated slot: " + std::to_string(slot));
        if (raw_blob.size() < 8) loaded.errors.push_back("custom blob " + std::to_string(slot) + " is shorter than a Blob header");
        else {
            const uint32_t declared = (static_cast<uint32_t>(raw_blob[4]) << 24) | (static_cast<uint32_t>(raw_blob[5]) << 16) | (static_cast<uint32_t>(raw_blob[6]) << 8) | raw_blob[7];
            if (declared != raw_blob.size()) loaded.errors.push_back("custom blob " + std::to_string(slot) + " has an invalid length field");
        }
    }
    if (!loaded.options.custom_signature.raw_cms_der.empty()) {
        const auto& der = loaded.options.custom_signature.raw_cms_der;
        const unsigned char* cursor = der.data();
        std::unique_ptr<PKCS7, decltype(&PKCS7_free)> p7(d2i_PKCS7(nullptr, &cursor, static_cast<long>(der.size())), PKCS7_free);
        if (!p7 || cursor != der.data() + der.size()) loaded.errors.push_back("cms.rawDERHex is not one complete DER PKCS#7 ContentInfo");
    }
    if (!loaded.options.custom_signature.raw_superblob.empty()) {
        const auto parsed = ldid::verifier::parse_superblob(loaded.options.custom_signature.raw_superblob);
        if (!parsed.valid || (parsed.magic != 0xfade0cc0U && parsed.magic != 0xfade0b02U))
            loaded.errors.push_back("raw.embeddedSuperBlobHex is not a structurally valid embedded SuperBlob");
        else if (parsed.slots.find(0U) == parsed.slots.end() || !ldid::verifier::parse_code_directory(parsed.slots.at(0U)))
            loaded.errors.push_back("raw.embeddedSuperBlobHex must contain a supported primary CodeDirectory in slot 0");
    }
    return loaded;
}

std::string hash_type_name(uint8_t type) {
    switch (type) { case 1: return "SHA-1"; case 2: return "SHA-256"; case 3: return "SHA-256-truncated"; case 4: return "SHA-384"; default: return "unknown(" + std::to_string(type) + ")"; }
}

std::string code_directory_version_name(uint32_t version) {
    std::ostringstream os; os << "0x" << std::hex << std::uppercase << version;
    switch (version) {
        case 0x20001: return os.str() + " (v2.0.1)";
        case 0x20100: return os.str() + " (v2.1)";
        case 0x20200: return os.str() + " (v2.2)";
        case 0x20300: return os.str() + " (v2.3)";
        case 0x20400: return os.str() + " (v2.4)";
        case 0x20500: return os.str() + " (v2.5)";
        case 0x20600: return os.str() + " (v2.6)";
        default: return os.str() + " (unmapped version)";
    }
}

std::string superblob_slot_name(uint32_t slot) {
    switch (slot) {
        case 0: return "CodeDirectory"; case 1: return "Info.plist hash"; case 2: return "Requirements";
        case 3: return "CodeResources hash"; case 4: return "Application-specific"; case 5: return "XML Entitlements";
        case 6: return "Representation-specific"; case 7: return "DER Entitlements";
        case 8: return "Launch Constraint: Self"; case 9: return "Launch Constraint: Parent";
        case 10: return "Launch Constraint: Responsible"; case 11: return "Library Constraint";
        case 0x10000: return "CMS Signature"; case 0x10001: return "Identification"; case 0x10002: return "Ticket";
        default:
            if (slot >= 0x1000 && slot < 0x1005) return "Alternate CodeDirectory " + std::to_string(slot - 0x1000);
            return "Unknown/custom";
    }
}

std::string cert_common_name(X509* certificate) {
    if (!certificate) return {};
    char value[1024] = {0};
    const int length = X509_NAME_get_text_by_NID(X509_get_subject_name(certificate), NID_commonName, value, sizeof(value));
    return length > 0 ? std::string(value, static_cast<size_t>(length)) : std::string();
}

struct CmsSignerEvidence {
    std::string common_name;
    std::string subject;
    std::string sha256_fingerprint;
    std::string digest_algorithm;
    std::string signature_algorithm;
    std::string not_before;
    std::string not_after;
    bool certificate_valid_now = false;
    bool certificate_expired = false;
    bool certificate_not_yet_valid = false;
    std::vector<std::string> signed_attribute_oids;
    std::vector<std::string> unsigned_attribute_oids;
    bool has_signing_time = false;
    bool has_timestamp_token = false;
    bool has_apple_cdhash_attribute = false;
    bool apple_app_signing = false;
    bool development = false;
    bool distribution = false;
};

std::string asn1_algorithm_name(const X509_ALGOR* algorithm) {
    if (!algorithm) return {};
    const ASN1_OBJECT* object = nullptr;
    X509_ALGOR_get0(&object, nullptr, nullptr, algorithm);
    if (!object) return {};
    char name[256] = {0};
    const int n = OBJ_obj2txt(name, sizeof(name), object, 1);
    return n > 0 ? std::string(name, static_cast<size_t>(std::min<int>(n, sizeof(name) - 1))) : std::string();
}

std::vector<std::string> attribute_oids(STACK_OF(X509_ATTRIBUTE)* attributes,
                                        bool* signing_time, bool* timestamp_token,
                                        bool* apple_cdhash) {
    std::vector<std::string> result;
    const int count = attributes ? sk_X509_ATTRIBUTE_num(attributes) : 0;
    for (int i = 0; i < count; ++i) {
        X509_ATTRIBUTE* attribute = sk_X509_ATTRIBUTE_value(attributes, i);
        const ASN1_OBJECT* object = attribute ? X509_ATTRIBUTE_get0_object(attribute) : nullptr;
        if (!object) continue;
        char oid[128] = {0};
        const int n = OBJ_obj2txt(oid, sizeof(oid), object, 1);
        if (n <= 0) continue;
        std::string value(oid, static_cast<size_t>(std::min<int>(n, sizeof(oid) - 1)));
        result.push_back(value);
        if (signing_time && value == "1.2.840.113549.1.9.5") *signing_time = true;
        if (timestamp_token && value == "1.2.840.113549.1.9.16.2.14") *timestamp_token = true;
        if (apple_cdhash && (value == "1.2.840.113635.100.9.1" || value == "1.2.840.113635.100.9.2")) *apple_cdhash = true;
    }
    return result;
}

std::string asn1_time_string(const ASN1_TIME* value) {
    if (!value) return {};
    BIO* bio = BIO_new(BIO_s_mem());
    if (!bio) return {};
    std::string result;
    if (ASN1_TIME_print(bio, value) == 1) {
        char* data = nullptr;
        const long length = BIO_get_mem_data(bio, &data);
        if (data && length > 0) result.assign(data, static_cast<size_t>(length));
    }
    BIO_free(bio);
    return result;
}

std::vector<CmsSignerEvidence> inspect_cms_signers(const std::vector<uint8_t>& der, bool* math_valid = nullptr, const std::vector<uint8_t>* detached_content = nullptr) {
    std::vector<CmsSignerEvidence> out;
    if (math_valid) *math_valid = false;
    if (der.empty() || der.size() > static_cast<size_t>(LONG_MAX)) return out;
    const unsigned char* cursor = der.data();
    std::unique_ptr<PKCS7, decltype(&PKCS7_free)> p7(d2i_PKCS7(nullptr, &cursor, static_cast<long>(der.size())), PKCS7_free);
    if (!p7 || cursor != der.data() + der.size()) return out;
    if (math_valid) {
        BIO* raw = BIO_new(BIO_s_mem());
        BIO* input = detached_content ? BIO_new_mem_buf(detached_content->data(), static_cast<int>(detached_content->size())) : nullptr;
        if (raw && (!detached_content || input)) {
            const int rc = PKCS7_verify(p7.get(), nullptr, nullptr, input, raw, PKCS7_NOVERIFY | PKCS7_NOCHAIN | PKCS7_BINARY);
            *math_valid = rc == 1;
        }
        if (input) BIO_free(input);
        if (raw) BIO_free(raw);
    }
    STACK_OF(PKCS7_SIGNER_INFO)* infos = PKCS7_get_signer_info(p7.get());
    const int count = infos ? sk_PKCS7_SIGNER_INFO_num(infos) : 0;
    for (int i = 0; i < count; ++i) {
        PKCS7_SIGNER_INFO* info = sk_PKCS7_SIGNER_INFO_value(infos, i);
        X509* cert = info ? PKCS7_cert_from_signer_info(p7.get(), info) : nullptr;
        if (!cert) continue;
        CmsSignerEvidence evidence;
        evidence.common_name = cert_common_name(cert);
        evidence.subject = ldid::x509_name_string(X509_get_subject_name(cert));
        evidence.digest_algorithm = asn1_algorithm_name(info ? info->digest_alg : nullptr);
        evidence.signature_algorithm = asn1_algorithm_name(info ? info->digest_enc_alg : nullptr);
        evidence.not_before = asn1_time_string(X509_get0_notBefore(cert));
        evidence.not_after = asn1_time_string(X509_get0_notAfter(cert));
        const int not_before_cmp = X509_cmp_current_time(X509_get0_notBefore(cert));
        const int not_after_cmp = X509_cmp_current_time(X509_get0_notAfter(cert));
        evidence.certificate_not_yet_valid = not_before_cmp > 0;
        evidence.certificate_expired = not_after_cmp < 0;
        evidence.certificate_valid_now = not_before_cmp <= 0 && not_after_cmp >= 0;
        evidence.signed_attribute_oids = attribute_oids(info ? info->auth_attr : nullptr,
            &evidence.has_signing_time, nullptr, &evidence.has_apple_cdhash_attribute);
        evidence.unsigned_attribute_oids = attribute_oids(info ? info->unauth_attr : nullptr,
            nullptr, &evidence.has_timestamp_token, &evidence.has_apple_cdhash_attribute);
        unsigned char fingerprint[EVP_MAX_MD_SIZE] = {0}; unsigned int fingerprint_length = 0;
        if (X509_digest(cert, EVP_sha256(), fingerprint, &fingerprint_length) == 1)
            evidence.sha256_fingerprint = ldid::to_hex(std::vector<uint8_t>(fingerprint, fingerprint + fingerprint_length));
        const std::string& cn = evidence.common_name;
        evidence.apple_app_signing = cn.find("Apple iPhone OS Application Signing") != std::string::npos;
        evidence.development = cn.find("Apple Development") != std::string::npos || cn.find("iPhone Developer") != std::string::npos || cn.find("iOS Development") != std::string::npos;
        evidence.distribution = cn.find("Apple Distribution") != std::string::npos || cn.find("iPhone Distribution") != std::string::npos || cn.find("iOS Distribution") != std::string::npos;
        out.push_back(std::move(evidence));
    }
    return out;
}

struct ProvisionProfileEvidence {
    bool present = false;
    bool cms_der_valid = false;
    bool cms_math_valid = false;
    bool cms_chain_checked = false;
    bool cms_chain_valid = false;
    std::string cms_chain_error;
    bool provisions_all_devices = false;
    bool apple_internal_profile = false;
    bool get_task_allow = false;
    bool beta_reports_active = false;
    size_t provisioned_device_count = 0;
    size_t developer_certificate_count = 0;
    std::string name;
    std::string uuid;
    std::string team_id;
    std::string application_identifier_prefix;
    std::string application_identifier;
    std::string expiration;
    bool expired = false;
    bool certificate_match = false;
    bool der_encoded_profile_present = false;
    uint64_t der_encoded_profile_length = 0;
    std::set<std::string> developer_certificate_fingerprints;
    std::set<std::string> entitlement_keys;
    std::string error;
};

std::string profile_array_first_string(plist_t array) {
    if (!array || plist_get_node_type(array) != PLIST_ARRAY || plist_array_get_size(array) == 0) return {};
    return plist_scalar_string(plist_array_get_item(array, 0));
}

ProvisionProfileEvidence inspect_provisioning_profile(const std::filesystem::path& path, X509* signer_certificate = nullptr,
                                                        const ldid::CertificateChainOptions& chain_options = {}) {
    ProvisionProfileEvidence result;
    if (!std::filesystem::is_regular_file(path)) return result;
    result.present = true;
    const auto bytes = ldid::read_file(path);
    if (bytes.empty() || bytes.size() > static_cast<size_t>(LONG_MAX)) { result.error = "profile file is empty or too large"; return result; }
    const unsigned char* cursor = bytes.data();
    std::unique_ptr<PKCS7, decltype(&PKCS7_free)> p7(d2i_PKCS7(nullptr, &cursor, static_cast<long>(bytes.size())), PKCS7_free);
    if (!p7 || cursor != bytes.data() + bytes.size()) { result.error = "embedded.mobileprovision is not valid DER PKCS#7"; return result; }
    result.cms_der_valid = true;
    std::vector<uint8_t> plist_bytes;
    std::string profile_cms_error;
    result.cms_chain_checked = chain_options.enabled;
    result.cms_math_valid = ldid::crypto::verify_pkcs7_attached_impl(p7.get(), ldid::CertificateChainOptions{}, &plist_bytes, &profile_cms_error);
    if (!result.cms_math_valid) {
        result.error = "profile CMS signature math validation failed: " + profile_cms_error;
        return result;
    }
    if (chain_options.enabled) {
        result.cms_chain_valid = ldid::crypto::verify_pkcs7_attached_impl(p7.get(), chain_options, nullptr, &result.cms_chain_error);
        if (!result.cms_chain_valid && result.cms_chain_error.empty()) result.cms_chain_error = "certificate chain validation failed";
    }
    plist_t root = ldid::plist_from_xml_bytes(plist_bytes);
    if (!root || plist_get_node_type(root) != PLIST_DICT) { if (root) plist_free(root); result.error = "profile CMS content is not a plist dictionary"; return result; }
    struct PlistGuard { plist_t p; ~PlistGuard() { if (p) plist_free(p); } } guard{root};
    result.name = plist_scalar_string(plist_child(root, "Name"));
    result.uuid = plist_scalar_string(plist_child(root, "UUID"));
    result.provisions_all_devices = cfg_bool(root, "ProvisionsAllDevices", false);
    result.apple_internal_profile = cfg_bool(root, "AppleInternalProfile", false);
    plist_t devices = plist_child(root, "ProvisionedDevices");
    if (devices && plist_get_node_type(devices) == PLIST_ARRAY) result.provisioned_device_count = plist_array_get_size(devices);
    plist_t teams = plist_child(root, "TeamIdentifier");
    result.team_id = profile_array_first_string(teams);
    plist_t app_id_prefixes = plist_child(root, "ApplicationIdentifierPrefix");
    result.application_identifier_prefix = profile_array_first_string(app_id_prefixes);
    plist_t der_profile = plist_child(root, "DER-Encoded-Profile");
    if (der_profile && plist_get_node_type(der_profile) == PLIST_DATA) {
        char* der_bytes = nullptr; uint64_t der_length = 0;
        plist_get_data_val(der_profile, &der_bytes, &der_length);
        result.der_encoded_profile_present = der_bytes != nullptr && der_length != 0;
        result.der_encoded_profile_length = der_length;
        if (der_bytes) free(der_bytes);
    }
    plist_t entitlements = plist_child(root, "Entitlements");
    result.get_task_allow = cfg_bool(entitlements, "get-task-allow", false);
    result.beta_reports_active = cfg_bool(entitlements, "beta-reports-active", false);
    result.application_identifier = cfg_string(entitlements, "application-identifier");
    if (entitlements && plist_get_node_type(entitlements) == PLIST_DICT) {
        plist_dict_iter entitlement_iter = nullptr;
        plist_dict_new_iter(entitlements, &entitlement_iter);
        if (entitlement_iter) {
            for (;;) {
                char* key = nullptr; plist_t value = nullptr;
                plist_dict_next_item(entitlements, entitlement_iter, &key, &value);
                if (!key || !value) { free(key); break; }
                result.entitlement_keys.insert(key);
                free(key);
            }
            free(entitlement_iter);
        }
    }
    int64_t expiry = 0;
    plist_t expiration = plist_child(root, "ExpirationDate");
    if (expiration && plist_get_node_type(expiration) == PLIST_DATE) {
        plist_get_unix_date_val(expiration, &expiry);
        std::time_t t = static_cast<std::time_t>(expiry);
        char buf[64] = {0}; std::tm tm{};
#if defined(_WIN32)
        gmtime_s(&tm, &t);
#else
        gmtime_r(&t, &tm);
#endif
        std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
        result.expiration = buf;
        result.expired = expiry <= static_cast<int64_t>(std::time(nullptr));
    }
    plist_t devcerts = plist_child(root, "DeveloperCertificates");
    if (devcerts && plist_get_node_type(devcerts) == PLIST_ARRAY) {
        result.developer_certificate_count = plist_array_get_size(devcerts);
        for (uint32_t i = 0; i < plist_array_get_size(devcerts); ++i) {
            plist_t item = plist_array_get_item(devcerts, i);
            char* cert_bytes = nullptr; uint64_t cert_len = 0;
            if (!item || plist_get_node_type(item) != PLIST_DATA) continue;
            plist_get_data_val(item, &cert_bytes, &cert_len);
            if (cert_bytes && cert_len > 0 && cert_len <= static_cast<uint64_t>(LONG_MAX)) {
                const unsigned char* c = reinterpret_cast<const unsigned char*>(cert_bytes);
                std::unique_ptr<X509, decltype(&X509_free)> cert(d2i_X509(nullptr, &c, static_cast<long>(cert_len)), X509_free);
                unsigned char fp[EVP_MAX_MD_SIZE] = {0}; unsigned int fp_len = 0;
                if (cert && X509_digest(cert.get(), EVP_sha256(), fp, &fp_len) == 1)
                    result.developer_certificate_fingerprints.insert(ldid::to_hex(std::vector<uint8_t>(fp, fp + fp_len)));
            }
            if (cert_bytes) free(cert_bytes);
        }
        if (signer_certificate) {
            unsigned char signer_fp[EVP_MAX_MD_SIZE] = {0}; unsigned int signer_fp_len = 0;
            if (X509_digest(signer_certificate, EVP_sha256(), signer_fp, &signer_fp_len) == 1)
                result.certificate_match = result.developer_certificate_fingerprints.count(ldid::to_hex(std::vector<uint8_t>(signer_fp, signer_fp + signer_fp_len))) != 0;
        }
    }
    return result;
}

bool profile_identifier_matches(const std::string& pattern, const std::string& value) {
    if (pattern.empty() || value.empty()) return false;
    // Apple application-identifier wildcards are most commonly a trailing '*'.
    const size_t star = pattern.find('*');
    if (star == std::string::npos) return pattern == value;
    if (pattern.find('*', star + 1) != std::string::npos) return false;
    return value.size() >= star && value.compare(0, star, pattern, 0, star) == 0;
}

std::string bundle_identifier_from_info_plist(const std::filesystem::path& bundle) {
    const auto bytes = ldid::read_file(bundle / "Info.plist");
    if (bytes.empty()) return {};
    plist_t root = ldid::plist_from_xml_bytes(bytes);
    if (!root) return {};
    const auto value = plist_scalar_string(plist_child(root, "CFBundleIdentifier"));
    plist_free(root);
    return value;
}

bool is_signature_bundle_path(const std::filesystem::path& path) {
    const auto ext = path.extension().string();
    return ext == ".app" || ext == ".appex" || ext == ".framework" || ext == ".xpc" || ext == ".bundle";
}

std::filesystem::path locate_signature_bundle(const std::filesystem::path& input) {
    std::error_code ec;
    if (std::filesystem::is_directory(input, ec) && is_signature_bundle_path(input)) return input;
    auto cursor = input.parent_path();
    for (size_t depth = 0; depth < 32 && !cursor.empty(); ++depth) {
        if (is_signature_bundle_path(cursor) && std::filesystem::is_directory(cursor, ec)) return cursor;
        const auto parent = cursor.parent_path();
        if (parent == cursor) break;
        cursor = parent;
    }
    return {};
}

std::filesystem::path locate_app_bundle(const std::filesystem::path& input) {
    std::error_code ec;
    if (std::filesystem::is_directory(input, ec) && input.extension() == ".app") return input;
    auto cursor = input.parent_path();
    for (size_t depth = 0; depth < 32 && !cursor.empty(); ++depth) {
        if (cursor.extension() == ".app" && std::filesystem::is_directory(cursor, ec)) return cursor;
        const auto parent = cursor.parent_path();
        if (parent == cursor) break;
        cursor = parent;
    }
    return {};
}

struct SignatureClassification {
    std::string label = "UNKNOWN / INDETERMINATE";
    std::vector<std::string> evidence;
    std::vector<std::string> limitations;
};

SignatureClassification classify_ios_signature(const ProvisionProfileEvidence& profile,
                                                const std::vector<CmsSignerEvidence>& signers,
                                                bool adhoc, const std::filesystem::path& path) {
    SignatureClassification c;
    const CmsSignerEvidence* primary = signers.empty() ? nullptr : &signers.front();
    if (profile.present && profile.cms_math_valid) {
        if (profile.expired) c.evidence.push_back("embedded profile is expired");
        else if (profile.cms_chain_checked && profile.cms_chain_valid)
            c.evidence.push_back("embedded.mobileprovision CMS math and certificate path validated against configured trust anchors");
        else if (profile.cms_chain_checked)
            c.evidence.push_back("embedded.mobileprovision CMS mathematical signature is valid; certificate-chain validation failed");
        else c.evidence.push_back("embedded.mobileprovision CMS mathematical signature is valid; certificate chain was not checked");
        if (profile.apple_internal_profile) {
            c.label = "PROFILE CLAIM: APPLE INTERNAL (TRUST NOT ESTABLISHED)";
            c.evidence.push_back("AppleInternalProfile = true");
            if (profile.provisions_all_devices) c.evidence.push_back("ProvisionsAllDevices = true");
        } else if (profile.provisions_all_devices) {
            c.label = "PROFILE CLAIM: ENTERPRISE / IN-HOUSE (TRUST NOT ESTABLISHED)";
            c.evidence.push_back("ProvisionsAllDevices = true");
        } else if (profile.provisioned_device_count != 0 && profile.get_task_allow) {
            c.label = "PROFILE CLAIM: DEVELOPMENT / DEVICE-REGISTERED (TRUST NOT ESTABLISHED)";
            c.evidence.push_back("ProvisionedDevices present and Entitlements.get-task-allow = true");
        } else if (profile.provisioned_device_count != 0 && !profile.get_task_allow) {
            c.label = "PROFILE CLAIM: AD HOC / DEVICE-REGISTERED DISTRIBUTION (TRUST NOT ESTABLISHED)";
            c.evidence.push_back("ProvisionedDevices present and get-task-allow = false");
        } else {
            c.label = profile.beta_reports_active
                ? "PROFILE CLAIM: APP STORE CONNECT / TESTFLIGHT-LIKE (TRUST NOT ESTABLISHED)"
                : "PROFILE CLAIM: APP STORE CONNECT DISTRIBUTION (NOT PROOF OF APP STORE DELIVERY)";
            c.evidence.push_back("no ProvisionedDevices and ProvisionsAllDevices is not true");
            if (profile.beta_reports_active) c.evidence.push_back("beta-reports-active = true (supporting TestFlight evidence only)");
        }
        if (!profile.cms_chain_checked)
            c.limitations.push_back("certificate-chain trust was not checked; classification is a profile claim, not an authenticated Apple distribution verdict");
        else if (!profile.cms_chain_valid)
            c.limitations.push_back("certificate-chain validation failed; profile classification is untrusted");
        else
            c.limitations.push_back("chain is valid under the configured trust store; this alone does not prove that the trust store is Apple's or establish App Store delivery");
        const bool matched_profile_cert = primary && !primary->sha256_fingerprint.empty() &&
            profile.developer_certificate_fingerprints.count(primary->sha256_fingerprint) != 0;
        if (matched_profile_cert) c.evidence.push_back("CMS leaf certificate matches one DeveloperCertificates entry in the provisioning profile");
        else if (primary) {
            c.limitations.push_back("CMS signer certificate did not match DeveloperCertificates (or signer data was unavailable)");
            c.label += " — SIGNER/PROFILE MISMATCH OR UNKNOWN";
        }
        if (profile.team_id.empty()) c.limitations.push_back("profile TeamIdentifier missing");
        if (profile.application_identifier.empty()) c.limitations.push_back("profile application-identifier missing");
        if (profile.expired) c.limitations.push_back("expired provisioning profile is not valid for current installation");
        return c;
    }
    if (profile.present) c.limitations.push_back(profile.error.empty() ? "embedded profile could not be authenticated" : profile.error);
    if (primary && primary->apple_app_signing) {
        c.label = "APPLE-MANAGED APP SIGNING CANDIDATE (APP STORE / TESTFLIGHT NOT DISTINGUISHED)";
        c.evidence.push_back("CMS leaf common name matches Apple iPhone OS Application Signing");
        c.limitations.push_back("without a verified Apple trust chain or App Store receipt, App Store vs TestFlight vs other Apple-managed distribution cannot be proven solely from this Mach-O");
    } else if (primary && primary->development) {
        c.label = "DEVELOPMENT-CERTIFICATE-LIKE SIGNATURE (TRUST NOT ESTABLISHED)";
        c.evidence.push_back("CMS leaf common name resembles Apple Development / iPhone Developer");
        c.limitations.push_back("no valid provisioning profile available to determine registered-device policy");
    } else if (primary && primary->distribution) {
        c.label = "APPLE-DISTRIBUTION-CERTIFICATE-LIKE SIGNATURE (PROFILE CLASS UNKNOWN)";
        c.evidence.push_back("CMS leaf common name resembles Apple Distribution / iOS Distribution");
        c.limitations.push_back("Apple Distribution certificates can be used for App Store Connect and Ad Hoc; In-House requires profile evidence");
    } else if (primary && primary->common_name.find("Developer ID Application") != std::string::npos) {
        c.label = "DEVELOPER ID APPLICATION (macOS; NOT AN iOS DISTRIBUTION CLASS)";
        c.evidence.push_back("CMS leaf common name resembles Developer ID Application");
    } else if (primary && primary->common_name.find("3rd Party Mac Developer Application") != std::string::npos) {
        c.label = "MAC APP STORE DISTRIBUTION (NOT AN iOS DISTRIBUTION CLASS)";
        c.evidence.push_back("CMS leaf common name resembles 3rd Party Mac Developer Application");
    } else if (adhoc) {
        c.label = "AD-HOC SIGNED (NO CMS SIGNER)";
        c.evidence.push_back("CodeDirectory CS_ADHOC flag set and no CMS signature is present");
    } else {
        c.label = "SIGNED / DISTRIBUTION CLASS UNDETERMINED";
        if (!primary) c.evidence.push_back("no CMS signer certificate extracted");
    }
    const std::string path_text = path.generic_string();
    if (path_text.rfind("/System/", 0) == 0 || path_text.rfind("/usr/lib/", 0) == 0 || path_text.rfind("/usr/bin/", 0) == 0) {
        c.evidence.push_back("input path is under an Apple system namespace");
        c.limitations.push_back("system origin/path is only a hint; platform-binary trust is a runtime/kernel decision and is not established by the file alone");
        if (primary && !primary->common_name.empty() && primary->common_name.find("Apple") != std::string::npos)
            c.label = "APPLE SYSTEM COMPONENT CANDIDATE (RUNTIME TRUST UNCONFIRMED)";
    }
    return c;
}

void print_signature_catalog() {
    std::cout << "iOS code-signing classification and format catalog\n"
              << "\nA. SIGNING IDENTITY / DISTRIBUTION CLASSIFICATION (evidence-based):\n"
              << "  App Store final delivery: commonly Apple-managed signing; no embedded profile on installed app; App Store receipt / platform trust may be needed to prove delivery channel\n"
              << "  App Store Connect submission: profile with no ProvisionedDevices and no ProvisionsAllDevices; describes upload/signing workflow, not proof of final App Store install\n"
              << "  TestFlight: Apple-managed final signing candidate; beta-reports-active in a profile is supporting evidence only\n"
              << "  Apple Development: Apple Development / iPhone Developer leaf certificate + development profile\n"
              << "  Development profile: ProvisionedDevices plus get-task-allow=true\n"
              << "  Ad Hoc distribution: ProvisionedDevices plus get-task-allow=false; normally Apple Distribution certificate\n"
              << "  Enterprise / In-House: ProvisionsAllDevices=true; profile evidence is decisive for this classification\n"
              << "  Apple Internal profile: AppleInternalProfile=true in an Apple-issued CMS-signed profile; this is not a profile-free signing mode\n"
              << "  Apple system internal: Apple platform signer + runtime/platform trust evidence; path and subject alone are candidates only\n"
              << "  Ad-hoc code signature: CodeDirectory CS_ADHOC and empty/absent CMS; not an Apple distribution identity\n"
              << "  Developer ID / Mac App Store: macOS signing classes, not iOS app distribution classes\n"
              << "  Local signing / TrollStore-like signing: requires environment/install method evidence; do not infer from a generic CMS or Team ID\n"
              << "\nB. CODE SIGNATURE CONTAINERS / VARIANTS:\n"
              << "  SuperBlob: embedded 0xfade0cc0, legacy embedded 0xfade0b02, detached 0xfade0cc1\n"
              << "  CodeDirectory: v2.0.1 base; v2.1 Scatter; v2.2 Team ID; v2.3 codeLimit64; v2.4 executable segment; v2.5 runtime/pre-encrypt; v2.6 linkage (XNU-defined; OS acceptance varies; Apple Security current parser may treat newer compatible versions as unknown)\n"
              << "  Hash type: SHA-1(1), SHA-256(2), SHA-256-truncated(3), SHA-384(4)\n"
              << "  CodeDirectories: primary slot 0 + alternate slots 0x1000..0x1004 (five alternate slots)\n"
              << "  Signature mode: ad-hoc/no CMS; CMS/PKCS#7 SignedData; one or multiple SignerInfo; embedded or detached CMS\n"
              << "  Special slots: Info.plist(-1), Requirements(-2), CodeResources(-3), Application(-4), XML Entitlements(-5), RepSpecific(-6), DER Entitlements(-7), Launch Constraints(-8..-11)\n"
              << "  Entitlements: XML plist, DER plist, and XML/DER consistency\n"
              << "  Requirements: designated/overall Requirements blobs, expression form, raw form, LWCR/DER constraints\n"
              << "  Bundle resources: files/files2, rules/rules2, SHA-1/SHA-256, symlink and nested-code cdhash seals\n"
              << "  Architectures: thin Mach-O, FAT/FAT64; each slice checked independently\n"
              << "\nC. IMPORTANT LIMITS:\n"
              << "  XNU validation categories (runtime-only): INVALID=0, PLATFORM=1, TESTFLIGHT=2, DEVELOPMENT=3, APP_STORE=4, ENTERPRISE=5, DEVELOPER_ID=6, LOCAL_SIGNING=7, ROSETTA=8, OOPJIT=9, NONE=10\n"
              << "  CS_PLATFORM_BINARY and validation category are kernel/runtime state; cannot be granted by setting a CodeDirectory flag\n"
              << "  Provisioning profiles: Development, Ad Hoc, App Store Connect, In-House; CMS math is always checked and certificate chain is optional (disabled by default); labels remain evidence-based\n"
              << "  DER-Encoded-Profile: presence and byte length reported; full DER profile semantic decoding is not implemented in this build\n"
              << "  Unknown/future SuperBlob entries are preserved; unsupported CodeDirectory layouts are reported as unparsed, never silently treated as verified\n";
}

void print_template_validation(const CustomTemplateLoad& loaded) {
    std::cout << "Template schema: ldid.custom-signature v1\n";
    std::cout << "Classification hint: " << loaded.classification_hint << " (descriptive only)\n";
    if (loaded.options.apple_internal_profile.enabled) {
        std::cout << "Apple Internal profile policy: ENABLED (requires AppleInternalProfile=true in an authentic CMS-signed embedded.mobileprovision)\n";
        std::cout << "  Profile source: " << (loaded.options.apple_internal_profile.source_path.empty() ? "already embedded in bundle" : loaded.options.apple_internal_profile.source_path) << "\n";
    }
    for (const auto& warning : loaded.warnings) std::cout << "WARNING: " << warning << "\n";
    for (const auto& error : loaded.errors) std::cout << "ERROR: " << error << "\n";
    if (loaded.errors.empty()) std::cout << "Template validation: PASS (static/schema checks; image-dependent hashes are checked after apply)\n";
    else std::cout << "Template validation: FAIL (" << loaded.errors.size() << " errors)\n";
}

std::string cpu_name(ldid::CPUType cpu) {
    switch (cpu) {
        case ldid::CPUType::ARM64: return "arm64";
        case ldid::CPUType::ARM64_32: return "arm64_32";
        case ldid::CPUType::ARM: return "arm";
        case ldid::CPUType::X86_64: return "x86_64";
        case ldid::CPUType::X86: return "i386";
        case ldid::CPUType::POWERPC: return "ppc";
        case ldid::CPUType::POWERPC64: return "ppc64";
        default: return "cpu(" + std::to_string(static_cast<uint32_t>(cpu)) + ")";
    }
}

std::string code_directory_flags(uint32_t flags) {
    const std::array<std::pair<uint32_t, const char*>, 12> known{{
        {0x00000001U, "VALID"}, {0x00000002U, "ADHOC"}, {0x00000100U, "HARD"},
        {0x00000200U, "KILL"}, {0x00000400U, "CHECK_EXPIRATION"}, {0x00000800U, "RESTRICT"},
        {0x00001000U, "ENFORCEMENT"}, {0x00002000U, "GET_TASK_ALLOW"}, {0x00004000U, "LIBRARY_VALIDATION"},
        {0x00008000U, "FOR_TESTING"}, {0x00010000U, "RUNTIME"}, {0x00020000U, "LINKER_SIGNED"}
    }};
    std::ostringstream out;
    bool first = true;
    uint32_t remaining = flags;
    for (const auto& [mask, name] : known) {
        if ((flags & mask) == 0) continue;
        if (!first) out << '|';
        out << name; first = false; remaining &= ~mask;
    }
    if (remaining != 0 || first) {
        if (!first) out << '|';
        out << "UNKNOWN(0x" << std::hex << remaining << ')';
    }
    return out.str();
}

void print_oid_list(const char* label, const std::vector<std::string>& oids) {
    std::cout << "        " << label << ":";
    if (oids.empty()) {
        std::cout << " (none)\n";
        return;
    }
    std::cout << "\n";
    for (const auto& oid : oids) std::cout << "          " << oid << "\n";
}

void print_slice_classification(const ProvisionProfileEvidence& profile,
                                const std::vector<CmsSignerEvidence>& signers,
                                bool adhoc, const std::filesystem::path& path) {
    const auto classification = classify_ios_signature(profile, signers, adhoc, path);
    std::cout << "    Signing classification: " << classification.label << "\n";
    for (const auto& line : classification.evidence) std::cout << "      evidence: " << line << "\n";
    for (const auto& line : classification.limitations) std::cout << "      limitation: " << line << "\n";
}

void inspect_one_macho(const std::filesystem::path& path, const std::vector<uint8_t>& data,
                       const ProvisionProfileEvidence& profile, const std::filesystem::path& classification_path,
                       const ldid::VerificationOptions& verification_options = {}) {
    const auto slices = ldid::macho::parse_slices_impl(data);
    if (slices.empty()) {
        std::cout << "Mach-O: no valid slices in " << path << "\n";
        return;
    }
    for (size_t i = 0; i < slices.size(); ++i) {
        const auto& slice = slices[i];
        std::vector<uint8_t> thin(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                  data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        const auto analysis = ldid::macho::analyze_thin(thin, 0);
        std::vector<CmsSignerEvidence> slice_signers;
        bool adhoc = false;
        std::cout << "\n  Slice[" << i << "] " << cpu_name(slice.cpu_type) << " subtype=" << slice.cpu_subtype
                  << " offset=" << slice.offset << " size=" << slice.size << "\n";
        if (!analysis.valid || analysis.code_signature_size == 0 || analysis.code_signature_offset > thin.size() ||
            analysis.code_signature_size > thin.size() - analysis.code_signature_offset) {
            std::cout << "    Signature: missing or invalid LC_CODE_SIGNATURE\n";
            print_slice_classification(profile, slice_signers, false, classification_path);
            continue;
        }
        std::vector<uint8_t> signature(thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
                                       thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
        const auto super = ldid::verifier::parse_superblob(signature);
        if (!super.valid) {
            std::cout << "    SuperBlob: INVALID\n";
            print_slice_classification(profile, slice_signers, false, classification_path);
            continue;
        }
        std::cout << "    SuperBlob magic=0x" << std::hex << super.magic << std::dec << " length=" << super.length
                  << " count=" << super.slots.size() << "\n";
        for (const auto& [slot, blob] : super.slots) {
            std::cout << "      slot 0x" << std::hex << slot << std::dec << " " << superblob_slot_name(slot)
                      << " size=" << blob.size() << " magic=0x";
            if (blob.size() >= 4) std::cout << std::hex << ((static_cast<uint32_t>(blob[0]) << 24) | (static_cast<uint32_t>(blob[1]) << 16) | (static_cast<uint32_t>(blob[2]) << 8) | blob[3]) << std::dec;
            else std::cout << "?";
            std::cout << "\n";
        }
        const auto cd_it = super.slots.find(0);
        if (cd_it != super.slots.end()) {
            const auto cd = ldid::verifier::parse_code_directory(cd_it->second);
            if (cd) {
                adhoc = (cd->flags & static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC)) != 0;
                std::cout << "    Primary CodeDirectory: " << code_directory_version_name(cd->version)
                          << " identifier='" << cd->identifier << "' teamID='" << cd->team_id << "'\n";
                std::cout << "      hash=" << hash_type_name(cd->hash_type) << " hashSize=" << static_cast<unsigned>(cd->hash_size)
                          << " flags=0x" << std::hex << cd->flags << std::dec << " (" << code_directory_flags(cd->flags) << ") platformIdentifier=" << static_cast<unsigned>(cd->platform)
                          << " pageSize=" << (cd->page_size_exp == 0 ? std::string("infinite") : std::to_string(1U << cd->page_size_exp))
                          << " codeLimit=" << cd->code_limit << " nCodeSlots=" << cd->n_code << " nSpecialSlots=" << cd->n_special << "\n";
                if (cd->version >= 0x20400) std::cout << "      execSegBase=" << cd->exec_seg_base << " execSegLimit=" << cd->exec_seg_limit << " execSegFlags=0x" << std::hex << cd->exec_seg_flags << std::dec << "\n";
                if (cd->version >= 0x20500) std::cout << "      runtime=0x" << std::hex << cd->runtime << std::dec << " preEncryptOffset=" << cd->pre_encrypt_offset << "\n";
                if (cd->version >= 0x20600) std::cout << "      linkageHashType=" << static_cast<unsigned>(cd->linkage_hash_type)
                    << " linkageApplicationType=" << static_cast<unsigned>(cd->linkage_application_type)
                    << " linkageApplicationSubType=" << cd->linkage_application_subtype
                    << " linkageOffset=" << cd->linkage_offset << " linkageSize=" << cd->linkage_size << "\n";
                const auto digest = ldid::CryptoEngine::hash(static_cast<ldid::HashType>(cd->hash_type), cd->blob);
                if (!digest.empty()) {
                    const size_t cdhash_size = std::min<size_t>(20, digest.size());
                    const std::vector<uint8_t> cdhash(digest.begin(), digest.begin() + static_cast<std::ptrdiff_t>(cdhash_size));
                    std::cout << "      cdhash=" << ldid::to_hex(cdhash) << "\n";
                }
            } else std::cout << "    Primary CodeDirectory: UNSUPPORTED OR INVALID\n";
        } else {
            std::cout << "    Primary CodeDirectory: MISSING\n";
        }
        for (const auto& [alt_slot, alt_blob] : super.slots) {
            if (alt_slot < 0x1000U || alt_slot > 0x1004U) continue;
            const auto alt = ldid::verifier::parse_code_directory(alt_blob);
            std::cout << "    Alternate CodeDirectory slot 0x" << std::hex << alt_slot << std::dec;
            if (!alt) {
                std::cout << ": UNSUPPORTED OR INVALID\n";
                continue;
            }
            const auto alt_digest = ldid::CryptoEngine::hash(static_cast<ldid::HashType>(alt->hash_type), alt->blob);
            const size_t alt_cdhash_size = std::min<size_t>(20, alt_digest.size());
            std::cout << ": " << code_directory_version_name(alt->version)
                      << " hash=" << hash_type_name(alt->hash_type)
                      << " identifier='" << alt->identifier << "' teamID='" << alt->team_id << "'"
                      << " flags=0x" << std::hex << alt->flags << std::dec << " (" << code_directory_flags(alt->flags) << ")"
                      << " platform=" << static_cast<unsigned>(alt->platform)
                      << " pageSize=" << (alt->page_size_exp == 0 ? std::string("infinite") : std::to_string(1U << alt->page_size_exp))
                      << " codeLimit=" << alt->code_limit << " nCodeSlots=" << alt->n_code
                      << " cdhash=" << ldid::to_hex(std::vector<uint8_t>(alt_digest.begin(), alt_digest.begin() + static_cast<std::ptrdiff_t>(alt_cdhash_size))) << "\n";
        }
        std::cout << "    Kernel validation category: UNKNOWN (runtime/kernel state; not encoded as a user-settable CodeDirectory field)\n";
        const auto cms_it = super.slots.find(0x10000);
        if (cms_it != super.slots.end() && cms_it->second.size() >= 8) {
            const std::vector<uint8_t> cms(cms_it->second.begin() + 8, cms_it->second.end());
            bool cms_math = false;
            slice_signers = inspect_cms_signers(cms, &cms_math, cd_it == super.slots.end() ? nullptr : &cd_it->second);
            std::cout << "    CMS: " << (cms.empty() ? "empty wrapper (ad-hoc)" : (cms_math ? "mathematical signature valid" : "mathematical signature invalid or unrecognized"))
                      << "; certificate-chain policy=" << (verification_options.certificate_chain.enabled ? "enabled" : "disabled")
                      << " signerCount=" << slice_signers.size() << "\n";
            for (size_t si = 0; si < slice_signers.size(); ++si) {
                const auto& signer = slice_signers[si];
                std::cout << "      SignerInfo[" << si << "] CN='" << signer.common_name << "' subject='" << signer.subject << "'\n"
                          << "        digestAlgorithm=" << signer.digest_algorithm
                          << " signatureAlgorithm=" << signer.signature_algorithm
                          << " SHA256(cert)=" << signer.sha256_fingerprint << "\n"
                          << "        notBefore=" << signer.not_before << " notAfter=" << signer.not_after
                          << " validityNow=" << (signer.certificate_valid_now ? "yes" : "no") << "\n"
                          << "        signingTime=" << (signer.has_signing_time ? "yes" : "no")
                          << " RFC3161Token=" << (signer.has_timestamp_token ? "yes" : "no")
                          << " AppleCdHashAttr=" << (signer.has_apple_cdhash_attribute ? "yes" : "no") << "\n";
                print_oid_list("signedAttributeOIDs", signer.signed_attribute_oids);
                print_oid_list("unsignedAttributeOIDs", signer.unsigned_attribute_oids);
            }
            if (slice_signers.size() > 1)
                std::cout << "      NOTICE: multiple SignerInfo entries are inspect-only in custom apply mode\n";
        } else {
            std::cout << "    CMS: absent\n";
        }
        const auto verify = ldid::Verifier::verify_memory(thin, verification_options);
        std::cout << "    Internal validation: " << (verify.ok ? "PASS" : "FAIL") << "\n";
        for (const auto& error : verify.errors) std::cout << "      ! " << error << "\n";
        print_slice_classification(profile, slice_signers, adhoc, classification_path);
    }
}

std::vector<CmsSignerEvidence> signers_for_macho_file(const std::filesystem::path& file) {
    const auto data = ldid::read_file(file);
    const auto slices = ldid::macho::parse_slices_impl(data);
    std::vector<CmsSignerEvidence> combined;
    for (const auto& slice : slices) {
        if (slice.offset > data.size() || slice.size > data.size() - slice.offset) continue;
        const std::vector<uint8_t> thin(data.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                        data.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
        const auto analysis = ldid::macho::analyze_thin(thin, 0);
        if (!analysis.valid || analysis.code_signature_size == 0 ||
            analysis.code_signature_offset > thin.size() ||
            analysis.code_signature_size > thin.size() - analysis.code_signature_offset) continue;
        const std::vector<uint8_t> signature(thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
            thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
        const auto parsed = ldid::verifier::parse_superblob(signature);
        if (!parsed.valid) continue;
        const auto cms = parsed.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::CMS_SIGNATURE));
        if (cms == parsed.slots.end() || cms->second.size() < 8) continue;
        const std::vector<uint8_t> der(cms->second.begin() + 8, cms->second.end());
        bool math = false;
        const auto cd = parsed.slots.find(0U);
        auto slice_signers = inspect_cms_signers(der, &math, cd == parsed.slots.end() ? nullptr : &cd->second);
        combined.insert(combined.end(), slice_signers.begin(), slice_signers.end());
    }
    return combined;
}

void validate_profile_against_app(const ProvisionProfileEvidence& profile,
                                  const std::filesystem::path& app_bundle,
                                  const std::filesystem::path& main_executable,
                                  std::vector<std::string>& errors,
                                  std::vector<std::string>& warnings) {
    if (!profile.present) return;
    if (!profile.cms_math_valid) {
        errors.push_back("embedded.mobileprovision CMS mathematical signature is invalid");
        return;
    }
    if (profile.expired) errors.push_back("embedded.mobileprovision is expired");
    if (profile.cms_chain_checked && !profile.cms_chain_valid)
        errors.push_back("embedded.mobileprovision certificate chain validation failed: " +
                         (profile.cms_chain_error.empty() ? std::string("unknown chain error") : profile.cms_chain_error));
    const auto bundle_id = bundle_identifier_from_info_plist(app_bundle);
    if (bundle_id.empty()) warnings.push_back("CFBundleIdentifier could not be read for profile application-identifier matching");
    else if (!profile.application_identifier.empty()) {
        const std::string prefix = !profile.application_identifier_prefix.empty()
            ? profile.application_identifier_prefix : profile.team_id;
        if (!prefix.empty()) {
            const std::string expected = prefix + "." + bundle_id;
            if (!profile_identifier_matches(profile.application_identifier, expected))
                errors.push_back("profile application-identifier does not match ApplicationIdentifierPrefix + CFBundleIdentifier");
        } else {
            warnings.push_back("ApplicationIdentifierPrefix and TeamIdentifier are missing; bundle identifier binding could not be checked");
        }
    }
    if (!main_executable.empty() && std::filesystem::is_regular_file(main_executable)) {
        const auto executable = ldid::read_file(main_executable);
        const auto signature = ldid::macho::get_signature_info_impl(executable);
        if (!profile.team_id.empty() && !signature.team_id.empty() && profile.team_id != signature.team_id)
            errors.push_back("CodeDirectory Team ID does not match provisioning profile TeamIdentifier");
        const auto signer_evidence = signers_for_macho_file(main_executable);
        bool matched = false;
        for (const auto& signer : signer_evidence) {
            if (!signer.sha256_fingerprint.empty() && profile.developer_certificate_fingerprints.count(signer.sha256_fingerprint))
                matched = true;
            if (signer.certificate_expired)
                warnings.push_back("CMS signing certificate is expired at inspection time: " + signer.common_name +
                                   " (notAfter=" + signer.not_after +"); an authenticated trusted timestamp may affect historical validity");
            else if (signer.certificate_not_yet_valid)
                errors.push_back("CMS signing certificate is not yet valid: " + signer.common_name + " (notBefore=" + signer.not_before + ")");
        }
        if (!profile.developer_certificate_fingerprints.empty() && !signer_evidence.empty() && !matched)
            errors.push_back("CMS leaf signer certificate does not match any profile DeveloperCertificates entry");
        else if (profile.developer_certificate_fingerprints.empty())
            warnings.push_back("profile has no parseable DeveloperCertificates entries");

        if (!signature.entitlements_xml.empty()) {
            const std::vector<uint8_t> app_entitlement_bytes(signature.entitlements_xml.begin(), signature.entitlements_xml.end());
            plist_t app_entitlements = ldid::plist_from_xml_bytes(app_entitlement_bytes);
            if (!app_entitlements || plist_get_node_type(app_entitlements) != PLIST_DICT) {
                if (app_entitlements) plist_free(app_entitlements);
                errors.push_back("signed XML Entitlements are not a plist dictionary");
            } else {
                plist_dict_iter app_iter = nullptr;
                plist_dict_new_iter(app_entitlements, &app_iter);
                if (app_iter) {
                    for (;;) {
                        char* key = nullptr; plist_t value = nullptr;
                        plist_dict_next_item(app_entitlements, app_iter, &key, &value);
                        if (!key || !value) { free(key); break; }
                        if (!profile.entitlement_keys.count(key))
                            errors.push_back(std::string("signed entitlement is not allowed by profile: ") + key);
                        if (std::string(key) == "get-task-allow") {
                            uint8_t allow = 0;
                            if (plist_get_node_type(value) == PLIST_BOOLEAN) plist_get_bool_val(value, &allow);
                            if (allow && !profile.get_task_allow)
                                errors.push_back("signed get-task-allow=true is not permitted by provisioning profile");
                        }
                        free(key);
                    }
                    free(app_iter);
                }
                plist_free(app_entitlements);
            }
        }
    }
}

void validate_apple_internal_profile_target(const std::filesystem::path& target,
                                             const ldid::VerificationOptions& verification_options,
                                             bool require_der_encoded_profile,
                                             std::vector<std::string>& errors,
                                             std::vector<std::string>& warnings) {
    std::filesystem::path inspect_root = target;
    std::filesystem::path temp_dir;
    std::error_code ec;
    if (std::filesystem::is_regular_file(target, ec) && target.extension() == ".ipa") {
        temp_dir = std::filesystem::temp_directory_path() /
            ("ldid-apple-internal-check-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
        std::filesystem::create_directories(temp_dir);
        try {
            ldid::ArchiveEngine::extract_ipa(target, temp_dir);
            inspect_root = ldid::ArchiveEngine::find_app_bundle(temp_dir);
        } catch (...) {
            std::filesystem::remove_all(temp_dir, ec);
            throw;
        }
    }
    auto app_bundle = locate_app_bundle(inspect_root);
    if (app_bundle.empty() && std::filesystem::is_directory(inspect_root, ec))
        app_bundle = ldid::ArchiveEngine::find_app_bundle(inspect_root);
    if (app_bundle.empty()) {
        errors.push_back("Apple Internal policy requires an .app bundle output");
    } else {
        const auto profile_path = app_bundle / "embedded.mobileprovision";
        const auto profile = inspect_provisioning_profile(profile_path, nullptr, verification_options.certificate_chain);
        if (!profile.present) {
            errors.push_back("Apple Internal policy output has no embedded.mobileprovision");
        } else {
            if (!profile.apple_internal_profile)
                errors.push_back("embedded.mobileprovision does not claim AppleInternalProfile=true");
            if (require_der_encoded_profile && !profile.der_encoded_profile_present)
                errors.push_back("embedded.mobileprovision is missing required DER-Encoded-Profile data");
            if (!profile.cms_math_valid)
                errors.push_back("embedded.mobileprovision CMS mathematical signature is invalid: " + profile.error);
            if (profile.expired)
                errors.push_back("embedded Apple Internal provisioning profile is expired");
            if (!profile.cms_chain_checked)
                errors.push_back("embedded Apple Internal profile certificate-chain validation was not performed");
            else if (!profile.cms_chain_valid)
                errors.push_back("embedded Apple Internal provisioning profile chain does not reach a trusted root: " + profile.cms_chain_error);
            const auto executable = ldid::ArchiveEngine::find_executable_in_bundle(app_bundle);
            validate_profile_against_app(profile, app_bundle, executable, errors, warnings);
            if (profile.team_id.empty()) errors.push_back("Apple Internal profile has no TeamIdentifier");
            if (profile.application_identifier.empty()) errors.push_back("Apple Internal profile has no Entitlements.application-identifier");
            if (profile.developer_certificate_fingerprints.empty()) errors.push_back("Apple Internal profile has no parseable DeveloperCertificates certificate");
            if (executable.empty()) {
                errors.push_back("cannot locate the app's main executable for signer/profile matching");
            } else {
                const auto executable_bytes = ldid::read_file(executable);
                const auto signature = ldid::MachOParser::get_signature_info(executable_bytes);
                if (signature.team_id.empty()) errors.push_back("signed app executable has no CodeDirectory Team ID");
                else if (!profile.team_id.empty() && signature.team_id != profile.team_id)
                    errors.push_back("signed app executable Team ID does not match Apple Internal profile TeamIdentifier");
                const auto signer_evidence = signers_for_macho_file(executable);
                bool signer_matches = false;
                for (const auto& signer : signer_evidence) {
                    if (!signer.sha256_fingerprint.empty() &&
                        profile.developer_certificate_fingerprints.count(signer.sha256_fingerprint))
                        signer_matches = true;
                }
                if (signer_evidence.empty()) errors.push_back("signed app executable has no CMS signer; ad-hoc signing is not accepted by Apple Internal policy");
                else if (!signer_matches) errors.push_back("CMS signer certificate is not listed in Apple Internal profile DeveloperCertificates");
            }
        }

        // An app extension is a separately signed bundle and normally carries
        // its own profile; validate those profiles against their own executable.
        for (auto it = std::filesystem::recursive_directory_iterator(app_bundle,
                 std::filesystem::directory_options::skip_permission_denied, ec);
             !ec && it != std::filesystem::recursive_directory_iterator(); ++it) {
            if (!it->is_directory(ec) || ec) { ec.clear(); continue; }
            if (it->path().extension() != ".appex") continue;
            const auto ext_profile = inspect_provisioning_profile(it->path() / "embedded.mobileprovision",
                nullptr, verification_options.certificate_chain);
            if (!ext_profile.present) {
                errors.push_back("app extension has no embedded.mobileprovision: " + it->path().string());
                continue;
            }
            if (!ext_profile.apple_internal_profile)
                errors.push_back("app extension profile does not claim AppleInternalProfile=true: " + it->path().string());
            if (require_der_encoded_profile && !ext_profile.der_encoded_profile_present)
                errors.push_back("app extension profile is missing required DER-Encoded-Profile: " + it->path().string());
            if (!ext_profile.cms_math_valid) errors.push_back("app extension profile CMS mathematical signature is invalid: " + it->path().string());
            if (!ext_profile.cms_chain_checked)
                errors.push_back("app extension profile certificate-chain validation was not performed: " + it->path().string());
            else if (!ext_profile.cms_chain_valid)
                errors.push_back("app extension profile certificate chain does not reach a trusted root: " + ext_profile.cms_chain_error + " (" + it->path().string() + ")");
            if (ext_profile.expired) errors.push_back("app extension profile has expired: " + it->path().string());
            if (ext_profile.developer_certificate_fingerprints.empty())
                errors.push_back("app extension profile has no parseable DeveloperCertificates certificate: " + it->path().string());
            const auto ext_executable = ldid::ArchiveEngine::find_executable_in_bundle(it->path());
            validate_profile_against_app(ext_profile, it->path(), ext_executable, errors, warnings);
            if (ext_executable.empty()) {
                errors.push_back("cannot locate app extension executable: " + it->path().string());
            } else {
                const auto ext_signature = ldid::MachOParser::get_signature_info(ldid::read_file(ext_executable));
                const auto ext_signers = signers_for_macho_file(ext_executable);
                bool ext_signer_matches = false;
                for (const auto& signer : ext_signers)
                    if (!signer.sha256_fingerprint.empty() && ext_profile.developer_certificate_fingerprints.count(signer.sha256_fingerprint))
                        ext_signer_matches = true;
                if (ext_signature.team_id.empty() || (!ext_profile.team_id.empty() && ext_signature.team_id != ext_profile.team_id))
                    errors.push_back("app extension CodeDirectory Team ID does not match its profile: " + it->path().string());
                if (ext_signers.empty() || !ext_signer_matches)
                    errors.push_back("app extension CMS signer does not match its profile DeveloperCertificates: " + it->path().string());
            }
            it.disable_recursion_pending();
        }
    }
    if (!temp_dir.empty()) std::filesystem::remove_all(temp_dir, ec);
}

int inspect_detached_signature_file(const std::filesystem::path& input, bool validate,
                                    const ldid::VerificationOptions& verification_options = {}) {
    const auto bytes = ldid::read_file(input);
    if (bytes.empty()) throw std::runtime_error("detached signature file is empty");
    const auto parsed = ldid::verifier::parse_superblob(bytes);
    if (!parsed.valid || parsed.magic != 0xfade0cc1U)
        throw std::invalid_argument("file is not a structurally valid detached signature SuperBlob (0xfade0cc1)");
    std::cout << "Detached Signature: " << input << "\n"
              << "SuperBlob magic=0x" << std::hex << parsed.magic << std::dec
              << " length=" << parsed.length << " slots=" << parsed.slots.size() << "\n"
              << "Certificate-chain verification: " << (verification_options.certificate_chain.enabled ? "ENABLED" : "DISABLED (default)")
              << "; require self-signed root: " << (verification_options.certificate_chain.require_root ? "yes" : "no") << "\n";
    for (const auto& [slot, blob] : parsed.slots) {
        std::cout << "  slot 0x" << std::hex << slot << std::dec << " " << superblob_slot_name(slot)
                  << " bytes=" << blob.size() << "\n";
    }
    const auto cd_it = parsed.slots.find(0U);
    if (cd_it == parsed.slots.end()) throw std::runtime_error("detached signature has no primary CodeDirectory");
    const auto cd = ldid::verifier::parse_code_directory(cd_it->second);
    if (!cd) throw std::runtime_error("detached signature primary CodeDirectory is unsupported or malformed");
    std::cout << "  CodeDirectory=" << code_directory_version_name(cd->version)
              << " identifier='" << cd->identifier << "' teamID='" << cd->team_id << "'"
              << " hash=" << hash_type_name(cd->hash_type) << " codeLimit=" << cd->code_limit
              << " nCodeSlots=" << cd->n_code << "\n";
    bool cms_math = false;
    const auto cms_it = parsed.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::CMS_SIGNATURE));
    std::vector<CmsSignerEvidence> signers;
    bool cms_full_valid = false;
    if (cms_it != parsed.slots.end() && cms_it->second.size() >= 8) {
        std::vector<uint8_t> der(cms_it->second.begin() + 8, cms_it->second.end());
        signers = inspect_cms_signers(der, &cms_math, &cd_it->second);
        std::string cms_diagnostic;
        cms_full_valid = ldid::crypto::verify_pkcs7_impl(cd_it->second, der, verification_options.certificate_chain, &cms_diagnostic);
        std::cout << "  CMS mathematical validation: " << (cms_math ? "PASS" : "FAIL")
                  << "; SignerInfo count=" << signers.size()
                  << "; chain=" << (verification_options.certificate_chain.enabled ? (cms_full_valid ? "valid" : "invalid") : "not checked") << "\n";
        if (!cms_diagnostic.empty()) std::cout << "  CMS validation detail: " << cms_diagnostic << "\n";
        for (size_t i = 0; i < signers.size(); ++i)
            std::cout << "    SignerInfo[" << i << "] CN='" << signers[i].common_name
                      << "' digest=" << signers[i].digest_algorithm
                      << " signature=" << signers[i].signature_algorithm << "\n";
    } else {
        std::cout << "  CMS: absent\n";
    }
    std::cout << "  Code-page hashes: NOT CHECKED (detached signature inspection has no target executable)\n";
    if (validate) {
        std::cout << "Detached signature validation: INCOMPLETE without --with-code target; structure and CMS were inspected\n";
        if (cms_it != parsed.slots.end() && (!cms_math || (verification_options.certificate_chain.enabled && !cms_full_valid))) return 1;
        return 2;
    }
    if (cms_it == parsed.slots.end()) return 0;
    return cms_math && (!verification_options.certificate_chain.enabled || cms_full_valid) ? 0 : 1;
}

int run_signature_inspect(const std::filesystem::path& input, bool validate,
                          const ldid::VerificationOptions& verification_options = {}) {
    std::filesystem::path inspect_root = input;
    std::filesystem::path temp_dir;
    if (std::filesystem::is_regular_file(input)) {
        std::ifstream header(input, std::ios::binary);
        std::array<uint8_t, 4> prefix{};
        if (header.read(reinterpret_cast<char*>(prefix.data()), static_cast<std::streamsize>(prefix.size())) &&
            prefix[0] == 0xfa && prefix[1] == 0xde && prefix[2] == 0x0c && prefix[3] == 0xc1)
            return inspect_detached_signature_file(input, validate, verification_options);
    }
    std::error_code ec;
    if (std::filesystem::is_regular_file(input, ec) && input.extension() == ".ipa") {
        temp_dir = std::filesystem::temp_directory_path() / ("ldid-inspect-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
        std::filesystem::create_directories(temp_dir);
        ldid::ArchiveEngine::extract_ipa(input, temp_dir);
        inspect_root = ldid::ArchiveEngine::find_app_bundle(temp_dir);
        if (inspect_root.empty()) throw std::runtime_error("IPA contains no .app bundle");
    }
    auto app_bundle = locate_app_bundle(inspect_root);
    auto signature_bundle = locate_signature_bundle(inspect_root);
    std::filesystem::path profile_path = app_bundle.empty() ? std::filesystem::path() : app_bundle / "embedded.mobileprovision";
    ProvisionProfileEvidence profile;
    if (!profile_path.empty() && std::filesystem::exists(profile_path)) profile = inspect_provisioning_profile(profile_path, nullptr, verification_options.certificate_chain);
    std::cout << "Input: " << input << "\n";
    std::cout << "Certificate-chain verification: " << (verification_options.certificate_chain.enabled ? "ENABLED" : "DISABLED (default)")
              << "; require self-signed root: " << (verification_options.certificate_chain.require_root ? "yes" : "no") << "\n";
    if (profile.present) {
        std::cout << "Provisioning Profile: present; CMS DER=" << (profile.cms_der_valid ? "valid" : "invalid")
                  << "; CMS math=" << (profile.cms_math_valid ? "valid" : "invalid")
                  << (profile.cms_chain_checked ? (profile.cms_chain_valid ? "; chain=valid" : "; chain=invalid") : "; chain=not checked") << "\n";
        if (!profile.name.empty()) std::cout << "  Name: " << profile.name << "\n";
        if (!profile.uuid.empty()) std::cout << "  UUID: " << profile.uuid << "\n";
        if (!profile.team_id.empty()) std::cout << "  TeamIdentifier: " << profile.team_id << "\n";
        if (!profile.application_identifier_prefix.empty()) std::cout << "  ApplicationIdentifierPrefix: " << profile.application_identifier_prefix << "\n";
        std::cout << "  AppleInternalProfile: " << (profile.apple_internal_profile ? "true" : "false") << "\n"
                  << "  ProvisionedDevices: " << profile.provisioned_device_count
                  << " ProvisionsAllDevices: " << (profile.provisions_all_devices ? "true" : "false")
                  << " get-task-allow: " << (profile.get_task_allow ? "true" : "false")
                  << " developer certificates: " << profile.developer_certificate_count << "\n"
                  << "  DER-Encoded-Profile: " << (profile.der_encoded_profile_present ? "present" : "absent")
                  << " bytes=" << profile.der_encoded_profile_length << " (presence reported; DER profile semantics not independently interpreted)\n";
        if (!profile.expiration.empty()) std::cout << "  Expiration: " << profile.expiration << (profile.expired ? " (EXPIRED)" : "") << "\n";
        if (!profile.error.empty()) std::cout << "  Profile error: " << profile.error << "\n";
        if (!profile.cms_chain_error.empty()) std::cout << "  Profile chain error: " << profile.cms_chain_error << "\n";
    } else std::cout << "Provisioning Profile: absent (normal for many App Store-installed apps)\n";

    size_t macho_count = 0;
    std::filesystem::path main_executable_path;
    auto inspect_file = [&](const std::filesystem::path& file) {
        auto bytes = ldid::read_file(file);
        if (!ldid::MachOParser::is_macho(bytes)) return;
        ++macho_count;
        std::cout << "\nMach-O: " << file << "\n";
        ProvisionProfileEvidence local_profile;
        const auto containing_bundle = locate_signature_bundle(file);
        if (!containing_bundle.empty()) {
            const auto local_profile_path = containing_bundle / "embedded.mobileprovision";
            if (std::filesystem::is_regular_file(local_profile_path))
                local_profile = inspect_provisioning_profile(local_profile_path, nullptr, verification_options.certificate_chain);
        }
        inspect_one_macho(file, bytes, local_profile, file, verification_options);
    };
    if (std::filesystem::is_regular_file(inspect_root, ec)) {
        inspect_file(inspect_root);
    } else if (std::filesystem::is_directory(inspect_root, ec)) {
        const auto main_exec = signature_bundle.empty() ? std::filesystem::path() : ldid::ArchiveEngine::find_executable_in_bundle(signature_bundle);
        main_executable_path = main_exec;
        if (!main_exec.empty()) inspect_file(main_exec);
        const auto signables = ldid::ArchiveEngine::scan_for_signables(inspect_root);
        for (const auto& entry : signables) {
            const std::filesystem::path bundle(entry.path);
            if (!signature_bundle.empty() && std::filesystem::equivalent(bundle, signature_bundle, ec)) continue;
            const auto executable = ldid::ArchiveEngine::find_executable_in_bundle(bundle);
            if (!executable.empty() && executable != main_exec) inspect_file(executable);
        }
        if (!signature_bundle.empty() && main_exec.empty()) std::cout << "WARNING: CFBundleExecutable not found in " << signature_bundle << "\n";
    }
    if (macho_count == 0) std::cout << "No Mach-O executable discovered.\n";
    int exit_code = 0;
    if (validate) {
        auto result = ldid::Verifier::verify(inspect_root, verification_options);
        std::vector<std::string> profile_errors;
        std::vector<std::string> profile_warnings;
        if (!app_bundle.empty()) validate_profile_against_app(profile, app_bundle, main_executable_path,
                                                               profile_errors, profile_warnings);
        // Validate every nested signable bundle that carries its own profile;
        // never reuse the outer app's profile for a nested extension/framework.
        if (std::filesystem::is_directory(inspect_root, ec)) {
            const auto nested_entries = ldid::ArchiveEngine::scan_for_signables(inspect_root);
            for (const auto& entry : nested_entries) {
                if (!entry.is_directory) continue;
                const std::filesystem::path nested_bundle(entry.path);
                std::error_code same_ec;
                if (!app_bundle.empty() && std::filesystem::equivalent(nested_bundle, app_bundle, same_ec) && !same_ec) continue;
                const auto nested_profile_path = nested_bundle / "embedded.mobileprovision";
                if (!std::filesystem::is_regular_file(nested_profile_path)) continue;
                const auto nested_executable = ldid::ArchiveEngine::find_executable_in_bundle(nested_bundle);
                auto nested_profile = inspect_provisioning_profile(nested_profile_path, nullptr, verification_options.certificate_chain);
                std::vector<std::string> nested_errors, nested_warnings;
                validate_profile_against_app(nested_profile, nested_bundle, nested_executable, nested_errors, nested_warnings);
                for (const auto& error : nested_errors) profile_errors.push_back(nested_bundle.generic_string() + ": " + error);
                for (const auto& warning : nested_warnings) profile_warnings.push_back(nested_bundle.generic_string() + ": " + warning);
            }
        }
        const bool all_ok = result.ok && profile_errors.empty();
        std::cout << "\nSignature matrix validation: " << (all_ok ? "PASS" : "FAIL") << "\n";
        for (const auto& error : result.errors) { std::cout << "  ERROR: " << error << "\n"; exit_code = 1; }
        for (const auto& error : profile_errors) { std::cout << "  ERROR: " << error << "\n"; exit_code = 1; }
        for (const auto& warning : profile_warnings) std::cout << "  WARNING: " << warning << "\n";
        std::cout << "  CMS certificate-chain trust: " << (verification_options.certificate_chain.enabled ? "CHECKED" : "NOT CHECKED (default)") << "\n";
        if (verification_options.certificate_chain.enabled && verification_options.certificate_chain.require_root)
            std::cout << "  Root requirement: chain must terminate at a self-signed root certificate\n";
    }
    if (!temp_dir.empty()) std::filesystem::remove_all(temp_dir, ec);
    return exit_code;
}

struct SignatureDiffRecord {
    std::string key;
    bool signed_image = false;
    std::string identifier;
    std::string team_id;
    std::string cdhash;
    std::string entitlements;
    std::string requirements;
    std::string cms;
    uint32_t flags = 0;
    uint32_t version = 0;
    uint8_t platform = 0;
    ldid::HashType hash_type = ldid::HashType::ANY;
};

std::vector<std::filesystem::path> collect_macho_files(const std::filesystem::path& root) {
    std::vector<std::filesystem::path> files;
    std::error_code ec;
    if (std::filesystem::is_regular_file(root, ec)) {
        const auto bytes = ldid::read_file(root);
        if (ldid::MachOParser::is_macho(bytes)) files.push_back(root);
        return files;
    }
    if (!std::filesystem::is_directory(root, ec)) return files;
    std::filesystem::recursive_directory_iterator it(root, std::filesystem::directory_options::skip_permission_denied, ec), end;
    for (; !ec && it != end; it.increment(ec)) {
        std::error_code item_ec;
        if (it->is_symlink(item_ec)) { if (it->is_directory(item_ec)) it.disable_recursion_pending(); continue; }
        if (!it->is_regular_file(item_ec)) continue;
        std::ifstream f(it->path(), std::ios::binary);
        std::array<uint8_t, 4> magic{};
        if (f.read(reinterpret_cast<char*>(magic.data()), 4)) {
            std::vector<uint8_t> prefix(magic.begin(), magic.end());
            if (ldid::MachOParser::is_macho(prefix)) files.push_back(it->path());
        }
    }
    std::sort(files.begin(), files.end());
    return files;
}

std::filesystem::path resolve_signature_target(const std::filesystem::path& input,
                                               std::filesystem::path& temp_dir) {
    std::error_code ec;
    if (std::filesystem::is_regular_file(input, ec) && input.extension() == ".ipa") {
        temp_dir = std::filesystem::path(ldid::make_temp_dir());
        ldid::ArchiveEngine::extract_ipa(input, temp_dir);
        const auto app = ldid::ArchiveEngine::find_app_bundle(temp_dir);
        if (app.empty()) throw std::runtime_error("archive contains no app bundle: " + input.string());
        return app;
    }
    if (std::filesystem::is_directory(input, ec)) return input;
    return input;
}

std::vector<SignatureDiffRecord> collect_signature_diff_records(const std::filesystem::path& root) {
    std::vector<SignatureDiffRecord> records;
    const auto files = collect_macho_files(root);
    for (const auto& file : files) {
        const auto bytes = ldid::read_file(file);
        const auto slices = ldid::MachOParser::parse_slices(bytes);
        for (const auto& slice : slices) {
            if (slice.offset > bytes.size() || slice.size > bytes.size() - slice.offset) continue;
            const std::vector<uint8_t> thin(bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                            bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
            SignatureDiffRecord r;
            std::error_code ec;
            auto rel = root == file ? file.filename() : std::filesystem::relative(file, root, ec);
            r.key = (ec ? file.filename() : rel).generic_string() + "@" + cpu_name(slice.cpu_type) + ":" + std::to_string(slice.cpu_subtype);
            const auto info = ldid::MachOParser::get_signature_info(thin);
            r.identifier = info.identifier; r.team_id = info.team_id;
            r.cdhash = ldid::to_hex(info.cd_hash); r.entitlements = info.entitlements_xml;
            r.requirements = ldid::to_hex(info.requirements_blob); r.cms = ldid::to_hex(info.cms_signature);
            r.signed_image = !info.cd_hash.empty(); r.hash_type = info.hash_type;
            const auto analysis = ldid::macho::analyze_thin(thin, 0);
            if (analysis.valid && analysis.code_signature_size && analysis.code_signature_offset <= thin.size() &&
                analysis.code_signature_size <= thin.size() - analysis.code_signature_offset) {
                const std::vector<uint8_t> sig(thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
                    thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
                const auto parsed = ldid::verifier::parse_superblob(sig);
                if (parsed.valid) {
                    auto it = parsed.slots.find(0U);
                    if (it != parsed.slots.end()) {
                        const auto cd = ldid::verifier::parse_code_directory(it->second);
                        if (cd) { r.flags = cd->flags; r.version = cd->version; r.platform = cd->platform; r.hash_type = static_cast<ldid::HashType>(cd->hash_type); }
                    }
                }
            }
            records.push_back(std::move(r));
        }
    }
    return records;
}


std::string build_signature_inspect_json(const std::filesystem::path& input, bool validate,
                                         const ldid::VerificationOptions& verification,
                                         int exit_code, const std::string& text_report) {
    std::filesystem::path temp_dir;
    std::filesystem::path root;
    try { root = resolve_signature_target(input, temp_dir); }
    catch (...) { if (!temp_dir.empty()) { std::error_code ec; std::filesystem::remove_all(temp_dir, ec); } throw; }
    if (std::filesystem::is_regular_file(input)) {
        const auto raw = ldid::read_file(input);
        if (raw.size() >= 4 && ldid::load_be32(raw.data()) == 0xfade0cc1U) {
            const auto parsed = ldid::verifier::parse_superblob(raw);
            const auto primary = parsed.slots.find(0U);
            const auto cms = parsed.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::CMS_SIGNATURE));
            bool cms_math = false;
            std::vector<CmsSignerEvidence> signers;
            bool cms_policy_valid = false;
            if (parsed.valid && primary != parsed.slots.end() && cms != parsed.slots.end() && cms->second.size() > 8) {
                const std::vector<uint8_t> der(cms->second.begin() + 8, cms->second.end());
                signers = inspect_cms_signers(der, &cms_math, &primary->second);
                cms_policy_valid = ldid::crypto::verify_pkcs7_impl(primary->second, der, verification.certificate_chain);
            }
            std::ostringstream detached;
            detached << "{\"schema\":\"ldid.signature-report\",\"schemaVersion\":1"
                << ",\"kind\":\"detached-signature\",\"input\":\"" << json_escape(input.string()) << "\""
                << ",\"valid\":" << (validate ? "null" : ((parsed.valid && (cms == parsed.slots.end() || cms_math) &&
                    (!verification.certificate_chain.enabled || cms_policy_valid)) ? "true" : "false"))
                << ",\"codePageHashesChecked\":false,\"certificateChain\":{\"enabled\":"
                << (verification.certificate_chain.enabled ? "true" : "false") << ",\"requireRoot\":"
                << (verification.certificate_chain.require_root ? "true" : "false") << "}"
                << ",\"codeDirectoryPresent\":" << (primary != parsed.slots.end() ? "true" : "false")
                << ",\"cmsPresent\":" << (cms != parsed.slots.end() ? "true" : "false")
                << ",\"cmsMathValid\":" << (cms == parsed.slots.end() ? "null" : (cms_math ? "true" : "false"))
                << ",\"cmsChainValid\":" << (!verification.certificate_chain.enabled || cms == parsed.slots.end() ? "null" : (cms_policy_valid ? "true" : "false"))
                << ",\"signers\":[";
            for (size_t i = 0; i < signers.size(); ++i) {
                if (i) detached << ',';
                detached << "{\"commonName\":\"" << json_escape(signers[i].common_name) << "\",\"subject\":\""
                    << json_escape(signers[i].subject) << "\",\"sha256Fingerprint\":\"" << json_escape(signers[i].sha256_fingerprint) << "\"}";
            }
            detached << "],\"slots\":[";
            bool first = true;
            if (parsed.valid) for (const auto& [slot, blob] : parsed.slots) {
                if (!first) detached << ',';
                first = false;
                detached << "{\"slot\":" << slot << ",\"name\":\"" << json_escape(superblob_slot_name(slot))
                    << "\",\"bytes\":" << blob.size() << '}';
            }
            detached << "],\"report\":\"" << json_escape(text_report) << "\"}\n";
            std::error_code ec; if (!temp_dir.empty()) std::filesystem::remove_all(temp_dir, ec);
            return detached.str();
        }
    }
    std::ostringstream out;
    out << "{\"schema\":\"ldid.signature-report\",\"schemaVersion\":1"
        << ",\"input\":\"" << json_escape(input.string()) << "\""
        << ",\"mode\":\"" << (validate ? "validate" : "inspect") << "\""
        << ",\"valid\":" << (validate ? (exit_code == 0 ? "true" : "false") : "null")
        << ",\"certificateChain\":{\"enabled\":" << (verification.certificate_chain.enabled ? "true" : "false")
        << ",\"requireRoot\":" << (verification.certificate_chain.require_root ? "true" : "false")
        << ",\"caFile\":\"" << json_escape(verification.certificate_chain.ca_file) << "\""
        << ",\"caPath\":\"" << json_escape(verification.certificate_chain.ca_path) << "\"}"
        << ",\"files\":[";
    const auto files = collect_macho_files(root);
    bool first_file = true;
    for (const auto& file : files) {
        const auto bytes = ldid::read_file(file);
        const auto slices = ldid::MachOParser::parse_slices(bytes);
        if (!first_file) out << ',';
        first_file = false;
        std::error_code rel_ec;
        auto relative = root == file ? file.filename() : std::filesystem::relative(file, root, rel_ec);
        const auto bundle = locate_signature_bundle(file);
        ProvisionProfileEvidence profile;
        if (!bundle.empty()) {
            const auto profile_path = bundle / "embedded.mobileprovision";
            if (std::filesystem::is_regular_file(profile_path))
                profile = inspect_provisioning_profile(profile_path, nullptr, verification.certificate_chain);
        }
        out << "{\"path\":\"" << json_escape((rel_ec ? file.filename() : relative).generic_string()) << "\",\"provisioningProfile\":{" 
            << "\"present\":" << (profile.present ? "true" : "false")
            << ",\"cmsMathValid\":" << (profile.cms_math_valid ? "true" : "false")
            << ",\"chainChecked\":" << (profile.cms_chain_checked ? "true" : "false")
            << ",\"chainValid\":" << (profile.cms_chain_valid ? "true" : "false")
            << ",\"teamID\":\"" << json_escape(profile.team_id) << "\""
            << ",\"applicationIdentifierPrefix\":\"" << json_escape(profile.application_identifier_prefix) << "\""
            << ",\"applicationIdentifier\":\"" << json_escape(profile.application_identifier) << "\""
            << ",\"provisionedDeviceCount\":" << profile.provisioned_device_count
            << ",\"provisionsAllDevices\":" << (profile.provisions_all_devices ? "true" : "false")
            << ",\"appleInternalProfile\":" << (profile.apple_internal_profile ? "true" : "false")
            << ",\"getTaskAllow\":" << (profile.get_task_allow ? "true" : "false")
            << ",\"expired\":" << (profile.expired ? "true" : "false")
            << ",\"derEncodedProfilePresent\":" << (profile.der_encoded_profile_present ? "true" : "false") << "},\"slices\":[";
        bool first_slice = true;
        for (const auto& slice : slices) {
            if (slice.offset > bytes.size() || slice.size > bytes.size() - slice.offset) continue;
            const std::vector<uint8_t> thin(bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                            bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
            const auto info = ldid::MachOParser::get_signature_info(thin);
            const auto analysis = ldid::macho::analyze_thin(thin, 0);
            ldid::verifier::SuperBlobParseResult parsed;
            std::optional<ldid::verifier::CodeDirectoryView> cd;
            if (analysis.valid && analysis.code_signature_size != 0 &&
                analysis.code_signature_offset <= thin.size() &&
                analysis.code_signature_size <= thin.size() - analysis.code_signature_offset) {
                const std::vector<uint8_t> signature(
                    thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
                    thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
                parsed = ldid::verifier::parse_superblob(signature);
                if (parsed.valid) {
                    const auto primary = parsed.slots.find(0U);
                    if (primary != parsed.slots.end()) cd = ldid::verifier::parse_code_directory(primary->second);
                }
            }
            bool cms_math = false;
            std::vector<CmsSignerEvidence> signers;
            const auto cms = parsed.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::CMS_SIGNATURE));
            const auto primary = parsed.slots.find(0U);
            if (cms != parsed.slots.end() && cms->second.size() > 8) {
                const std::vector<uint8_t> der(cms->second.begin() + 8, cms->second.end());
                signers = inspect_cms_signers(der, &cms_math, primary == parsed.slots.end() ? nullptr : &primary->second);
            }
            const bool adhoc = cd && (cd->flags & static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC)) != 0;
            const auto classification = classify_ios_signature(profile, signers, adhoc, file);
            if (!first_slice) out << ',';
            first_slice = false;
            out << "{\"architecture\":\"" << json_escape(cpu_name(slice.cpu_type)) << "\""
                << ",\"cpuSubtype\":" << slice.cpu_subtype
                << ",\"signed\":" << (!info.cd_hash.empty() ? "true" : "false")
                << ",\"identifier\":\"" << json_escape(info.identifier) << "\""
                << ",\"teamID\":\"" << json_escape(info.team_id) << "\""
                << ",\"cdhash\":\"" << json_escape(ldid::to_hex(info.cd_hash)) << "\""
                << ",\"cmsPresent\":" << (cms != parsed.slots.end() ? "true" : "false")
                << ",\"cmsMathValid\":" << (cms == parsed.slots.end() ? "null" : (cms_math ? "true" : "false"))
                << ",\"xmlEntitlements\":" << (info.entitlements_xml.empty() ? "false" : "true")
                << ",\"derEntitlements\":" << (!info.entitlements_der.empty() ? "true" : "false")
                << ",\"requirementsPresent\":" << (!info.requirements_blob.empty() ? "true" : "false")
                << ",\"signingClassification\":\"" << json_escape(classification.label) << "\"";
            if (cd) {
                const uint64_t page_size = cd->page_size_exp < 63 ? (uint64_t{1} << cd->page_size_exp) : 0;
                out << ",\"codeDirectory\":{\"version\":\"" << json_escape(code_directory_version_name(cd->version)) << "\""
                    << ",\"versionRaw\":" << cd->version
                    << ",\"flags\":" << cd->flags
                    << ",\"hashType\":\"" << json_escape(hash_type_name(cd->hash_type)) << "\""
                    << ",\"hashSize\":" << static_cast<unsigned>(cd->hash_size)
                    << ",\"platform\":" << static_cast<unsigned>(cd->platform)
                    << ",\"pageSize\":" << page_size
                    << ",\"codeLimit\":" << cd->code_limit
                    << ",\"codeSlots\":" << cd->n_code
                    << ",\"specialSlots\":" << cd->n_special
                    << ",\"teamID\":\"" << json_escape(cd->team_id) << "\"}";
            } else out << ",\"codeDirectory\":null";
            out << ",\"alternateCodeDirectories\":[";
            bool first_alt = true;
            if (parsed.valid) {
                for (const auto& [slot, blob] : parsed.slots) {
                    if (slot < 0x1000 || slot > 0x1004) continue;
                    const auto alt = ldid::verifier::parse_code_directory(blob);
                    if (!alt) continue;
                    if (!first_alt) out << ',';
                    first_alt = false;
                    auto alt_cdhash = ldid::crypto::hash_impl(static_cast<ldid::HashType>(alt->hash_type), blob);
                    if (alt_cdhash.size() > 20) alt_cdhash.resize(20);
                    out << "{\"slot\":" << slot << ",\"version\":" << alt->version
                        << ",\"hashType\":\"" << json_escape(hash_type_name(alt->hash_type)) << "\""
                        << ",\"cdhash\":\"" << json_escape(ldid::to_hex(alt_cdhash)) << "\"}";
                }
            }
            out << "],\"cmsSigners\":[";
            for (size_t i = 0; i < signers.size(); ++i) {
                if (i) out << ',';
                out << "{\"commonName\":\"" << json_escape(signers[i].common_name) << "\""
                    << ",\"subject\":\"" << json_escape(signers[i].subject) << "\""
                    << ",\"sha256Fingerprint\":\"" << json_escape(signers[i].sha256_fingerprint) << "\""
                    << ",\"digestAlgorithm\":\"" << json_escape(signers[i].digest_algorithm) << "\""
                    << ",\"signatureAlgorithm\":\"" << json_escape(signers[i].signature_algorithm) << "\""
                    << ",\"certificateCurrentlyValid\":" << (signers[i].certificate_valid_now ? "true" : "false")
                    << ",\"notBefore\":\"" << json_escape(signers[i].not_before) << "\""
                    << ",\"notAfter\":\"" << json_escape(signers[i].not_after) << "\""
                    << ",\"hasTimestampToken\":" << (signers[i].has_timestamp_token ? "true" : "false")
                    << ",\"signedAttributeOids\":[";
                for (size_t oid = 0; oid < signers[i].signed_attribute_oids.size(); ++oid) { if (oid) out << ','; out << "\"" << json_escape(signers[i].signed_attribute_oids[oid]) << "\""; }
                out << "],\"unsignedAttributeOids\":[";
                for (size_t oid = 0; oid < signers[i].unsigned_attribute_oids.size(); ++oid) { if (oid) out << ','; out << "\"" << json_escape(signers[i].unsigned_attribute_oids[oid]) << "\""; }
                out << "]}";
            }
            out << "],\"classificationEvidence\":[";
            for (size_t i = 0; i < classification.evidence.size(); ++i) { if (i) out << ','; out << "\"" << json_escape(classification.evidence[i]) << "\""; }
            out << "],\"classificationLimitations\":[";
            for (size_t i = 0; i < classification.limitations.size(); ++i) { if (i) out << ','; out << "\"" << json_escape(classification.limitations[i]) << "\""; }
            out << "],\"superBlobSlots\":[";
            bool first_slot = true;
            if (parsed.valid) for (const auto& [slot, blob] : parsed.slots) {
                if (!first_slot) out << ',';
                first_slot = false;
                out << "{\"slot\":" << slot << ",\"name\":\"" << json_escape(superblob_slot_name(slot))
                    << "\",\"bytes\":" << blob.size() << '}';
            }
            out << "]}";
        }
        out << "]}";
    }
    out << "],\"report\":\"" << json_escape(text_report) << "\"}\n";
    std::error_code ec;
    if (!temp_dir.empty()) std::filesystem::remove_all(temp_dir, ec);
    return out.str();
}

int run_signature_diff(const std::filesystem::path& left, const std::filesystem::path& right, bool json, bool quiet) {
    std::filesystem::path left_temp, right_temp;
    const auto left_root = resolve_signature_target(left, left_temp);
    const auto right_root = resolve_signature_target(right, right_temp);
    auto lhs = collect_signature_diff_records(left_root);
    auto rhs = collect_signature_diff_records(right_root);
    std::map<std::string, SignatureDiffRecord> a, b;
    for (auto& r : lhs) a.emplace(r.key, std::move(r));
    for (auto& r : rhs) b.emplace(r.key, std::move(r));
    std::vector<std::string> changes;
    std::set<std::string> keys;
    for (const auto& [key, value] : a) keys.insert(key);
    for (const auto& [key, value] : b) keys.insert(key);
    for (const auto& key : keys) {
        auto ai = a.find(key), bi = b.find(key);
        if (ai == a.end()) { changes.push_back("ADDED in right: " + key); continue; }
        if (bi == b.end()) { changes.push_back("REMOVED in right: " + key); continue; }
        const auto& x = ai->second; const auto& y = bi->second;
        auto compare = [&](const char* field, const auto& xv, const auto& yv) {
            if (xv != yv) changes.push_back(key + ": " + field + " changed");
        };
        compare("signed state", x.signed_image, y.signed_image);
        compare("identifier", x.identifier, y.identifier);
        compare("Team ID", x.team_id, y.team_id);
        compare("cdhash", x.cdhash, y.cdhash);
        compare("CodeDirectory flags", x.flags, y.flags);
        compare("CodeDirectory version", x.version, y.version);
        compare("platform", x.platform, y.platform);
        compare("hash type", x.hash_type, y.hash_type);
        compare("Entitlements", x.entitlements, y.entitlements);
        compare("Requirements", x.requirements, y.requirements);
        compare("CMS", x.cms, y.cms);
    }
    if (quiet) {
        if (changes.empty()) std::cout << "SAME\n";
        else std::cout << "DIFFERENT " << changes.size() << "\n";
    } else if (json) {
        std::cout << "{\"left\":\"" << json_escape(left.string()) << "\",\"right\":\"" << json_escape(right.string())
                  << "\",\"identical\":" << (changes.empty() ? "true" : "false") << ",\"changes\":[";
        for (size_t i = 0; i < changes.size(); ++i) { if (i) std::cout << ','; std::cout << "\"" << json_escape(changes[i]) << "\""; }
        std::cout << "]}\n";
    } else {
        std::cout << "Signature diff\n  left: " << left << "\n  right: " << right << "\n";
        if (changes.empty()) std::cout << "No signature differences found.\n";
        else for (const auto& change : changes) std::cout << "  * " << change << "\n";
    }
    std::error_code ec; if (!left_temp.empty()) std::filesystem::remove_all(left_temp, ec); if (!right_temp.empty()) std::filesystem::remove_all(right_temp, ec);
    return changes.empty() ? 0 : 1;
}

struct AmfiPrecheckReport {
    std::vector<std::string> blockers;
    std::vector<std::string> warnings;
    size_t macho_count = 0;
    size_t slice_count = 0;
};

AmfiPrecheckReport run_amfi_precheck_analysis(const std::filesystem::path& root,
                                               const ldid::VerificationOptions& verification,
                                               uint32_t target_ios, const std::string& target_chip) {
    AmfiPrecheckReport report;
    const auto files = collect_macho_files(root);
    report.macho_count = files.size();
    if (files.empty()) report.blockers.push_back("no Mach-O executable found in target");
    for (const auto& file : files) {
        const auto bytes = ldid::read_file(file);
        const auto slices = ldid::MachOParser::parse_slices(bytes);
        for (const auto& slice : slices) {
            if (slice.offset > bytes.size() || slice.size > bytes.size() - slice.offset) continue;
            ++report.slice_count;
            const std::vector<uint8_t> thin(bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                            bytes.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
            const auto analysis = ldid::macho::analyze_thin(thin, 0);
            const std::string tag = file.filename().string() + " [" + cpu_name(slice.cpu_type) + "]";
            if (!analysis.valid || analysis.code_signature_size == 0 || analysis.code_signature_offset > thin.size() ||
                analysis.code_signature_size > thin.size() - analysis.code_signature_offset) {
                report.blockers.push_back(tag + ": missing or invalid LC_CODE_SIGNATURE");
                continue;
            }
            const std::vector<uint8_t> sig(thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset),
                thin.begin() + static_cast<std::ptrdiff_t>(analysis.code_signature_offset + analysis.code_signature_size));
            const auto super = ldid::verifier::parse_superblob(sig);
            if (!super.valid) { report.blockers.push_back(tag + ": malformed SuperBlob"); continue; }
            const auto cd_it = super.slots.find(0U);
            if (cd_it == super.slots.end()) { report.blockers.push_back(tag + ": primary CodeDirectory is missing"); continue; }
            const auto cd = ldid::verifier::parse_code_directory(cd_it->second);
            if (!cd) { report.blockers.push_back(tag + ": primary CodeDirectory is malformed/unsupported"); continue; }
            if (cd->platform != 0 && cd->platform != static_cast<uint8_t>(ldid::Platform::IOS))
                report.blockers.push_back(tag + ": CodeDirectory platform identifier is not iOS (value=" + std::to_string(cd->platform) + ")");
            else if (cd->platform == 0)
                report.warnings.push_back(tag + ": CodeDirectory platform identifier is unset; target compatibility cannot be inferred");
            const auto xml_it = super.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::ENTITLEMENTS));
            const auto der_it = super.slots.find(static_cast<uint32_t>(ldid::CodeSignSlot::DER_ENTITLEMENTS));
            if (xml_it != super.slots.end() && der_it == super.slots.end() && target_ios >= ((15U << 16) | 0U))
                report.blockers.push_back(tag + ": XML Entitlements present without DER Entitlements for target iOS 15+");
            if (der_it != super.slots.end() && der_it->second.size() <= 8)
                report.blockers.push_back(tag + ": DER Entitlements Blob is empty");
            const bool has_cms = super.slots.count(static_cast<uint32_t>(ldid::CodeSignSlot::CMS_SIGNATURE)) != 0;
            const bool adhoc = (cd->flags & static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC)) != 0;
            if (adhoc || !has_cms)
                report.warnings.push_back(tag + ": ad-hoc/no-CMS signature may require environment-specific installation trust or TrustCache; stock AMFI acceptance is not inferable offline");
            if (xml_it != super.slots.end() && xml_it->second.size() > 8) {
                std::vector<uint8_t> xml(xml_it->second.begin() + 8, xml_it->second.end());
                plist_t ent = ldid::plist_from_xml_bytes(xml);
                if (!ent || plist_get_node_type(ent) != PLIST_DICT) {
                    if (ent) plist_free(ent);
                    report.blockers.push_back(tag + ": XML Entitlements is not a valid plist dictionary");
                } else {
                    plist_dict_iter iter = nullptr; plist_dict_new_iter(ent, &iter);
                    if (iter) {
                        for (;;) {
                            char* key = nullptr; plist_t value = nullptr;
                            plist_dict_next_item(ent, iter, &key, &value);
                            if (!key || !value) { free(key); break; }
                            const std::string name(key);
                            if (name.rfind("com.apple.private.", 0) == 0)
                                report.warnings.push_back(tag + ": restricted private entitlement requires Apple/platform entitlement authorization: " + name);
                            if (name == "get-task-allow" && cfg_bool(ent, "get-task-allow", false))
                                report.warnings.push_back(tag + ": get-task-allow=true is a development/debug entitlement, not production distribution state");
                            if (name == "com.apple.security.cs.debugger" || name == "com.apple.security.cs.allow-jit" ||
                                name == "com.apple.security.cs.allow-unsigned-executable-memory" ||
                                name == "com.apple.security.cs.disable-library-validation" ||
                                name == "dynamic-codesigning" || name == "skip-library-validation") {
                                report.warnings.push_back(tag + ": sensitive code-signing entitlement may be subject to OS/device-specific AMFI policy: " + name);
                                if (target_ios >= ((15U << 16) | 0U) && !target_chip.empty()) {
                                    std::string chip = target_chip;
                                    std::transform(chip.begin(), chip.end(), chip.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
                                    if (chip.rfind("A12", 0) == 0 || chip.rfind("A13", 0) == 0 || chip.rfind("A14", 0) == 0 ||
                                        chip.rfind("A15", 0) == 0 || chip.rfind("A16", 0) == 0 || chip.rfind("A17", 0) == 0 ||
                                        chip.rfind("A18", 0) == 0 || chip.rfind("M1", 0) == 0 || chip.rfind("M2", 0) == 0 || chip.rfind("M3", 0) == 0 || chip.rfind("M4", 0) == 0)
                                        report.warnings.push_back(tag + ": target " + target_chip + " on iOS 15+ requires runtime validation for this entitlement combination");
                                }
                            }
                            free(key);
                        }
                        free(iter);
                    }
                    plist_free(ent);
                }
            }
        }
    }
    const auto verify = ldid::Verifier::verify(root, verification);
    for (const auto& error : verify.errors) report.blockers.push_back("internal verifier: " + error);
    return report;
}

int run_check_amfi(const std::filesystem::path& input, uint32_t target_ios,
                   const std::string& target_chip, const ldid::VerificationOptions& verification,
                   bool json, bool quiet) {
    std::filesystem::path temp_dir;
    const auto root = resolve_signature_target(input, temp_dir);
    const auto report = run_amfi_precheck_analysis(root, verification, target_ios, target_chip);
    const bool blocked = !report.blockers.empty();
    const bool warnings = !report.warnings.empty();
    if (quiet) {
        std::cout << (blocked ? "STATIC_BLOCKED" : (warnings ? "STATIC_REVIEW" : "NO_STATIC_BLOCKERS")) << "\n";
    } else if (json) {
        std::cout << "{\"input\":\"" << json_escape(input.string()) << "\",\"mode\":\"static-precheck-only\",\"targetIOS\":\""
                  << (target_ios ? std::to_string(target_ios >> 16) + "." + std::to_string((target_ios >> 8) & 0xff) : std::string("unspecified"))
                  << "\",\"targetChip\":\"" << json_escape(target_chip) << "\",\"machOFiles\":" << report.macho_count
                  << ",\"slices\":" << report.slice_count << ",\"certificateChainChecked\":" << (verification.certificate_chain.enabled ? "true" : "false")
                  << ",\"requireRoot\":" << (verification.certificate_chain.require_root ? "true" : "false")
                  << ",\"status\":\"" << (blocked ? "STATIC_BLOCKED" : (warnings ? "STATIC_REVIEW" : "NO_STATIC_BLOCKERS")) << "\",\"blockers\":[";
        for (size_t i = 0; i < report.blockers.size(); ++i) { if (i) std::cout << ','; std::cout << "\"" << json_escape(report.blockers[i]) << "\""; }
        std::cout << "],\"warnings\":[";
        for (size_t i = 0; i < report.warnings.size(); ++i) { if (i) std::cout << ','; std::cout << "\"" << json_escape(report.warnings[i]) << "\""; }
        std::cout << "],\"runtimeAMFI\":\"NOT_TESTED\"}\n";
    } else {
        std::cout << "AMFI preflight: STATIC ONLY (does not execute kernel/AMFI checks)\n"
                  << "Target iOS: " << (target_ios ? std::to_string(target_ios >> 16) + "." + std::to_string((target_ios >> 8) & 0xff) : "unspecified")
                  << " Target chip: " << (target_chip.empty() ? "unspecified" : target_chip) << "\n"
                  << "Mach-O files: " << report.macho_count << " slices: " << report.slice_count << "\n"
                  << "Certificate chain: " << (verification.certificate_chain.enabled ? "enabled" : "disabled (default)")
                  << "; require self-signed root: " << (verification.certificate_chain.require_root ? "yes" : "no") << "\n"
                  << "Result: " << (blocked ? "STATIC BLOCKERS FOUND" : (warnings ? "REVIEW REQUIRED" : "NO STATIC BLOCKERS FOUND")) << "\n";
        for (const auto& item : report.blockers) std::cout << "  BLOCKER: " << item << "\n";
        for (const auto& item : report.warnings) std::cout << "  WARNING: " << item << "\n";
        std::cout << "  NOTE: TrustCache, device model, OS build, Apple policy exceptions and runtime AMFI are not fully knowable from an offline file check.\n";
    }
    std::error_code ec; if (!temp_dir.empty()) std::filesystem::remove_all(temp_dir, ec);
    return blocked ? 1 : 0;
}

int apply_custom_signature_template(const std::filesystem::path& template_path,
                                    const std::filesystem::path& input,
                                    const std::filesystem::path& output,
                                    const std::vector<std::string>& credential_args) {
    auto loaded = load_custom_template(template_path);
    print_template_validation(loaded);
    if (!loaded.errors.empty()) return 2;
    auto options = loaded.options;
    for (size_t i = 0; i < credential_args.size(); ++i) {
        const auto& arg = credential_args[i];
        auto value = [&](const std::string& name) -> std::string {
            if (i + 1 >= credential_args.size()) throw std::invalid_argument("missing value for " + name);
            return credential_args[++i];
        };
        if (arg == "--p12" || arg == "-K") options.p12_path = value(arg);
        else if (arg == "--password" || arg == "-U") options.key_password = value(arg);
        else if (arg == "--cert") options.certificate_path = value(arg);
        else if (arg == "--key") options.private_key_path = value(arg);
        else if (arg == "--adhoc") options.adhoc = true;
        else if (arg == "--verify-chain") loaded.verification.certificate_chain.enabled = true;
        else if (arg == "--no-verify-chain") { loaded.verification.certificate_chain.enabled = false; loaded.verification.certificate_chain.require_root = false; }
        else if (arg == "--verify-chain-root") { loaded.verification.certificate_chain.enabled = true; loaded.verification.certificate_chain.require_root = true; }
        else if (arg == "--ca-file") { loaded.verification.certificate_chain.ca_file = value(arg); loaded.verification.certificate_chain.enabled = true; }
        else if (arg == "--ca-path") { loaded.verification.certificate_chain.ca_path = value(arg); loaded.verification.certificate_chain.enabled = true; }
        else if (arg == "--verify-time") { loaded.verification.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(value(arg), "verification time")); loaded.verification.certificate_chain.enabled = true; }
        else if (arg == "--timestamp-url") { options.timestamp_url = value(arg); options.timestamp_enabled = true; }
        else if (arg == "--timestamp-policy") options.timestamp_policy = value(arg);
        else if (arg == "--timestamp-ca-file") { options.timestamp_ca_file = value(arg); options.timestamp_enabled = true; }
        else if (arg == "--timestamp-ca-path") { options.timestamp_ca_path = value(arg); options.timestamp_enabled = true; }
        else if (arg == "--timestamp-required") { options.timestamp_enabled = true; options.timestamp_required = true; }
        else if (arg == "--timestamp-require-root") { options.timestamp_enabled = true; options.timestamp_required = true; options.timestamp_require_root = true; }
        else throw std::invalid_argument("unknown signature-apply option: " + arg);
    }
    if ((!options.certificate_path.empty() || !options.private_key_path.empty()) &&
        (options.certificate_path.empty() || options.private_key_path.empty())) throw std::invalid_argument("--cert and --key must be supplied together");
    if (!options.p12_path.empty() && (!options.certificate_path.empty() || !options.private_key_path.empty())) throw std::invalid_argument("choose either --p12 or --cert/--key");
    if (options.apple_internal_profile.enabled &&
        (options.adhoc || (options.p12_path.empty() && options.certificate_path.empty())))
        throw std::invalid_argument("Apple Internal profile policy requires a real certificate/private key; ad-hoc or unsigned-CMS signing is not accepted");
    if (options.apple_internal_profile.enabled &&
        (!loaded.verification.certificate_chain.enabled || !loaded.verification.certificate_chain.require_root))
        throw std::invalid_argument("Apple Internal profile policy cannot run with certificate-chain verification disabled or without a trusted root");
    if (options.apple_internal_profile.enabled) {
        std::error_code input_ec;
        const bool ipa_input = std::filesystem::is_regular_file(input, input_ec) && input.extension() == ".ipa";
        const bool input_is_directory = std::filesystem::is_directory(input, input_ec);
        const bool app_directory_input = input_is_directory &&
            (input.extension() == ".app" || !ldid::ArchiveEngine::find_app_bundle(input).empty());
        if (!ipa_input && !app_directory_input)
            throw std::invalid_argument("Apple Internal profile policy requires an .ipa or a directory containing an .app bundle; it cannot be applied to a standalone Mach-O file");
    }
    if (std::filesystem::is_directory(input)) {
        std::filesystem::path target = output.empty() ? input : output;
        if (!output.empty() && std::filesystem::absolute(output) != std::filesystem::absolute(input)) {
            if (std::filesystem::exists(output)) throw std::runtime_error("output already exists: " + output.string());
            std::filesystem::copy(input, output, std::filesystem::copy_options::recursive | std::filesystem::copy_options::copy_symlinks);
        }
        ldid::Signer::sign(target, options);
    } else if (input.extension() == ".ipa") {
        ldid::Signer::sign_ipa(input, output.empty() ? input : output, options);
    } else {
        options.output_path = output.string();
        ldid::Signer::sign(input, options);
    }
    const std::filesystem::path verify_target = output.empty() ? input : output;
    auto result = ldid::Verifier::verify(verify_target, loaded.verification);
    std::vector<std::string> policy_warnings;
    if (options.apple_internal_profile.enabled) {
        validate_apple_internal_profile_target(verify_target, loaded.verification,
            options.apple_internal_profile.require_der_encoded_profile, result.errors, policy_warnings);
        result.ok = result.ok && result.errors.empty();
    }
    std::cout << "Output: " << verify_target << "\n";
    std::cout << "Post-signature validation: " << (result.ok ? "PASS" : "FAIL") << "\n";
    for (const auto& error : result.errors) std::cout << "  ERROR: " << error << "\n";
    for (const auto& warning : policy_warnings) std::cout << "  WARNING: " << warning << "\n";
    std::cout << "Certificate-chain verification: " << (loaded.verification.certificate_chain.enabled ? "CHECKED" : "NOT CHECKED (default)") << "\n";
    return result.ok ? 0 : 1;
}

int run_custom_signature_cli(int argc, char** argv) {
    try {
        const std::string command = argv[1];
        if (command == "--signature-catalog") { print_signature_catalog(); return 0; }
        if (command == "--signature-template") {
            if (argc >= 3) {
                if (!ldid::write_text(argv[2], custom_signature_template_json())) throw std::runtime_error("cannot write template file");
                std::cout << "Wrote empty custom-signature template: " << argv[2] << "\n";
            } else std::cout << custom_signature_template_json() << "\n";
            return 0;
        }
        if (command == "--apple-internal-template") {
            if (argc >= 3) {
                if (!ldid::write_text(argv[2], apple_internal_signature_template_json())) throw std::runtime_error("cannot write Apple Internal template file");
                std::cout << "Wrote Apple Internal profile policy template (requires a real Apple-issued internal profile): " << argv[2] << "\n";
            } else std::cout << apple_internal_signature_template_json() << "\n";
            return 0;
        }
        if (command == "--signature-template-check") {
            if (argc != 3) throw std::invalid_argument("usage: ldid --signature-template-check template.json");
            auto loaded = load_custom_template(argv[2]); print_template_validation(loaded); return loaded.errors.empty() ? 0 : 2;
        }
        if (command == "--signature-diff") {
            if (argc < 4) throw std::invalid_argument("usage: ldid --signature-diff LEFT RIGHT [--json] [--quiet]");
            bool json = false, quiet = false;
            for (int i = 4; i < argc; ++i) {
                const std::string arg = argv[i];
                if (arg == "--json") json = true;
                else if (arg == "--quiet") quiet = true;
                else throw std::invalid_argument("unknown signature-diff option: " + arg);
            }
            return run_signature_diff(argv[2], argv[3], json, quiet);
        }
        if (command == "--check-amfi") {
            if (argc < 3) throw std::invalid_argument("usage: ldid --check-amfi path [--target-ios VERSION] [--target-chip A12|A13|...] [--verify-chain] [--verify-chain-root] [--ca-file FILE] [--ca-path DIR] [--json] [--quiet]");
            uint32_t target_ios = 0; std::string target_chip; bool json = false, quiet = false;
            ldid::VerificationOptions verification;
            for (int i = 3; i < argc; ++i) {
                const std::string arg = argv[i];
                auto value = [&](const char* name) -> std::string {
                    if (i + 1 >= argc) throw std::invalid_argument(std::string("missing value for ") + name);
                    return argv[++i];
                };
                if (arg == "--target-ios") target_ios = parse_version_value(value("--target-ios"));
                else if (arg == "--target-chip") target_chip = value("--target-chip");
                else if (arg == "--verify-chain") verification.certificate_chain.enabled = true;
                else if (arg == "--no-verify-chain") { verification.certificate_chain.enabled = false; verification.certificate_chain.require_root = false; }
                else if (arg == "--verify-chain-root") { verification.certificate_chain.enabled = true; verification.certificate_chain.require_root = true; }
                else if (arg == "--ca-file") { verification.certificate_chain.ca_file = value("--ca-file"); verification.certificate_chain.enabled = true; }
                else if (arg == "--ca-path") { verification.certificate_chain.ca_path = value("--ca-path"); verification.certificate_chain.enabled = true; }
                else if (arg == "--verify-time") { verification.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(value("--verify-time"), "verification time")); verification.certificate_chain.enabled = true; }
                else if (arg == "--json") json = true;
                else if (arg == "--quiet") quiet = true;
                else throw std::invalid_argument("unknown check-amfi option: " + arg);
            }
            return run_check_amfi(argv[2], target_ios, target_chip, verification, json, quiet);
        }
        if (command == "--signature-inspect" || command == "--signature-report" || command == "--signature-validate" || command == "--signature-check") {
            if (argc < 3) throw std::invalid_argument("usage: ldid --signature-inspect|--signature-validate path [--verify-chain] [--verify-chain-root] [--ca-file FILE] [--ca-path DIR] [--verify-time UNIX] [--json] [--quiet]");
            ldid::VerificationOptions verify_options;
            bool json = false, quiet = false;
            for (int i = 3; i < argc; ++i) {
                const std::string arg = argv[i];
                auto value = [&](const char* name) -> std::string {
                    if (i + 1 >= argc) throw std::invalid_argument(std::string("missing value for ") + name);
                    return argv[++i];
                };
                if (arg == "--verify-chain") verify_options.certificate_chain.enabled = true;
                else if (arg == "--no-verify-chain") { verify_options.certificate_chain.enabled = false; verify_options.certificate_chain.require_root = false; }
                else if (arg == "--verify-chain-root") { verify_options.certificate_chain.enabled = true; verify_options.certificate_chain.require_root = true; }
                else if (arg == "--ca-file") { verify_options.certificate_chain.ca_file = value("--ca-file"); verify_options.certificate_chain.enabled = true; }
                else if (arg == "--ca-path") { verify_options.certificate_chain.ca_path = value("--ca-path"); verify_options.certificate_chain.enabled = true; }
                else if (arg == "--verify-time") { verify_options.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(value("--verify-time"), "verification time")); verify_options.certificate_chain.enabled = true; }
                else if (arg == "--json") json = true;
                else if (arg == "--quiet") quiet = true;
                else throw std::invalid_argument("unknown signature-inspect option: " + arg);
            }
            const bool validate = command == "--signature-validate" || command == "--signature-check";
            if (json || quiet) {
                std::ostringstream captured;
                auto* previous = std::cout.rdbuf(captured.rdbuf());
                int rc = 0;
                try { rc = run_signature_inspect(argv[2], validate, verify_options); }
                catch (...) { std::cout.rdbuf(previous); throw; }
                std::cout.rdbuf(previous);
                const std::string report = captured.str();
                if (quiet) { if (rc != 0) std::cerr << report; else if (validate) std::cout << "PASS\n"; }
                else {
                    std::cout << build_signature_inspect_json(argv[2], validate, verify_options, rc, report);
                }
                return rc;
            }
            return run_signature_inspect(argv[2], validate, verify_options);
        }
        if (command == "--signature-apply") {
            if (argc < 4) throw std::invalid_argument("usage: ldid --signature-apply template.json input [output] [--p12 identity.p12 | --cert cert.pem --key key.pem | --adhoc]");
            std::filesystem::path output;
            int opt_start = 4;
            if (argc >= 5 && std::string(argv[4]).rfind("--", 0) != 0 && std::string(argv[4]) != "-K" && std::string(argv[4]) != "-U" && std::string(argv[4]) != "--cert") { output = argv[4]; opt_start = 5; }
            std::vector<std::string> credentials;
            for (int i = opt_start; i < argc; ++i) credentials.emplace_back(argv[i]);
            return apply_custom_signature_template(argv[2], argv[3], output, credentials);
        }
        return -1;
    } catch (const std::exception& e) {
        std::cerr << "ldid signature: " << e.what() << "\n";
        return 2;
    }
}

void print_usage() {
    std::cout << "usage: ldid [legacy signing options] [--verify-chain [--verify-chain-root] | --no-verify-chain] file...\n"
              << "       ldid --strip-codesig --deep bundle\n"
              << "       ldid --signature-catalog\n"
              << "       ldid --signature-template [template.json]\n"
              << "       ldid --apple-internal-template [template.json]\n"
              << "       ldid --signature-template-check template.json\n"
              << "       ldid --signature-inspect path\n"
              << "       ldid --signature-validate path [--verify-chain | --no-verify-chain] [--verify-chain-root] [--ca-file FILE] [--ca-path DIR] [--json] [--quiet]\n"
              << "       ldid --signature-diff LEFT RIGHT [--json] [--quiet]\n"
              << "       ldid --check-amfi path [--target-ios VERSION] [--target-chip A12|A13|...] [--json] [--quiet]\n"
              << "       ldid --signature-apply template.json input [output] [--p12 file | --cert cert.pem --key key.pem | --adhoc] [--verify-chain [--verify-chain-root]]\n"
              << "       ldid [--profile NAME] [--config FILE] [signing options] file...\n"
              << "       ldid --strip-codesig --deep bundle (strip signatures from the complete bundle tree)" << std::endl;
}

}

int main(int argc, char** argv) {
    if (argc >= 2) {
        const std::string command(argv[1]);
        if (command.rfind("--signature-", 0) == 0 || command == "--apple-internal-template" || command == "--check-amfi") {
            const int rc = run_custom_signature_cli(argc, argv);
            if (rc >= 0) return rc;
        }
    }
    if (argc >= 2 && std::string(argv[1]) == "--iosinject") {
        // Rebase argv so the integrated utility sees its command as argv[0].
        return ldid::iosinject::run(argc - 1, argv + 1);
    }
    if (argc < 2) {
        print_usage();
        return 1;
    }
    ldid::SignOptions options;
    ldid::VerificationOptions default_verification_options;
    std::string selected_profile;
    std::filesystem::path explicit_config;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--profile" && i + 1 < argc) selected_profile = argv[++i];
        else if (arg == "--config" && i + 1 < argc) explicit_config = argv[++i];
    }
    load_ldid_config(options, default_verification_options, selected_profile, explicit_config);
    bool do_sign = false;
    bool do_unsign = false;
    bool do_verify = false;
    bool show_entitlements = false;
    bool show_requirements = false;
    bool show_info = false;
    bool show_cdhash = false;
    bool show_version = false;
    bool reset_cryptid = false;
    ldid::VerificationOptions verification_options = default_verification_options;
    bool verify_json = false;
    bool verify_quiet = false;
    bool strip_deep = false;
    std::vector<std::string> inputs;
    try {
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--profile" || arg == "--config") {
            if (i + 1 >= argc) throw std::invalid_argument(arg + " requires a value");
            ++i;
        } else if (arg == "-v" || arg == "--version") {
            show_version = true;
        } else if (arg == "--true-sign") {
            options.true_sign = true;
        } else if (arg == "--deep") {
            options.deep = true;
            do_sign = true;
        } else if (arg == "--super-deep") {
            options.super_deep = true;
            do_sign = true;
        } else if (arg == "--verify") {
            do_verify = true;
        } else if (arg == "--verify-chain") {
            do_verify = true;
            verification_options.certificate_chain.enabled = true;
        } else if (arg == "--no-verify-chain") {
            do_verify = true;
            verification_options.certificate_chain.enabled = false;
            verification_options.certificate_chain.require_root = false;
        } else if (arg == "--verify-chain-root") {
            do_verify = true;
            verification_options.certificate_chain.enabled = true;
            verification_options.certificate_chain.require_root = true;
        } else if (arg == "--ca-file") {
            if (i + 1 >= argc) throw std::invalid_argument("--ca-file requires a path");
            verification_options.certificate_chain.ca_file = argv[++i];
            verification_options.certificate_chain.enabled = true;
            do_verify = true;
        } else if (arg == "--ca-path") {
            if (i + 1 >= argc) throw std::invalid_argument("--ca-path requires a directory");
            verification_options.certificate_chain.ca_path = argv[++i];
            verification_options.certificate_chain.enabled = true;
            do_verify = true;
        } else if (arg == "--verify-time") {
            if (i + 1 >= argc) throw std::invalid_argument("--verify-time requires Unix timestamp");
            verification_options.certificate_chain.verification_time = static_cast<int64_t>(parse_cfg_uint(argv[++i], "verification time"));
            verification_options.certificate_chain.enabled = true;
            do_verify = true;
        } else if (arg == "--json") {
            verify_json = true;
        } else if (arg == "--quiet") {
            verify_quiet = true;
        } else if (arg == "--merge-deep") {
            options.merge_entitlements_deep = true;
        } else if (arg == "--strip-codesig") {
            do_unsign = true;
            strip_deep = true;
        } else if (arg == "-arch") {
            if (i + 1 < argc) {
                options.arch = argv[++i];
            }
        } else if (arg.rfind("--arch=", 0) == 0) {
            options.arch = arg.substr(7);
        } else if (arg.rfind("-S", 0) == 0) {
            do_sign = true;
            auto value = optional_option_value(arg, "-S", argc, argv, i);
            if (!value.empty()) options.entitlements_path = value;
            else options.preserve_entitlements = true;
        } else if (arg == "-s") {
            do_sign = true;
            options.preserve_entitlements = true;
        } else if (arg == "-r") {
            do_unsign = true;
        } else if (arg == "-e") {
            show_entitlements = true;
        } else if (arg == "-q") {
            show_requirements = true;
        } else if (arg == "-D") {
            show_requirements = true;
        } else if (arg == "--reset-cryptid") {
            reset_cryptid = true;
        } else if (arg == "-d") {
            show_info = true;
        } else if (arg == "-h") {
            show_cdhash = true;
        } else if (arg == "-M") {
            do_sign = true;
            options.merge_only = true;
            options.preserve_entitlements = true;
        } else if (arg == "--cert" || arg == "--certificate") {
            options.certificate_path = required_option_value(arg, arg, argc, argv, i);
            do_sign = true;
        } else if (arg.rfind("--cert=", 0) == 0) {
            options.certificate_path = arg.substr(7);
            do_sign = true;
        } else if (arg == "--key" || arg == "--private-key") {
            options.private_key_path = required_option_value(arg, arg, argc, argv, i);
            do_sign = true;
        } else if (arg.rfind("--key=", 0) == 0) {
            options.private_key_path = arg.substr(6);
            do_sign = true;
        } else if (arg.rfind("-K", 0) == 0) {
            options.p12_path = required_option_value(arg, "-K", argc, argv, i);
            do_sign = true;
        } else if (arg.rfind("-U", 0) == 0) {
            options.key_password = required_option_value(arg, "-U", argc, argv, i);
        } else if (arg.rfind("-I", 0) == 0) {
            options.identifier = required_option_value(arg, "-I", argc, argv, i);
        } else if (arg.rfind("-t", 0) == 0) {
            options.team_id = required_option_value(arg, "-t", argc, argv, i);
        } else if (arg.rfind("-Q", 0) == 0) {
            options.requirements_path = required_option_value(arg, "-Q", argc, argv, i);
        } else if (arg.rfind("-N", 0) == 0) {
            options.overall_requirements_path = required_option_value(arg, "-N", argc, argv, i);
        } else if (arg.rfind("-C", 0) == 0) {
            std::string value;
            if (arg.size() > 2) {
                value = arg.substr(2);
            } else if (i + 1 < argc) {
                std::string candidate = argv[i + 1];
                std::string lowered = candidate;
                std::transform(lowered.begin(), lowered.end(), lowered.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
                bool recognized = false;
                for (const auto& token : {std::string("host"), std::string("adhoc"), std::string("hard"), std::string("kill"), std::string("expires"), std::string("check-expiration"), std::string("restrict"), std::string("enforcement"), std::string("library-validation"), std::string("runtime"), std::string("linker-signed"), std::string("no-host"), std::string("no-adhoc"), std::string("no-hard"), std::string("no-kill"), std::string("no-expires"), std::string("no-check-expiration"), std::string("no-restrict"), std::string("no-enforcement"), std::string("no-library-validation"), std::string("no-runtime"), std::string("no-linker-signed")}) {
                    if (lowered == token) { recognized = true; break; }
                }
                if (recognized) { value = candidate; ++i; }
            }
            if (value.empty()) { print_usage(); return 1; }
            apply_cd_flags(value, options.cd_flags);
        } else if (arg.rfind("-H", 0) == 0) {
            auto value = optional_option_value(arg, "-H", argc, argv, i);
            options.hash_type = parse_hash_type(value);
        } else if (arg.rfind("-A", 0) == 0) {
            options.arch = required_option_value(arg, "-A", argc, argv, i);
        } else if (arg.rfind("-P", 0) == 0) {
            auto value = optional_option_value(arg, "-P", argc, argv, i);
            options.platform = parse_platform(value);

        } else if (arg == "-a") {
            do_sign = true;
            options.adhoc = true;
        } else if (arg == "--force") {
            options.force = true;
        } else if (arg == "--min-os") {
            options.min_os_version = parse_version_value(required_option_value(arg, "--min-os", argc, argv, i));
        } else if (arg.rfind("--min-os=", 0) == 0) {
            options.min_os_version = parse_version_value(arg.substr(9));
        } else if (arg == "--timestamp") {
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-required") {
            options.timestamp_enabled = true;
            options.timestamp_required = true;
        } else if (arg == "--timestamp-ca-file") {
            options.timestamp_ca_file = required_option_value(arg, "--timestamp-ca-file", argc, argv, i);
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-ca-path") {
            options.timestamp_ca_path = required_option_value(arg, "--timestamp-ca-path", argc, argv, i);
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-require-root") {
            options.timestamp_enabled = true;
            options.timestamp_required = true;
            options.timestamp_require_root = true;
        } else if (arg == "--jobs") {
            const auto count = parse_cfg_uint(required_option_value(arg, "--jobs", argc, argv, i), "jobs");
            if (count > 64) throw std::invalid_argument("--jobs is limited to 64");
            options.jobs = static_cast<uint32_t>(count);
        } else if (arg == "--timestamp-policy") {
            options.timestamp_policy = required_option_value(arg, "--timestamp-policy", argc, argv, i);
        } else if (arg.rfind("--timestamp-policy=", 0) == 0) {
            options.timestamp_policy = arg.substr(19);
        } else if (arg == "--no-timestamp") {
            options.timestamp_enabled = false;
        } else if (arg == "--no-signing-time") {
            options.emit_signing_time = false;
        } else if (arg.rfind("--timestamp-url=", 0) == 0) {
            options.timestamp_url = arg.substr(15);
            options.timestamp_enabled = true;
        } else if (arg == "--timestamp-url") {
            options.timestamp_url = required_option_value(arg, "--timestamp-url", argc, argv, i);
            options.timestamp_enabled = true;
        } else if (arg.rfind("-T", 0) == 0) {
            std::string value;
            if (arg.size() > 2) {
                value = arg.substr(2);
            } else if (i + 1 < argc) {
                std::string candidate = argv[i + 1];
                if (candidate.find("://") != std::string::npos) {
                    value = candidate;
                    ++i;
                }
            }
            if (!value.empty() && value.find("://") != std::string::npos) options.timestamp_url = value;
            options.timestamp_enabled = true;
        } else if (arg == "-w") {
            options.write_copy = true;
        } else if (arg == "-O") {
            options.output_stdout = true;
        } else if (arg == "-n") {
            options.no_overwrite = true;
        } else if (!arg.empty() && arg[0] == '-') {
            print_usage();
            return 1;
        } else {
            inputs.push_back(arg);
        }
    }
    if (show_version) {
        std::cout << "ldid enhanced two-file edition" << std::endl;
        return 0;
    }
    if (inputs.empty()) {
        print_usage();
        return 1;
    }
    if ((!options.certificate_path.empty() || !options.private_key_path.empty()) &&
        (options.certificate_path.empty() || options.private_key_path.empty())) {
        throw std::invalid_argument("--cert and --key must be supplied together (or use -K with a PKCS#12 file)");
    }
    if (!options.p12_path.empty() && (!options.certificate_path.empty() || !options.private_key_path.empty())) {
        throw std::invalid_argument("choose either -K PKCS#12 or --cert/--key PEM inputs, not both");
    }
    if ((options.cd_flags & static_cast<uint32_t>(ldid::CodeDirectoryFlag::ADHOC)) != 0) {
        options.adhoc = true;
    }
    int exit_code = 0;
    for (auto& input : inputs) {
        if (reset_cryptid) {
            ldid::Signer::reset_cryptid(input);
            continue;
        }
        if (do_unsign) {
            if (strip_deep) ldid::Signer::unsign_deep(input);
            else ldid::Signer::unsign(input);
            continue;
        }
        if (do_verify) {
            auto result = ldid::Verifier::verify(input, verification_options);
            if (verify_json) {
                std::cout << "{\"path\":\"" << json_escape(input) << "\",\"valid\":" << (result.ok ? "true" : "false")
                          << ",\"certificateChainPolicyEnabled\":" << (verification_options.certificate_chain.enabled ? "true" : "false")
                          << ",\"requireRoot\":" << (verification_options.certificate_chain.require_root ? "true" : "false") << ",\"errors\":[";
                for (size_t ei = 0; ei < result.errors.size(); ++ei) { if (ei) std::cout << ','; std::cout << "\"" << json_escape(result.errors[ei]) << "\""; }
                std::cout << "]}\n";
            } else if (!verify_quiet || !result.ok) {
                std::cout << input << ": " << (result.ok ? "valid" : "invalid")
                          << (verification_options.certificate_chain.enabled
                                  ? " (certificate-chain policy enabled; CMS signers checked, ad-hoc/no-CMS is N/A)"
                                  : " (certificate chain not checked; default)") << std::endl;
                for (auto& error : result.errors) std::cout << error << std::endl;
            }
            if (!result.ok) exit_code = 1;
            continue;
        }
        if (do_sign) {
            ldid::Signer::sign(input, options);
            continue;
        }
        if (show_entitlements) {
            ldid::Display::display_entitlements(input);
        }
        if (show_requirements) {
            ldid::Display::display_requirements(input);
        }
        if (show_cdhash) {
            ldid::Display::display_cdhash(input);
        }
        if (show_info) {
            ldid::Display::display_info(input);
        }
        if (!show_entitlements && !show_requirements && !show_cdhash && !show_info) {
            ldid::Display::display_info(input);
        }
    }
    return exit_code;
    } catch (const std::exception& error) {
        std::cerr << "ldid: " << error.what() << std::endl;
        return 1;
    } catch (...) {
        std::cerr << "ldid: unknown error" << std::endl;
        return 1;
    }
}

namespace ldid {
namespace iosinject {
namespace {
#if defined(__APPLE__)

#else
#define MH_MAGIC 0xfeedfaceu
#define MH_CIGAM 0xcefaedfeu
#define MH_MAGIC_64 0xfeedfacfu
#define MH_CIGAM_64 0xcffaedfeu
#define FAT_MAGIC 0xcafebabeu
#define FAT_CIGAM 0xbebafecau
#endif

#define VERSION "2.0"
#define PATH_MAX_LOCAL 4096
#define MAX_ITEMS 4096

typedef struct { char **v; size_t n,cap; } StrVec;
typedef struct { const char *entitlements; const char *output; bool inplace; bool overwrite; bool dry_run; bool strip_codesig; bool weak; bool sign; bool verify; bool force; bool preserve; bool verbose; bool deep; bool super_deep; } Options;


static void die(const char *s) { fprintf(stderr,"iosinject: %s: %s\n",s,strerror(errno)); exit(1); }
static void die_msg(const char *s) { fprintf(stderr,"iosinject: %s\n",s); exit(1); }
static void *xmalloc(size_t n) { void *p=malloc(n?n:1); if(!p) die("out of memory"); return p; }
static char *xstrdup(const char *s) { char *p=strdup(s); if(!p) die("out of memory"); return p; }
static void vec_push(StrVec *a,const char *s) { if(a->n==a->cap){a->cap=a->cap? a->cap*2:16;a->v=static_cast<char**>(realloc(a->v,a->cap*sizeof(*a->v)));if(!a->v)die("out of memory");}a->v[a->n++]=xstrdup(s); }
static bool ends(const char *s,const char *x){size_t a=strlen(s),b=strlen(x);return a>=b&&!strcmp(s+a-b,x);}
static bool dirp(const char *p){struct stat st;return stat(p,&st)==0&&S_ISDIR(st.st_mode);}
static bool regularp(const char *p){struct stat st;return stat(p,&st)==0&&S_ISREG(st.st_mode);}
static char *join(const char *a,const char *b){char *p=static_cast<char*>(xmalloc(strlen(a)+strlen(b)+2));snprintf(p, strlen(a) + strlen(b) + 2, "%s/%s", a, b);return p;}
static char *base_dup(const char *p){const char *q=strrchr(p,'/');return xstrdup(q?q+1:p);}
static bool safe_rel(const char *p){if(!p||p[0]=='/')return false;const char *s=p;while(*s){while(*s=='/')s++;const char *e=strchr(s,'/');size_t n=e?(size_t)(e-s):strlen(s);if(n==2&&!strncmp(s,"..",2))return false;s=e?e+1:s+strlen(s);}return true;}

static bool magic_ok(uint32_t m){return m==MH_MAGIC||m==MH_CIGAM||m==MH_MAGIC_64||m==MH_CIGAM_64;}
static bool fat_magic(uint32_t m){return m==FAT_MAGIC||m==FAT_CIGAM;}

static bool mach_file(const char *p){FILE *f=fopen(p,"rb");if(!f)return false;uint32_t m=0;bool ok=fread(&m,4,1,f)==1&&(magic_ok(m)||fat_magic(m));fclose(f);return ok;}


static int copy_file(const char *src,const char *dst){int a=open(src,O_RDONLY);if(a<0)return -1;int b=open(dst,O_WRONLY|O_CREAT|O_TRUNC,0755);if(b<0){close(a);return -1;}char buf[65536];ssize_t n;int r=0;while((n=read(a,buf,sizeof buf))>0){char *q=buf;ssize_t z=n;while(z){ssize_t w=write(b,q,z);if(w<=0){r=-1;break;}q+=w;z-=w;}}if(n<0)r=-1;close(a);close(b);return r;}
static int mkdir_p(const char *p){char tmp[PATH_MAX_LOCAL];if(strlen(p)>=sizeof tmp)return -1;strcpy(tmp,p);for(char *q=tmp+1;*q;q++){if(*q=='/'){*q=0;if(mkdir(tmp,0755)&&errno!=EEXIST)return -1;*q='/';}}return mkdir(tmp,0755)&&errno!=EEXIST?-1:0;}
static int copy_tree(const char *src,const char *dst){struct stat st;if(lstat(src,&st)<0)return -1;if(S_ISLNK(st.st_mode)){char buf[PATH_MAX_LOCAL];ssize_t n=readlink(src,buf,sizeof(buf)-1);if(n<0)return -1;buf[n]=0;unlink(dst);return symlink(buf,dst);}if(S_ISREG(st.st_mode)){char *par=base_dup(dst);free(par);char tmp[PATH_MAX_LOCAL];if(strlen(dst)>=sizeof tmp)return -1;strcpy(tmp,dst);char *q=strrchr(tmp,'/');if(q){*q=0;if(mkdir_p(tmp)<0)return -1;}return copy_file(src,dst);}if(!S_ISDIR(st.st_mode))return 0;if(mkdir_p(dst)<0)return -1;DIR *d=opendir(src);if(!d)return -1;struct dirent *e;while((e=readdir(d))){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;char *a=join(src,e->d_name),*b=join(dst,e->d_name);if(copy_tree(a,b)<0){free(a);free(b);closedir(d);return -1;}free(a);free(b);}closedir(d);return 0;}

static char *find_macho(const char *root){if(mach_file(root))return xstrdup(root);DIR *d=opendir(root);if(!d)return NULL;struct dirent *e;char *best=NULL;while((e=readdir(d))){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;char *p=join(root,e->d_name);if(dirp(p)){char *q=find_macho(p);if(q&&!best)best=q;else free(q);}else if(regularp(p)&&mach_file(p)&&!best)best=xstrdup(p);free(p);}closedir(d);return best;}

static char *temp_dir(void){char t[]="/tmp/iosinject.XXXXXX";char *p=xstrdup(t);if(!mkdtemp(p))die("mkdtemp failed");return p;}
static bool is_payload(const char *n){return ends(n,".dylib")||ends(n,".framework")||ends(n,".xcframework")||ends(n,".deb")||ends(n,".a");}
static char *archive_extract(const char *deb){struct archive *a=archive_read_new();archive_read_support_filter_all(a);archive_read_support_format_all(a);if(archive_read_open_filename(a,deb,65536)!=ARCHIVE_OK){archive_read_free(a);return NULL;}char *root=temp_dir();struct archive_entry *e;while(archive_read_next_header(a,&e)==ARCHIVE_OK){const char *n=archive_entry_pathname(e);if(!safe_rel(n)){archive_read_free(a);die_msg("unsafe path in deb");}if(strncmp(n,"data/",5)==0)n+=5;else if(strstr(n,"/data/")){n=strstr(n,"/data/")+6;}else continue;if(!*n)continue;char *dst=join(root,n);char *par=xstrdup(dst);char *slash=strrchr(par,'/');if(slash){*slash=0;mkdir_p(par);}free(par);archive_entry_set_pathname(e,dst);if(archive_read_extract(a,e,ARCHIVE_EXTRACT_TIME|ARCHIVE_EXTRACT_PERM|ARCHIVE_EXTRACT_ACL|ARCHIVE_EXTRACT_FFLAGS)!=ARCHIVE_OK){free(dst);archive_read_free(a);return NULL;}free(dst);}archive_read_free(a);return root;}

static int install_payload(const char *app,const char *payload,StrVec *installed){
    struct stat st;
    if(stat(payload,&st)<0)return -1;
    if(ends(payload,".deb")){
        char *root=archive_extract(payload);
        if(!root)return -1;
        DIR *d=opendir(root);
        if(!d){free(root);return -1;}
        struct dirent *e;
        int result=0;
        while((e=readdir(d))){
            if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;
            char *p=join(root,e->d_name);
            char *m=dirp(p)?find_macho(p):(mach_file(p)?xstrdup(p):NULL);
            if(m){
                char *bn=base_dup(m);
                char *fw=join(app,"Frameworks");
                if(mkdir_p(fw)<0){result=-1;free(fw);free(bn);free(m);free(p);break;}
                char *dst=join(fw,bn);
                if(copy_tree(p,dst)<0){result=-1;free(dst);free(fw);free(bn);free(m);free(p);break;}
                char *target=find_macho(dst);
                if(target)vec_push(installed,target),free(target);else result=-1;
                free(dst);free(fw);free(bn);free(m);
            }
            free(p);
        }
        closedir(d);free(root);return result;
    }
    char *source=NULL;
    if(ends(payload,".xcframework"))source=find_macho(payload);else source=xstrdup(payload);
    if(!source)return -1;
    if(ends(source,".framework")){
        char *m=find_macho(source);
        if(!m){free(source);return -1;}
        char *name=base_dup(source);
        char *fwroot=join(app,"Frameworks");
        char *dst=join(fwroot,name);
        int r=mkdir_p(fwroot)<0||copy_tree(source,dst)<0?-1:0;
        if(r==0){char *target=find_macho(dst);if(target)vec_push(installed,target),free(target);else r=-1;}
        free(m);free(name);free(fwroot);free(dst);free(source);return r;
    }
    if(ends(source,".a")){
        fprintf(stderr, "iosinject: static .a archives cannot be injected as a runtime dylib; build a device .dylib/framework first\n");
        free(source);
        return -1;
    }
    char *fw=join(app,"Frameworks");char *name=base_dup(source);char *dst=join(fw,name);
    int r=mkdir_p(fw)<0||copy_file(source,dst)<0?-1:0;
    if(r==0)vec_push(installed,dst);else free(dst);
    free(fw);free(name);free(source);return r;
}

static bool thin_has_dylib_command(const std::vector<uint8_t>& bytes,
                                   const std::string& loadpath,
                                   bool weak) {
    auto header = ldid::macho::parse_header(bytes, 0);
    if (!header.valid) throw std::runtime_error("invalid Mach-O header");
    auto commands = ldid::macho::enumerate_load_commands(bytes, header, 0);
    if (commands.size() != header.ncmds) throw std::runtime_error("truncated Mach-O load-command table");
    const uint32_t wanted = weak ? 0x80000018U : 0x0000000CU; // LC_LOAD_WEAK_DYLIB / LC_LOAD_DYLIB
    for (const auto& command : commands) {
        if (command.cmd != wanted || command.cmdsize < 25) continue;
        const uint32_t name_offset = ldid::read_u32_file(bytes.data() + command.offset + 8, header.big);
        if (name_offset < 24 || name_offset >= command.cmdsize) continue;
        const char* name = reinterpret_cast<const char*>(bytes.data() + command.offset + name_offset);
        const size_t remaining = command.cmdsize - name_offset;
        const void* nul = std::memchr(name, '\0', remaining);
        if (!nul) continue;
        const size_t length = static_cast<const char*>(nul) - name;
        if (length == loadpath.size() && std::memcmp(name, loadpath.data(), length) == 0) return true;
    }
    return false;
}

static size_t first_file_data_offset(const std::vector<uint8_t>& bytes,
                                     const ldid::macho::MachHeaderFields& header,
                                     const std::vector<ldid::macho::LoadCommandRef>& commands) {
    size_t first = bytes.size();
    auto consider = [&](uint64_t offset) {
        if (offset != 0 && offset < first) first = static_cast<size_t>(offset);
    };
    for (const auto& command : commands) {
        if (command.cmd == ldid::macho::kLC_SEGMENT) {
            if (command.cmdsize < 56) throw std::runtime_error("truncated LC_SEGMENT command");
            const uint32_t fileoff = ldid::read_u32_file(bytes.data() + command.offset + 32, header.big);
            consider(fileoff);
            const uint32_t nsects = ldid::read_u32_file(bytes.data() + command.offset + 48, header.big);
            constexpr size_t section_size = 68;
            if (nsects > (command.cmdsize - 56) / section_size) throw std::runtime_error("invalid LC_SEGMENT section count");
            for (uint32_t i = 0; i < nsects; ++i) {
                const size_t section = command.offset + 56 + static_cast<size_t>(i) * section_size;
                consider(ldid::read_u32_file(bytes.data() + section + 40, header.big)); // section.offset
                consider(ldid::read_u32_file(bytes.data() + section + 48, header.big)); // section.reloff
            }
        } else if (command.cmd == ldid::macho::kLC_SEGMENT_64) {
            if (command.cmdsize < 72) throw std::runtime_error("truncated LC_SEGMENT_64 command");
            const uint64_t fileoff = ldid::read_u64_file(bytes.data() + command.offset + 40, header.big);
            consider(fileoff);
            const uint32_t nsects = ldid::read_u32_file(bytes.data() + command.offset + 64, header.big);
            constexpr size_t section_size = 80;
            if (nsects > (command.cmdsize - 72) / section_size) throw std::runtime_error("invalid LC_SEGMENT_64 section count");
            for (uint32_t i = 0; i < nsects; ++i) {
                const size_t section = command.offset + 72 + static_cast<size_t>(i) * section_size;
                consider(ldid::read_u32_file(bytes.data() + section + 48, header.big)); // section_64.offset
                consider(ldid::read_u32_file(bytes.data() + section + 56, header.big)); // section_64.reloff
            }
        }
    }
    return first;
}

static std::vector<uint8_t> inject_dylib_command_thin(const std::vector<uint8_t>& input,
                                                       const std::string& loadpath,
                                                       bool weak) {
    auto header = ldid::macho::parse_header(input, 0);
    if (!header.valid) throw std::runtime_error("payload target is not a thin Mach-O slice");
    auto commands = ldid::macho::enumerate_load_commands(input, header, 0);
    if (commands.size() != header.ncmds) throw std::runtime_error("truncated Mach-O load-command table");
    if (thin_has_dylib_command(input, loadpath, weak)) return input;

    const uint32_t wanted_command = weak ? 0x80000018U : 0x0000000CU;
    // If the same path already exists with the opposite weak/strong behavior,
    // update that command in place instead of creating a duplicate load.
    for (const auto& command : commands) {
        if ((command.cmd != 0x0000000CU && command.cmd != 0x80000018U) || command.cmdsize < 25) continue;
        const uint32_t name_offset = ldid::read_u32_file(input.data() + command.offset + 8, header.big);
        if (name_offset < 24 || name_offset >= command.cmdsize) continue;
        const char* name = reinterpret_cast<const char*>(input.data() + command.offset + name_offset);
        const size_t remaining = command.cmdsize - name_offset;
        const void* nul = std::memchr(name, '\0', remaining);
        if (!nul) continue;
        const size_t length = static_cast<const char*>(nul) - name;
        if (length == loadpath.size() && std::memcmp(name, loadpath.data(), length) == 0) {
            std::vector<uint8_t> output = input;
            ldid::write_u32_file(output.data() + command.offset, wanted_command, header.big);
            return output;
        }
    }

    if (loadpath.empty() || loadpath.size() > static_cast<size_t>(UINT32_MAX) - 25U) {
        throw std::runtime_error("dylib load command is too large");
    }
    const uint64_t command_bytes = 24ULL + static_cast<uint64_t>(loadpath.size()) + 1ULL;
    const size_t alignment = header.is_64 ? 8U : 4U;
    const uint64_t aligned_size = ldid::align_up64(command_bytes, alignment);
    if (aligned_size > UINT32_MAX || header.ncmds == UINT32_MAX ||
        static_cast<uint64_t>(header.sizeofcmds) + aligned_size > UINT32_MAX) {
        throw std::runtime_error("dylib load command is too large");
    }
    const size_t used = header.header_size + static_cast<size_t>(header.sizeofcmds);
    if (used < header.header_size || used > input.size()) throw std::runtime_error("invalid Mach-O sizeofcmds");
    const size_t end = first_file_data_offset(input, header, commands);
    const size_t cmdsize = static_cast<size_t>(aligned_size);
    if (used > end || cmdsize > end - used || cmdsize > input.size() - used ||
        !ldid::macho::all_zero(input, used, cmdsize)) {
        throw std::runtime_error("not enough zero-filled Mach-O header padding for dylib load command; refusing unsafe file-offset shifting");
    }

    std::vector<uint8_t> output = input;
    const uint32_t command = weak ? 0x80000018U : 0x0000000CU;
    ldid::write_u32_file(output.data() + used, command, header.big);
    ldid::write_u32_file(output.data() + used + 4, static_cast<uint32_t>(cmdsize), header.big);
    ldid::write_u32_file(output.data() + used + 8, 24U, header.big); // dylib.name.offset
    ldid::write_u32_file(output.data() + used + 12, 0U, header.big); // timestamp
    ldid::write_u32_file(output.data() + used + 16, 0U, header.big); // current_version
    ldid::write_u32_file(output.data() + used + 20, 0U, header.big); // compatibility_version
    std::memcpy(output.data() + used + 24, loadpath.c_str(), loadpath.size() + 1);
    ldid::write_u32_file(output.data() + 16, header.ncmds + 1, header.big);
    ldid::write_u32_file(output.data() + 20, header.sizeofcmds + static_cast<uint32_t>(cmdsize), header.big);
    return output;
}

static bool write_binary_atomic(const char* path, const std::vector<uint8_t>& bytes) {
    struct stat st{};
    if (::stat(path, &st) != 0) return false;
    std::string temporary = std::string(path) + ".ldid-inject.tmp." + std::to_string(static_cast<long long>(::getpid()));
    std::error_code ec;
    std::filesystem::remove(temporary, ec);
    if (!ldid::write_file(temporary, bytes)) {
        std::filesystem::remove(temporary, ec);
        return false;
    }
    if (::chmod(temporary.c_str(), st.st_mode & 07777) != 0) {
        std::filesystem::remove(temporary, ec);
        return false;
    }
    if (::rename(temporary.c_str(), path) != 0) {
        std::filesystem::remove(temporary, ec);
        return false;
    }
    return true;
}

static int patch_load(const char *binary, const char *loadpath, const Options *o) {
    try {
        const std::filesystem::path binary_path(binary);
        const std::string dylib_path(loadpath);
        auto original = ldid::read_file(binary_path);
        if (original.empty() || !ldid::MachOParser::is_macho(original)) {
            throw std::runtime_error("target is not a valid Mach-O file");
        }
        const uint32_t magic = ldid::load_be32(original.data());
        const bool fat = ldid::macho::is_fat_magic(magic);

        // Idempotence fast path: do not discard a valid existing signature when
        // every architecture already has the exact requested load command.
        bool all_present = true;
        if (fat) {
            auto current_slices = ldid::macho::parse_slices_impl(original);
            if (current_slices.empty()) throw std::runtime_error("invalid universal Mach-O");
            for (const auto& slice : current_slices) {
                if (slice.offset > original.size() || slice.size > original.size() - slice.offset)
                    throw std::runtime_error("universal Mach-O slice is out of bounds");
                std::vector<uint8_t> part(original.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                          original.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
                if (!thin_has_dylib_command(part, dylib_path, o->weak)) { all_present = false; break; }
            }
        } else {
            all_present = thin_has_dylib_command(original, dylib_path, o->weak);
        }
        if (all_present) {
            if (o->verbose) fprintf(stderr, "iosinject: load command already present; leaving file unchanged: %s\n", loadpath);
            return 0;
        }

        // Injection invalidates the old signature. Strip it with ldid's own
        // parser before modifying load commands; no insert_dylib process runs.
        auto unsigned_image = ldid::MachOParser::strip_signature(original);
        std::vector<uint8_t> patched;
        if (fat) {
            auto slices = ldid::macho::parse_slices_impl(unsigned_image);
            if (slices.empty()) throw std::runtime_error("invalid universal Mach-O after signature removal");
            std::vector<std::vector<uint8_t>> changed;
            changed.reserve(slices.size());
            for (const auto& slice : slices) {
                if (slice.offset > unsigned_image.size() || slice.size > unsigned_image.size() - slice.offset)
                    throw std::runtime_error("universal Mach-O slice is out of bounds");
                std::vector<uint8_t> part(unsigned_image.begin() + static_cast<std::ptrdiff_t>(slice.offset),
                                          unsigned_image.begin() + static_cast<std::ptrdiff_t>(slice.offset + slice.size));
                changed.push_back(inject_dylib_command_thin(part, dylib_path, o->weak));
            }
            const bool use64 = magic == ldid::macho::kFAT_MAGIC_64 || magic == ldid::macho::kFAT_CIGAM_64;
            const bool cigam = magic == ldid::macho::kFAT_CIGAM || magic == ldid::macho::kFAT_CIGAM_64;
            patched = ldid::macho::rebuild_fat_with_format_impl(changed, use64, cigam, slices);
        } else {
            patched = inject_dylib_command_thin(unsigned_image, dylib_path, o->weak);
        }
        if (patched == original) return 0;
        if (!write_binary_atomic(binary, patched)) throw std::runtime_error(std::string("failed to atomically replace target: ") + std::strerror(errno));
        if (o->verbose) fprintf(stderr, "iosinject: injected load command in-process: %s -> %s\n", binary, loadpath);
        return 0;
    } catch (const std::exception& error) {
        fprintf(stderr, "iosinject: in-process Mach-O injection failed for %s: %s\n", binary, error.what());
        return -1;
    } catch (...) {
        fprintf(stderr, "iosinject: in-process Mach-O injection failed for %s\n", binary);
        return -1;
    }
}
static char *framework_load_path(const char *app,const char *installed){(void)app;const char *p=strstr(installed,"/Frameworks/");if(!p)return NULL;p+=strlen("/Frameworks/");char *rel=xstrdup(p);if(ends(rel,".framework")){char *m=find_macho(installed);if(!m){free(rel);return NULL;}char *b=base_dup(m);char *name=base_dup(installed);char *r=static_cast<char*>(xmalloc(strlen("@rpath/")+strlen(name)+1+strlen(b)+1));snprintf(r, strlen("@rpath/") + strlen(name) + strlen(b) + 2, "@rpath/%s/%s", name, b);free(b);free(name);free(rel);free(m);return r;}char *r=static_cast<char*>(xmalloc(strlen("@rpath/")+strlen(rel)+1));snprintf(r, strlen("@rpath/") + strlen(rel) + 1, "@rpath/%s", rel);free(rel);return r;}

static int strip_signature(const char *p) {
    try {
        ldid::Signer::unsign(std::filesystem::path(p));
        return 0;
    } catch (const std::exception& error) {
        fprintf(stderr, "iosinject: failed to strip signature from %s: %s\n", p, error.what());
        return -1;
    } catch (...) {
        fprintf(stderr, "iosinject: failed to strip signature from %s\n", p);
        return -1;
    }
}

static int sign_graph(const char *app,const char *mainbin,const Options *o) {
    (void)mainbin;
    if (o->dry_run) {
        printf("sign bundle %s\n", app);
        return 0;
    }
    try {
        ldid::SignOptions sign_options;
        sign_options.input_path = app;
        sign_options.output_path = app;
        sign_options.adhoc = true;
        sign_options.force = o->force;
        sign_options.preserve_entitlements = o->preserve;
        sign_options.deep = o->deep;
        sign_options.super_deep = o->super_deep;
        if (o->entitlements != nullptr) {
            sign_options.entitlements_path = o->entitlements;
            sign_options.preserve_entitlements = false;
        }
        // This calls ldid's own signer directly: nested code, CodeResources,
        // and the top-level executable are signed in dependency order.
        ldid::Signer::sign_bundle(std::filesystem::path(app), sign_options);
        if (o->verbose) fprintf(stderr, "iosinject: bundle signed in-process: %s\n", app);
        return 0;
    } catch (const std::exception& error) {
        fprintf(stderr, "iosinject: in-process bundle signing failed: %s\n", error.what());
        return -1;
    } catch (...) {
        fprintf(stderr, "iosinject: in-process bundle signing failed\n");
        return -1;
    }
}

static char *find_main(const char *app){DIR *d=opendir(app);if(!d)return NULL;struct dirent *e;char *m=NULL;while((e=readdir(d))){if(!strcmp(e->d_name,".")||!strcmp(e->d_name,".."))continue;if(ends(e->d_name,".app")||ends(e->d_name,".framework")||ends(e->d_name,".appex"))continue;char *p=join(app,e->d_name);if(regularp(p)&&mach_file(p)){m=p;break;}free(p);}closedir(d);return m;}
static void usage(const char *p){printf("ldid --iosinject (iosinject %s)\n",VERSION);printf("Usage: %s [options] App.app payload...\n",p);printf("  --entitlements PATH\n  --output PATH\n  --inplace\n  --overwrite\n  --sign\n  --verify\n  --strip-codesig\n  --weak\n  --force\n  --preserve-metadata\n  --deep\n  --super-deep\n  --dry-run\n  --verbose\n");exit(0);}

} // namespace (iosinject helpers)

int run(int argc, char **argv) {
    Options o{};
    o.inplace = false;
    o.overwrite = false;
    o.dry_run = false;
    o.strip_codesig = false;
    o.weak = false;
    o.sign = false;
    o.verify = false;
    o.force = false;
    o.preserve = false;
    o.verbose = false;
    o.deep = true;
    o.super_deep = false;
    static struct option lo[] = {
        {"entitlements", required_argument, 0, 'e'}, {"output", required_argument, 0, 'o'},
        {"inplace", no_argument, 0, 'i'}, {"overwrite", no_argument, 0, 'w'},
        {"sign", no_argument, 0, 's'}, {"verify", no_argument, 0, 'v'},
        {"strip-codesig", no_argument, 0, 'c'}, {"weak", no_argument, 0, 'W'},
        {"force", no_argument, 0, 'f'}, {"preserve-metadata", no_argument, 0, 'p'},
        {"deep", no_argument, 0, 'd'}, {"super-deep", no_argument, 0, 'D'},
        {"dry-run", no_argument, 0, 'n'}, {"verbose", no_argument, 0, 'V'},
        {"help", no_argument, 0, 'h'}, {0, 0, 0, 0}
    };
    int c;
    while ((c = getopt_long(argc, argv, "e:o:iwsvcWfpdDnVh", lo, nullptr)) != -1) {
        switch (c) {
            case 'e': o.entitlements = optarg; break;
            case 'o': o.output = optarg; break;
            case 'i': o.inplace = true; break;
            case 'w': o.overwrite = true; break;
            case 's': o.sign = true; break;
            case 'v': o.verify = true; break;
            case 'c': o.strip_codesig = true; break;
            case 'W': o.weak = true; break;
            case 'f': o.force = true; break;
            case 'p': o.preserve = true; break;
            case 'd': o.deep = true; break;
            case 'D': o.deep = true; o.super_deep = true; break;
            case 'n': o.dry_run = true; break;
            case 'V': o.verbose = true; break;
            case 'h': usage(argv[0]); break;
            default: usage(argv[0]);
        }
    }
    if (argc - optind < 2) usage(argv[0]);
    if (!o.sign && !o.dry_run) die_msg("injection changes Mach-O signatures; pass --sign so the staged bundle is re-signed before commit");

    const std::filesystem::path input_app = std::filesystem::absolute(argv[optind++]).lexically_normal();
    if (!std::filesystem::is_directory(input_app) || input_app.extension() != ".app")
        die_msg("input must be an .app bundle");
    for (int i = optind; i < argc; ++i) {
        if (!is_payload(argv[i])) {
            fprintf(stderr, "iosinject: unsupported payload: %s\n", argv[i]);
            return 1;
        }
    }

    std::filesystem::path final_target;
    if (o.inplace) final_target = input_app;
    else if (o.output) final_target = std::filesystem::absolute(o.output).lexically_normal();
    else final_target = input_app.parent_path() / (input_app.stem().string() + ".injected.app");
    std::error_code ec;
    if (std::filesystem::exists(final_target, ec) && !o.overwrite && final_target != input_app)
        throw std::runtime_error("output exists: " + final_target.string() + " (use --overwrite)");
    if (final_target != input_app && std::filesystem::exists(final_target, ec) && !o.overwrite)
        throw std::runtime_error("output exists: " + final_target.string());
    std::filesystem::create_directories(final_target.parent_path(), ec);
    if (ec) throw std::runtime_error("cannot create output parent: " + ec.message());

    const auto stage = final_target.parent_path() /
        (final_target.filename().string() + ".ldid-stage-" + std::to_string(static_cast<long long>(::getpid())));
    const auto backup = final_target.parent_path() /
        (final_target.filename().string() + ".ldid-backup-" + std::to_string(static_cast<long long>(::getpid())));
    std::filesystem::remove_all(stage, ec);
    ec.clear();
    std::filesystem::remove_all(backup, ec);
    ec.clear();

    char *mainbin = nullptr;
    StrVec installed{nullptr, 0, 0};
    auto cleanup = [&] {
        if (mainbin) { free(mainbin); mainbin = nullptr; }
        for (size_t i = 0; i < installed.n; ++i) free(installed.v[i]);
        free(installed.v);
        installed.v = nullptr; installed.n = installed.cap = 0;
        std::error_code cleanup_ec;
        std::filesystem::remove_all(stage, cleanup_ec);
    };

    try {
        if (copy_tree(input_app.c_str(), stage.c_str()) < 0)
            throw std::runtime_error("failed to create staging copy of app bundle");
        mainbin = find_main(stage.c_str());
        if (!mainbin) throw std::runtime_error("main Mach-O not found in staged bundle");

        for (int i = optind; i < argc; ++i) {
            if (o.dry_run) {
                printf("install %s\n", argv[i]);
                continue;
            }
            if (install_payload(stage.c_str(), argv[i], &installed) < 0)
                throw std::runtime_error(std::string("failed to install payload: ") + argv[i]);
        }

        for (size_t i = 0; i < installed.n; ++i) {
            char *load_path = framework_load_path(stage.c_str(), installed.v[i]);
            if (!load_path) {
                if (o.verbose) fprintf(stderr, "iosinject: cannot derive @rpath for %s\n", installed.v[i]);
                continue;
            }
            if (o.dry_run) {
                printf("inject %s -> %s\n", mainbin, load_path);
                free(load_path);
                continue;
            }
            if (o.strip_codesig && strip_signature(mainbin) < 0) {
                free(load_path);
                throw std::runtime_error("unable to strip existing main executable signature");
            }
            if (patch_load(mainbin, load_path, &o) < 0) {
                const std::string failed = load_path;
                free(load_path);
                throw std::runtime_error("failed to inject load command for " + failed);
            }
            free(load_path);
        }

        if (!o.dry_run && o.sign) {
            if (sign_graph(stage.c_str(), mainbin, &o) != 0)
                throw std::runtime_error("staged bundle signing failed");
        }
        if (!o.dry_run && o.verify) {
            auto verification = ldid::Verifier::verify(stage);
            if (!verification.ok) {
                std::string reason = "staged bundle verification failed";
                for (const auto& error : verification.errors) reason += "\n  " + error;
                throw std::runtime_error(reason);
            }
        }

        if (o.dry_run) {
            printf("dry-run complete; no output committed\n");
            cleanup();
            return 0;
        }

        const bool target_exists = std::filesystem::exists(final_target, ec) && !ec;
        if (target_exists) {
            if (!o.overwrite && final_target != input_app)
                throw std::runtime_error("output appeared during build; refusing to overwrite: " + final_target.string());
            std::filesystem::rename(final_target, backup, ec);
            if (ec) throw std::runtime_error("cannot move previous target to backup: " + ec.message());
        }
        std::filesystem::rename(stage, final_target, ec);
        if (ec) {
            const std::string commit_error = ec.message();
            if (target_exists) {
                std::error_code restore_ec;
                std::filesystem::rename(backup, final_target, restore_ec);
                if (restore_ec) throw std::runtime_error("commit failed and rollback failed: " + commit_error + "; " + restore_ec.message());
            }
            throw std::runtime_error("cannot atomically commit staged app: " + commit_error);
        }
        if (target_exists) std::filesystem::remove_all(backup, ec);
        printf("%s\n", final_target.c_str());
        cleanup();
        return 0;
    } catch (const std::exception& error) {
        if (mainbin) { free(mainbin); mainbin = nullptr; }
        for (size_t i = 0; i < installed.n; ++i) free(installed.v[i]);
        free(installed.v); installed.v = nullptr;
        std::error_code cleanup_ec;
        std::filesystem::remove_all(stage, cleanup_ec);
        fprintf(stderr, "iosinject: transaction aborted; original target was not committed: %s\n", error.what());
        return 1;
    }
}
} // namespace iosinject
} // namespace ldid

