#!/bin/sh
set -eu
CXX=${CXX:-c++}
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/ldid-custom-signature-tests-$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
CXXFLAGS=${CXXFLAGS:--std=c++17 -Wall -Wextra -Werror -O2}
# CXXFLAGS is intentionally word-split to allow normal compiler flag lists.
# shellcheck disable=SC2086
"$CXX" $CXXFLAGS "$ROOT/tests/der_engine_tests.cpp" -o "$TMP/der_engine_tests"
"$TMP/der_engine_tests"
# shellcheck disable=SC2086
"$CXX" $CXXFLAGS -Wno-deprecated-declarations "$ROOT/tests/cms_attribute_tests.cpp" -lcrypto -o "$TMP/cms_attribute_tests"
"$TMP/cms_attribute_tests"
