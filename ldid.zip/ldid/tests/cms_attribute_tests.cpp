#include "../cms_attribute_engine.hpp"

#include <openssl/evp.h>
#include <openssl/pkcs7.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>

#include <cassert>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

using PkeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
using PkeyCtxPtr = std::unique_ptr<EVP_PKEY_CTX, decltype(&EVP_PKEY_CTX_free)>;
using X509Ptr = std::unique_ptr<X509, decltype(&X509_free)>;
using Pkcs7Ptr = std::unique_ptr<PKCS7, decltype(&PKCS7_free)>;
using BioPtr = std::unique_ptr<BIO, decltype(&BIO_free)>;

static PkeyPtr make_key() {
    PkeyCtxPtr context(EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, nullptr), EVP_PKEY_CTX_free);
    assert(context && EVP_PKEY_keygen_init(context.get()) == 1);
    assert(EVP_PKEY_CTX_set_rsa_keygen_bits(context.get(), 2048) == 1);
    EVP_PKEY* raw = nullptr;
    assert(EVP_PKEY_keygen(context.get(), &raw) == 1);
    return PkeyPtr(raw, EVP_PKEY_free);
}

static X509Ptr make_certificate(EVP_PKEY* key) {
    X509Ptr certificate(X509_new(), X509_free);
    assert(certificate);
    assert(ASN1_INTEGER_set(X509_get_serialNumber(certificate.get()), 1) == 1);
    assert(X509_gmtime_adj(X509_getm_notBefore(certificate.get()), -60) != nullptr);
    assert(X509_gmtime_adj(X509_getm_notAfter(certificate.get()), 3600) != nullptr);
    assert(X509_set_pubkey(certificate.get(), key) == 1);
    X509_NAME* name = X509_get_subject_name(certificate.get());
    assert(X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC,
        reinterpret_cast<const unsigned char*>("ldid CMS test"), -1, -1, 0) == 1);
    assert(X509_set_issuer_name(certificate.get(), name) == 1);
    assert(X509_sign(certificate.get(), key, EVP_sha256()) > 0);
    return certificate;
}

static bool verify(PKCS7* p7, const std::vector<uint8_t>& content) {
    BioPtr input(BIO_new_mem_buf(content.data(), static_cast<int>(content.size())), BIO_free);
    BioPtr output(BIO_new(BIO_s_mem()), BIO_free);
    if (!input || !output) return false;
    return PKCS7_verify(p7, nullptr, nullptr, input.get(), output.get(),
        PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOVERIFY) == 1;
}

static bool has_attribute(STACK_OF(X509_ATTRIBUTE)* attributes, const char* dotted_oid) {
    ASN1_OBJECT* wanted = OBJ_txt2obj(dotted_oid, 1);
    if (!wanted) return false;
    bool found = false;
    for (int i = 0; attributes && i < sk_X509_ATTRIBUTE_num(attributes); ++i) {
        X509_ATTRIBUTE* attribute = sk_X509_ATTRIBUTE_value(attributes, i);
        if (attribute && OBJ_cmp(X509_ATTRIBUTE_get0_object(attribute), wanted) == 0) {
            found = true;
            break;
        }
    }
    ASN1_OBJECT_free(wanted);
    return found;
}

int main() {
    const std::vector<uint8_t> content{'C','M','S',' ','c','u','s','t','o','m',' ','a','t','t','r',' ','t','e','s','t'};
    const std::string signed_oid = "1.3.6.1.4.1.55555.100.1";
    const std::string unsigned_oid = "1.3.6.1.4.1.55555.100.2";
    const ldid::CustomCMSAttribute signed_attribute{signed_oid, {0x0c, 0x05, 'H', 'e', 'l', 'l', 'o'}};
    const ldid::CustomCMSAttribute unsigned_attribute{unsigned_oid, {0x02, 0x01, 0x2a}};

    auto key = make_key();
    auto certificate = make_certificate(key.get());
    Pkcs7Ptr p7(PKCS7_sign(nullptr, nullptr, nullptr, nullptr,
        PKCS7_BINARY | PKCS7_DETACHED | PKCS7_PARTIAL), PKCS7_free);
    assert(p7);
    PKCS7_SIGNER_INFO* signer = PKCS7_sign_add_signer(p7.get(), certificate.get(), key.get(), EVP_sha256(), PKCS7_NOSMIMECAP);
    assert(signer);

    std::string diagnostic;
    assert(ldid::crypto::cms_attributes::add_one(signer, signed_attribute, true, &diagnostic));
    assert(!ldid::crypto::cms_attributes::add_one(signer, signed_attribute, true, &diagnostic)); // duplicate rejected
    const ldid::CustomCMSAttribute bad_boolean{"1.3.6.1.4.1.55555.100.3", {0x01, 0x01, 0x01}};
    assert(!ldid::crypto::cms_attributes::add_one(signer, bad_boolean, true, &diagnostic));
    const ldid::CustomCMSAttribute bad_oid{"1.not-an-oid", {0x05, 0x00}};
    assert(!ldid::crypto::cms_attributes::add_one(signer, bad_oid, true, &diagnostic));

    BioPtr input(BIO_new_mem_buf(content.data(), static_cast<int>(content.size())), BIO_free);
    assert(input && PKCS7_final(p7.get(), input.get(), PKCS7_BINARY | PKCS7_DETACHED | PKCS7_NOSMIMECAP) == 1);
    assert(has_attribute(signer->auth_attr, signed_oid.c_str()));
    assert(ldid::crypto::cms_attributes::add_one(signer, unsigned_attribute, false, &diagnostic));
    assert(has_attribute(signer->unauth_attr, unsigned_oid.c_str()));
    assert(verify(p7.get(), content)); // unsignedAttrs do not invalidate the signer signature

    unsigned char* encoded = nullptr;
    const int encoded_length = i2d_PKCS7(p7.get(), &encoded);
    assert(encoded_length > 0 && encoded);
    const unsigned char* cursor = encoded;
    Pkcs7Ptr reparsed(d2i_PKCS7(nullptr, &cursor, encoded_length), PKCS7_free);
    assert(reparsed && cursor == encoded + encoded_length);
    OPENSSL_free(encoded);
    assert(verify(reparsed.get(), content));
    auto* signers = PKCS7_get_signer_info(reparsed.get());
    assert(signers && sk_PKCS7_SIGNER_INFO_num(signers) == 1);
    auto* reparsed_signer = sk_PKCS7_SIGNER_INFO_value(signers, 0);
    assert(has_attribute(reparsed_signer->auth_attr, signed_oid.c_str()));
    assert(has_attribute(reparsed_signer->unauth_attr, unsigned_oid.c_str()));

    std::cout << "cms_attribute_tests: PASS\n";
}
