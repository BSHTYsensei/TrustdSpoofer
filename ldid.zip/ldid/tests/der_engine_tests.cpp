#include "../der_engine.hpp"
#include <cassert>
#include <iostream>
#include <vector>

using ldid::der::validate;

static std::vector<uint8_t> hex(const char* s) {
    std::vector<uint8_t> out;
    for (size_t i = 0; s[i]; i += 2) {
        auto nibble = [](char c) -> uint8_t {
            if (c >= '0' && c <= '9') return static_cast<uint8_t>(c - '0');
            if (c >= 'a' && c <= 'f') return static_cast<uint8_t>(c - 'a' + 10);
            return static_cast<uint8_t>(c - 'A' + 10);
        };
        out.push_back(static_cast<uint8_t>((nibble(s[i]) << 4) | nibble(s[i + 1])));
    }
    return out;
}

int main() {
    // SEQUENCE { INTEGER 1, BOOLEAN TRUE, OID 1.2.840.113635 }
    assert(validate(hex("300e0201010101ff06062a864886f763")).ok);
    // DER long form is legal only for lengths >= 128 and without leading zeroes.
    std::vector<uint8_t> long_form{0x04, 0x81, 0x80};
    long_form.resize(131, 0x41);
    assert(validate(long_form).ok);
    assert(!validate(hex("04817f" )).ok);       // non-minimal long form
    assert(!validate(hex("04820080")).ok);    // leading zero length
    assert(!validate(hex("0480")).ok);        // indefinite length
    assert(!validate(hex("010101")).ok);      // BOOLEAN must be FF, not 01
    assert(!validate(hex("02020001")).ok);    // redundant INTEGER sign octet
    assert(!validate(hex("03020301")).ok);    // non-zero unused bits
    assert(!validate(hex("06028000")).ok);    // non-minimal OID arc
    assert(!validate(hex("060181")).ok);      // unterminated OID arc
    assert(!validate(hex("3106020102020101")).ok); // SET OF is unsorted
    assert(validate(hex("3106020101020102")).ok);
    assert(!validate(hex("300302010100")).ok); // trailing bytes
    assert(validate(hex("170d3234303130313030303030305a")).ok); // UTCTime 2024-01-01 UTC
    assert(!validate(hex("170d3234313330313030303030305a")).ok); // invalid date
    assert(!validate(hex("170d3234303130313030303030302b3030")).ok); // DER time must use Z
    assert(validate(hex("180f32303234303130313030303030305a")).ok); // GeneralizedTime
    assert(!validate(hex("181232303234303130313030303030302e31305a")).ok); // trailing fraction zero
    assert(validate(hex("1303414243")).ok); // PrintableString
    assert(!validate(hex("130140")).ok); // PrintableString excludes @
    assert(validate(hex("1203312032")).ok); // NumericString
    assert(validate(hex("120131")).ok); // NumericString digit
    assert(!validate(hex("1e02d800")).ok); // BMPString surrogate

    ldid::der::Limits limits;
    limits.max_nodes = 1;
    assert(!validate(hex("3006020101020102"), limits).ok);
    std::cout << "der_engine_tests: PASS\n";
}
