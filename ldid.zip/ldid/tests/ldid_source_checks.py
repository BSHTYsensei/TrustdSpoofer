#!/usr/bin/env python3
"""Regression checks for the two-file ldid source distribution."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def test_two_file_layout(cpp: str, hpp: str) -> None:
    for name in ('der_engine.hpp', 'cms_attribute_engine.hpp'):
        require(name not in cpp and name not in hpp,
                f"source still depends on removed helper header: {name}")
    require('namespace ldid::der {' in cpp and '} // namespace ldid::der' in cpp,
            'bounded read-only DER validator was not inlined into ldid.cpp')
    require('ldid::der::validate(' in cpp,
            'read-only DER validation call sites disappeared unexpectedly')
    print('PASS: two-file source layout')


def test_removed_editors(cpp: str, hpp: str) -> None:
    removed_symbols = (
        'CustomCMSAttribute', 'CustomOIDRegistryEntry', 'OIDRegistryEntry',
        'raw_cms_der', 'cms_signed_attributes', 'cms_unsigned_attributes',
        'required_certificate_extensions', 'oid_registry',
        '--oid-registry-', '--oid-check', '--der-inspect',
        'signedAttributes', 'unsignedAttributes',
        'requiredExtensions', 'oidRegistry',
    )
    for token in removed_symbols:
        require(token not in cpp and token not in hpp,
                f"removed custom ASN.1/OID feature remains: {token}")
    require('int run_certificate_inspect(' in cpp and 'rawDERHex' in cpp,
            'read-only X.509 extension inspection unexpectedly disappeared')
    print('PASS: custom ASN.1/OID editing interfaces removed')


def test_template_json(cpp: str) -> None:
    match = re.search(
        r'const char\* custom_signature_template_json\(\)\s*\{\s*return R"JSON\((.*?)\)JSON";',
        cpp, re.S)
    require(match is not None, 'could not locate embedded custom-signature JSON template')
    template = json.loads(match.group(1))
    require('cms' in template and 'customBlobs' in template,
            'template lost standard CMS/custom SuperBlob settings')
    cms = template['cms']
    for key in ('rawDERHex', 'signedAttributes', 'unsignedAttributes'):
        require(key not in cms, f'removed CMS editing field remains in template: {key}')
    print('PASS: embedded template is valid JSON and has no custom CMS attribute fields')


def test_signing_regressions(cpp: str) -> None:
    reset = cpp.find('BIO_reset(data_bio.get())')
    finalize = cpp.find('PKCS7_final(p7.get(), data_bio.get()')
    require(reset >= 0 and finalize > reset,
            'CMS data BIO is not rewound before PKCS7_final')
    require('bool layout_converged = false;' in cpp and
            'code signature size did not converge after 8 layout passes' in cpp,
            'signature placeholder convergence guard is missing')
    require('generated code-signature SuperBlob has an invalid header or length' in cpp,
            'generated SuperBlob header/length guard is missing')
    require('else if (arg == "-D") {\n            show_requirements = true;' in cpp,
            '-D no longer displays requirements')
    require('else if (arg == "--reset-cryptid")' in cpp,
            '--reset-cryptid compatibility option is missing')
    require('else if (arg == arg' not in cpp, 'unexpected malformed CLI branch')
    require('else if (arg == "-C")' in cpp and 'invalid -C value' in cpp,
            'standalone -C argument handling regression is missing')
    print('PASS: CMS, signature layout and CLI regression guards')


def test_der_validator(cpp: str, compiler: str) -> None:
    start = cpp.find('namespace ldid::der {')
    end_marker = '} // namespace ldid::der'
    end = cpp.find(end_marker, start)
    require(start >= 0 and end > start, 'could not extract inlined DER validator')
    implementation = cpp[start:end + len(end_marker)]
    harness = r'''#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>
''' + implementation + r'''
int main() {
    using ldid::der::validate;
    const std::vector<uint8_t> valid_sequence{0x30,0x06,0x02,0x01,0x01,0x01,0x01,0xff};
    if (!validate(valid_sequence).ok) return 1;

    const std::vector<uint8_t> non_minimal_integer{0x30,0x04,0x02,0x02,0x00,0x01};
    if (validate(non_minimal_integer).ok) return 2;

    const std::vector<uint8_t> non_minimal_length{0x04,0x81,0x01,0x00};
    if (validate(non_minimal_length).ok) return 3;

    const std::vector<uint8_t> unordered_set{0x31,0x06,0x02,0x01,0x02,0x02,0x01,0x01};
    if (validate(unordered_set).ok) return 4;

    const std::vector<uint8_t> non_minimal_oid{0x06,0x02,0x80,0x01};
    if (validate(non_minimal_oid).ok) return 5;

    ldid::der::Limits tiny;
    tiny.max_bytes = 4;
    if (validate(valid_sequence, tiny).ok) return 6;
    return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='ldid-der-test-') as tmp:
        src = Path(tmp) / 'der_validator_test.cpp'
        binary = Path(tmp) / 'der_validator_test'
        src.write_text(harness)
        build = subprocess.run(
            [compiler, '-std=c++17', '-O2', '-Wall', '-Wextra', str(src), '-o', str(binary)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(build.returncode == 0,
                'DER validator test harness failed to compile:\n' + build.stdout)
        run = subprocess.run([str(binary)], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(run.returncode == 0,
                f'DER validator test failed with exit {run.returncode}:\n{run.stdout}')
    print('PASS: DER parser valid/invalid vectors and resource limit')



def test_hot_path_and_macho_guards(cpp: str) -> None:
    require('class DigestContext {' in cpp and 'EVP_DigestInit_ex(context_, md_, nullptr)' in cpp,
            'reusable EVP digest context is missing from the page-hash hot path')
    require('inputs.code_data = signing_image.data();' in cpp and 'inputs.code_size = signing_limit;' in cpp,
            'CodeDirectory no longer uses a non-owning signed-image view')
    require('const std::vector<uint8_t> code' not in cpp,
            'CodeDirectoryInputs still owns/copies the full signed image')
    require('const std::vector<std::vector<uint8_t>>* special_slots = nullptr;' in cpp and
            'const std::vector<uint8_t>* pre_encrypt_hashes = nullptr;' in cpp and
            'const std::vector<uint8_t>* linkage_data = nullptr;' in cpp,
            'alternate CodeDirectories still duplicate large shared signature inputs')
    require('inputs.special_slots = &special_slots;' in cpp and
            'inputs.pre_encrypt_hashes = &custom.pre_encrypt_hashes;' in cpp and
            'inputs.linkage_data = &custom.linkage_data;' in cpp,
            'shared read-only CodeDirectory input views are not wired to stable signing storage')
    require('enumerate_load_commands(const std::vector<uint8_t>& data' in cpp and
            'if (pos != command_end) return {};' in cpp,
            'Mach-O load-command parser no longer validates the complete bounded table')
    require('ranges[i].first < ranges[i - 1].second' in cpp and
            'slice.size > data.size() - slice.offset' in cpp,
            'universal Mach-O overlap/bounds checks are missing')
    require('atomic<bool> cancelled{false};' in cpp,
            'parallel signing worker pool does not stop scheduling after first failure')
    require('inline thread_local unsigned int parallel_execution_depth = 0;' in cpp and
            'struct ParallelExecutionGuard' in cpp and
            'parallel_execution_depth == 0' in cpp and
            'input.parallel_hash_worker_limit' in cpp,
            'nested parallel signing is not bounded before enabling page hashing')
    require('code_limit >= (32ULL * 1024ULL * 1024ULL)' in cpp and
            'configured_limit = input.parallel_hash_worker_limit == 0' in cpp,
            'large-image hashing lacks a conservative size threshold or worker cap')
    require('const uint64_t first_page = code_slots64 * worker_index / worker_count;' in cpp and
            'const uint64_t last_page = code_slots64 * (worker_index + 1U) / worker_count;' in cpp,
            'parallel page hashing does not partition disjoint contiguous slot ranges')
    require('std::rethrow_exception(failure);' in cpp,
            'parallel page-hash worker failures are not propagated')
    require('read_u32_file(data.data() + command.offset + 44, header.big)' in cpp,
            '32-bit LC_SEGMENT initprot field offset is incorrect')
    require('bool code_signature_seen = false;' in cpp and 'command.cmdsize != 16 || code_signature_seen' in cpp,
            'Mach-O parser does not reject duplicate/malformed LC_CODE_SIGNATURE commands')
    require('refusing to sign a malformed Mach-O header or load-command table' in cpp,
            'malformed Mach-O signing can still silently succeed as a no-op')
    require('load_commands_end = static_cast<uint64_t>(header.header_size) + header.sizeofcmds' in cpp,
            'LC_CODE_SIGNATURE is not checked against the header/load-command region')
    require('const auto updated_header = parse_header(out, 0);' in cpp,
            'signature stripping does not update LINKEDIT using the modified load-command count')
    print('PASS: hashing hot-path, zero-copy inputs and Mach-O bounds guards')


def test_digest_context(cpp: str, hpp_path: Path, compiler: str) -> None:
    marker = 'class DigestContext {'
    start = cpp.find(marker)
    end = cpp.find('\n};\n\nstd::vector<uint8_t> hash_impl', start)
    require(start >= 0 and end > start, 'could not extract reusable EVP digest context')
    implementation = cpp[start:end + 3]
    harness = r'''#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <thread>
#include <vector>
#include <openssl/evp.h>
#include "ldid.hpp"
namespace ldid::crypto {
''' + implementation + r'''
}
int main() {
    using ldid::HashType;
    const std::vector<HashType> types = {HashType::SHA1, HashType::SHA256,
        HashType::SHA256_TRUNCATED, HashType::SHA384};
    const std::vector<size_t> lengths = {0, 1, 17, 4096, 65537};
    for (auto type : types) {
        ldid::crypto::DigestContext context(type);
        for (size_t length : lengths) {
            std::vector<uint8_t> input(length);
            for (size_t i = 0; i < input.size(); ++i)
                input[i] = static_cast<uint8_t>((i * 131U + length * 17U) & 0xffU);
            const EVP_MD* md = type == HashType::SHA1 ? EVP_sha1() :
                type == HashType::SHA384 ? EVP_sha384() : EVP_sha256();
            std::array<uint8_t, EVP_MAX_MD_SIZE> expected{};
            unsigned int expected_length = 0;
            static const uint8_t empty = 0;
            if (EVP_Digest(input.empty() ? &empty : input.data(), input.size(),
                           expected.data(), &expected_length, md, nullptr) != 1) return 1;
            const size_t output_size = type == HashType::SHA256_TRUNCATED ? 20U : expected_length;
            std::vector<uint8_t> actual(output_size);
            context.digest(input.empty() ? nullptr : input.data(), input.size(),
                           actual.data(), actual.size());
            if (!std::equal(actual.begin(), actual.end(), expected.begin())) return 2;
        }
    }

    // Exercise the same independent contiguous page partitions used by the
    // production large-image path. Every worker owns a separate EVP context
    // and writes to disjoint output slots.
    constexpr size_t page_size = 4096;
    constexpr size_t worker_count = 4;
    const size_t code_size = 32U * 1024U * 1024U + 37U;
    const size_t slots = (code_size + page_size - 1U) / page_size;
    std::vector<uint8_t> code(code_size);
    for (size_t i = 0; i < code.size(); ++i)
        code[i] = static_cast<uint8_t>((i * 29U + (i >> 7U) * 11U) & 0xffU);
    std::vector<uint8_t> serial(slots * 32U), parallel(slots * 32U);
    {
        ldid::crypto::DigestContext context(HashType::SHA256);
        for (size_t page = 0; page < slots; ++page) {
            const size_t offset = page * page_size;
            const size_t length = std::min(page_size, code.size() - offset);
            context.digest(code.data() + offset, length,
                           serial.data() + page * 32U, 32U);
        }
    }
    std::vector<std::thread> workers;
    workers.reserve(worker_count);
    for (size_t worker = 0; worker < worker_count; ++worker) {
        workers.emplace_back([&, worker] {
            ldid::crypto::DigestContext context(HashType::SHA256);
            const size_t first = slots * worker / worker_count;
            const size_t last = slots * (worker + 1U) / worker_count;
            for (size_t page = first; page < last; ++page) {
                const size_t offset = page * page_size;
                const size_t length = std::min(page_size, code.size() - offset);
                context.digest(code.data() + offset, length,
                               parallel.data() + page * 32U, 32U);
            }
        });
    }
    for (auto& worker : workers) worker.join();
    if (serial != parallel) return 3;
    return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='ldid-digest-test-') as tmp:
        src = Path(tmp) / 'digest_context_test.cpp'
        binary = Path(tmp) / 'digest_context_test'
        src.write_text(harness)
        build = subprocess.run(
            [compiler, '-std=c++20', '-O3', '-Wall', '-Wextra', '-I', str(hpp_path.parent),
             str(src), '-lcrypto', '-o', str(binary)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(build.returncode == 0,
                'digest-context test harness failed to compile:\n' + build.stdout)
        run = subprocess.run([str(binary)], text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(run.returncode == 0,
                f'digest-context compatibility test failed with exit {run.returncode}:\n{run.stdout}')
    print('PASS: reusable SHA-1/SHA-256/truncated-SHA-256/SHA-384 output parity and context reuse')

def test_workflow(workflow_path: Path) -> None:
    if not workflow_path.exists():
        print('SKIP: workflow file not present in this source tree')
        return
    workflow = workflow_path.read_text()
    require('ldid_custom_signature_engine.zip' not in workflow,
            'workflow still prioritizes the obsolete source archive')
    source_block = re.search(r'REQUIRED_SOURCE_FILES=\((.*?)\)', workflow, re.S)
    require(source_block is not None and
            re.findall(r'^\s+(ldid\.cpp|ldid\.hpp)\s*$', source_block.group(1), re.M) == ['ldid.cpp', 'ldid.hpp'],
            'workflow source requirements are not limited to ldid.cpp and ldid.hpp')
    require('python3 tests/ldid_source_checks.py' in workflow,
            'workflow does not run the source regression tests')
    require('-fsyntax-only' in workflow,
            'workflow does not run the iOS-target syntax compilation check')
    print('PASS: workflow uses the two-file source and includes tests')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--workflow', type=Path, default=None)
    parser.add_argument('--compiler', default=os.environ.get('CXX', 'clang++'))
    args = parser.parse_args()
    source = args.source_dir.resolve()
    cpp_path, hpp_path = source / 'ldid.cpp', source / 'ldid.hpp'
    require(cpp_path.is_file() and hpp_path.is_file(),
            'source directory must contain ldid.cpp and ldid.hpp')
    cpp, hpp = cpp_path.read_text(), hpp_path.read_text()
    test_two_file_layout(cpp, hpp)
    test_removed_editors(cpp, hpp)
    test_template_json(cpp)
    test_signing_regressions(cpp)
    test_hot_path_and_macho_guards(cpp)
    compiler_path = shutil.which(args.compiler)
    require(compiler_path is not None, f'C++ compiler not found: {args.compiler}')
    test_der_validator(cpp, compiler_path)
    test_digest_context(cpp, hpp_path, compiler_path)
    workflow_path = args.workflow or (source / '.github' / 'workflows' / 'build_libs.yml')
    if not workflow_path.exists():
        workflow_path = source / 'build_libs.yml'
    test_workflow(workflow_path)
    print('All ldid source checks passed.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        raise SystemExit(f'FAIL: {exc}')
