#!/usr/bin/env python3
"""Regression checks for the two-file ldid source distribution."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def test_two_file_layout(cpp: str, hpp: str) -> None:
    for name in ('der_engine.hpp', 'cms_attribute_engine.hpp'):
        require(name not in cpp and name not in hpp,
                f"source still depends on removed helper header: {name}")
    require('namespace ldid::der {' in cpp and '} // namespace ldid::der' in cpp,
            'bounded read-only DER validator was not inlined into ldid.cpp')
    require('ldid::der::validate(' in cpp,
            'read-only DER validation call sites disappeared unexpectedly')
    print('PASS: two-file source layout')


def test_removed_editors(cpp: str, hpp: str) -> None:
    removed_symbols = (
        'CustomCMSAttribute', 'CustomOIDRegistryEntry', 'OIDRegistryEntry',
        'raw_cms_der', 'cms_signed_attributes', 'cms_unsigned_attributes',
        'required_certificate_extensions', 'oid_registry',
        '--oid-registry-', '--oid-check', '--der-inspect',
        'signedAttributes', 'unsignedAttributes',
        'requiredExtensions', 'oidRegistry',
    )
    for token in removed_symbols:
        require(token not in cpp and token not in hpp,
                f"removed custom ASN.1/OID feature remains: {token}")
    require('int run_certificate_inspect(' in cpp and 'rawDERHex' in cpp,
            'read-only X.509 extension inspection unexpectedly disappeared')
    print('PASS: custom ASN.1/OID editing interfaces removed')


def test_template_json(cpp: str) -> None:
    match = re.search(
        r'const char\* custom_signature_template_json\(\)\s*\{\s*return R"JSON\((.*?)\)JSON";',
        cpp, re.S)
    require(match is not None, 'could not locate embedded custom-signature JSON template')
    template = json.loads(match.group(1))
    require('cms' in template and 'customBlobs' in template,
            'template lost standard CMS/custom SuperBlob settings')
    cms = template['cms']
    for key in ('rawDERHex', 'signedAttributes', 'unsignedAttributes'):
        require(key not in cms, f'removed CMS editing field remains in template: {key}')
    print('PASS: embedded template is valid JSON and has no custom CMS attribute fields')


def test_signing_regressions(cpp: str) -> None:
    reset = cpp.find('BIO_reset(data_bio.get())')
    finalize = cpp.find('PKCS7_final(p7.get(), data_bio.get()')
    require(reset >= 0 and finalize > reset,
            'CMS data BIO is not rewound before PKCS7_final')
    require('bool layout_converged = false;' in cpp and
            'code signature size did not converge after 8 layout passes' in cpp,
            'signature placeholder convergence guard is missing')
    require('generated code-signature SuperBlob has an invalid header or length' in cpp,
            'generated SuperBlob header/length guard is missing')
    require('else if (arg == "-D") {\n            show_requirements = true;' in cpp,
            '-D no longer displays requirements')
    require('else if (arg == "--reset-cryptid")' in cpp,
            '--reset-cryptid compatibility option is missing')
    require('else if (arg == arg' not in cpp, 'unexpected malformed CLI branch')
    require('else if (arg == "-C")' in cpp and 'invalid -C value' in cpp,
            'standalone -C argument handling regression is missing')
    print('PASS: CMS, signature layout and CLI regression guards')


def test_der_validator(cpp: str, compiler: str) -> None:
    start = cpp.find('namespace ldid::der {')
    end_marker = '} // namespace ldid::der'
    end = cpp.find(end_marker, start)
    require(start >= 0 and end > start, 'could not extract inlined DER validator')
    implementation = cpp[start:end + len(end_marker)]
    harness = r'''#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <string>
#include <utility>
#include <vector>
''' + implementation + r'''
int main() {
    using ldid::der::validate;
    const std::vector<uint8_t> valid_sequence{0x30,0x06,0x02,0x01,0x01,0x01,0x01,0xff};
    if (!validate(valid_sequence).ok) return 1;

    const std::vector<uint8_t> non_minimal_integer{0x30,0x04,0x02,0x02,0x00,0x01};
    if (validate(non_minimal_integer).ok) return 2;

    const std::vector<uint8_t> non_minimal_length{0x04,0x81,0x01,0x00};
    if (validate(non_minimal_length).ok) return 3;

    const std::vector<uint8_t> unordered_set{0x31,0x06,0x02,0x01,0x02,0x02,0x01,0x01};
    if (validate(unordered_set).ok) return 4;

    const std::vector<uint8_t> non_minimal_oid{0x06,0x02,0x80,0x01};
    if (validate(non_minimal_oid).ok) return 5;

    ldid::der::Limits tiny;
    tiny.max_bytes = 4;
    if (validate(valid_sequence, tiny).ok) return 6;
    return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='ldid-der-test-') as tmp:
        src = Path(tmp) / 'der_validator_test.cpp'
        binary = Path(tmp) / 'der_validator_test'
        src.write_text(harness)
        build = subprocess.run(
            [compiler, '-std=c++17', '-O2', '-Wall', '-Wextra', str(src), '-o', str(binary)],
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(build.returncode == 0,
                'DER validator test harness failed to compile:\n' + build.stdout)
        run = subprocess.run([str(binary)], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        require(run.returncode == 0,
                f'DER validator test failed with exit {run.returncode}:\n{run.stdout}')
    print('PASS: DER parser valid/invalid vectors and resource limit')


def test_workflow(workflow_path: Path) -> None:
    if not workflow_path.exists():
        print('SKIP: workflow file not present in this source tree')
        return
    workflow = workflow_path.read_text()
    require('ldid_custom_signature_engine.zip' not in workflow,
            'workflow still prioritizes the obsolete source archive')
    source_block = re.search(r'REQUIRED_SOURCE_FILES=\((.*?)\)', workflow, re.S)
    require(source_block is not None and
            re.findall(r'^\s+(ldid\.cpp|ldid\.hpp)\s*$', source_block.group(1), re.M) == ['ldid.cpp', 'ldid.hpp'],
            'workflow source requirements are not limited to ldid.cpp and ldid.hpp')
    require('python3 tests/ldid_source_checks.py' in workflow,
            'workflow does not run the source regression tests')
    require('-fsyntax-only' in workflow,
            'workflow does not run the iOS-target syntax compilation check')
    print('PASS: workflow uses the two-file source and includes tests')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-dir', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--workflow', type=Path, default=None)
    parser.add_argument('--compiler', default=os.environ.get('CXX', 'clang++'))
    args = parser.parse_args()
    source = args.source_dir.resolve()
    cpp_path, hpp_path = source / 'ldid.cpp', source / 'ldid.hpp'
    require(cpp_path.is_file() and hpp_path.is_file(),
            'source directory must contain ldid.cpp and ldid.hpp')
    cpp, hpp = cpp_path.read_text(), hpp_path.read_text()
    test_two_file_layout(cpp, hpp)
    test_removed_editors(cpp, hpp)
    test_template_json(cpp)
    test_signing_regressions(cpp)
    compiler_path = shutil.which(args.compiler)
    require(compiler_path is not None, f'C++ compiler not found: {args.compiler}')
    test_der_validator(cpp, compiler_path)
    workflow_path = args.workflow or (source / '.github' / 'workflows' / 'build_libs.yml')
    test_workflow(workflow_path)
    print('All ldid source checks passed.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        raise SystemExit(f'FAIL: {exc}')
