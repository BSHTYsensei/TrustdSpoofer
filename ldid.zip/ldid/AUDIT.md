# ldid 源码审计与性能优化记录

审计日期：2026-11-25  
对象：`ldid.cpp`、`ldid.hpp`、`build_libs.yml` 与源码回归测试。

## 结论摘要

本次以签名正确性优先，针对 Mach-O 解析边界、CodeDirectory 哈希热路径、备用目录内存复制和并发调度进行了修改。源码回归测试通过，摘要输出与 OpenSSL 单次摘要结果一致，串行与并行页哈希结果一致。

**这不是 Apple 设备上的端到端签名认证报告。** 当前执行环境为 Linux，没有 Xcode/iOS SDK，也缺少 libplist 开发头文件和库，因此无法在本机完成仓库 workflow 中的 iOS arm64 完整编译、macOS `codesign` 对照验证或设备安装验证。仓库内的 `build_libs.yml` 保留了 macOS runner 上的 iOS arm64 syntax-only compile 和最终静态链接步骤；发布前仍应在该环境执行并进行真实设备验签。

## 审查及修正

### Mach-O / Universal Binary

- load-command 表现在按 `sizeofcmds` 建立严格边界；命令数量、每条命令长度和整个命令区必须吻合，损坏或截断的命令表不再被部分解析后继续签名。
- 对 `LC_CODE_SIGNATURE` 检查命令长度、重复命令、签名范围越界，以及签名数据与 Mach-O header/load-command 区的重叠。
- 修正 32 位 `LC_SEGMENT.initprot` 字段偏移：正确位置是命令偏移 `+44`，原代码读到的是 `nsects`（`+48`）。这会影响 32 位可执行段判定及 CodeDirectory 执行段元数据。
- 对 `LC_SEGMENT` / `LC_SEGMENT_64` 的 file range 和 64 位 VM range 加入边界/溢出检查；段名读取限制在固定 16 字节字段内。
- Fat/Fat64 切片现在要求架构表完整、切片非空且在文件内、对齐指数合法、切片不重叠、切片头 CPU 类型与 Fat 表一致；Fat64 reserved 字段必须为零。损坏的 universal binary 不再跳过坏切片并继续生成部分结果。
- 签名大小、签名偏移及 `__LINKEDIT` 32 位字段在写入前检查可表示性，不再静默截断。
- 剥离 `LC_CODE_SIGNATURE` 后，先重新解析已更新的 `ncmds/sizeofcmds`，再更新 `__LINKEDIT`，避免旧命令数令重新枚举失败、导致 LINKEDIT 大小未更新。

### CodeDirectory / 验签

- 保留 SHA-1、SHA-256、截断 SHA-256、SHA-384，CodeDirectory v2.0–v2.6、special slots、scatter、pre-encrypt hashes、linkage 数据和备用 CodeDirectory 的既有数据格式。
- 代码页哈希改为直接写入 CodeDirectory 输出区，避免原先每页临时创建 digest vector、再复制到哈希表的额外分配和复制。
- 哈希计算使用可复用的 OpenSSL EVP 上下文；所有摘要初始化、更新、结束操作都检查返回值和摘要长度。验签路径同样避免为每页分配一个临时摘要 vector。
- `CodeDirectoryInputs` 对待签名 Mach-O、special slots、pre-encrypt hashes 和 linkage data 使用受控只读视图。备用 CodeDirectory 只复制小型配置，不再复制完整代码区及上述可能较大的数据块。视图所指向的存储均由当前签名函数的局部对象持有，直到主目录和所有备用目录构建完成。
- 页数计算改为除法加余数，避免 `code_limit + page_size - 1` 溢出。
- scatter 校验允许合法的最后一页为部分页：检查最后一页的起始偏移仍在 `codeLimit` 内，而不错误要求末页必须是完整页；同时检查偏移乘加溢出、重复 slot、越界范围和 sentinel。
- 验签时对无限页大小、页数、页范围、散列表范围、scatter 偏移和散列结果作对应检查。
- 读取 CodeDirectory cdhash 时检查 OpenSSL 摘要调用结果，不再在摘要失败时继续返回可能错误的 cdhash。

### 并发与资源控制

- 只有非-scatter CodeDirectory、签名代码区至少 32 MiB、且当前线程不处在外层并行签名任务时，才启动页哈希并行任务。
- 页按连续 slot 范围分区；每个 worker 使用独立 EVP 上下文并写入互不重叠的输出范围。
- 自动模式最多 4 个 worker；显式 `--jobs N` 会限制页哈希 worker 数，`--jobs 1` 保持串行。Fat slice / bundle / resource 外层已经并行时，内层页哈希退回串行，避免线程数相乘。
- 通用签名 worker pool 在首个任务异常后停止继续领取新任务，并在 join 后传播异常。

## ASM 与最佳实践判断

不建议在 ldid 中手写或强制 ARM SHA 指令。当前 `build_libs.yml` 固定 OpenSSL `openssl-4.1.0`，使用 `ios64-cross`，没有传入 `no-asm`；发布优化参数包括 `-O3` 和 `-flto=thin`。OpenSSL 在 AArch64 Apple 平台会按其 CPU capability 配置选择 SHA-1/SHA-256 硬件实现；`EVP` 可让调用方保留算法可移植性，并由 OpenSSL 负责实现选择。自行设置某个特定 `-mcpu` 或直接插入 SHA 指令，可能让二进制失去目标设备兼容性，因此没有这样做。

更合适的性能路线是：让 OpenSSL 自带的 ARM 汇编/硬件加速生效；减少每页临时分配和复制；只对足够大的文件并行；控制并发上限；保留 ThinLTO 和 `-O3`。ThinLTO 的并行后端和跨模块优化已经写在现有构建配置中，本次没有重复添加额外的激进编译选项。

参考资料：

- Apple TN3126：CodeDirectory 的 per-page hashes、special slots、资源和 entitlements 封印，以及 universal binary 各架构独立签名。https://developer.apple.com/documentation/technotes/tn3126-inside-code-signing-hashes
- Apple TN3161：CMS、证书链和签名验证模型。https://developer.apple.com/documentation/technotes/tn3161-inside-code-signing-certificates
- OpenSSL EVP digest 文档：建议使用 `EVP_DigestInit_ex` / `EVP_DigestFinal_ex`，并检查初始化返回值。https://docs.openssl.org/master/man3/EVP_DigestInit/
- OpenSSL ARM capability dispatch：Apple AArch64 SHA-1 / SHA-256 capability 配置。https://github.com/openssl/openssl/blob/master/crypto/armcap.c
- OpenSSL ARMv8 SHA-1 汇编实现及其硬件加速路径。https://github.com/openssl/openssl/blob/master/crypto/sha/asm/sha1-armv8.pl
- Clang ThinLTO：可扩展的 whole-program 优化与并行 backend。https://clang.llvm.org/docs/ThinLTO.html

## 回归测试与基准

运行命令：

```sh
python3 tests/ldid_source_checks.py
```

结果：所有源码检查通过，包括 DER 有效/无效输入、SHA-1/SHA-256/截断 SHA-256/SHA-384 摘要对照、空输入和多种页长、可复用上下文重复调用，以及 32 MiB+37 字节数据的串行/4-worker 页哈希逐字节一致性测试。测试同时检查了签名命令边界、FAT 切片规则、32 位 initprot 偏移、签名剥离后 LINKEDIT 更新及并发限制。

本机合成基准（Linux x86_64、Clang `-O3`、OpenSSL 3.5.7；7 轮中位数，不是 iPhone 实测）：

- 对 128 MiB、4 KiB 页、SHA-256，旧版每页创建临时 digest vector 并复制到输出的模式约 121.7 ms；复用 EVP 上下文、直接写输出的模式约 111.3 ms，约 1.09 倍。两种输出逐字节一致。
- 同一 128 MiB/4 KiB 页 workload，复用上下文的串行模式约 112.3 ms；4 worker 模式约 59.4 ms，约 1.89 倍。串行与并行散列输出一致。

这些数字用于比较实现方向，受 CPU、OpenSSL 构建方式、负载和内存带宽影响；不能直接外推为 iPhone 的固定提速比例。小文件仍走串行路径，避免线程启动开销。

## 仍需在 macOS / iOS 环境验证

1. 用仓库 `build_libs.yml` 在 macOS runner 完成依赖构建、iOS arm64 syntax-only compile 和完整链接。
2. 使用真实 32/64 位及 Fat Mach-O 样本覆盖签名、重签、剥离、指定架构、scatter 和多哈希目录。
3. 在 macOS 上用 Apple `codesign --verify --strict --deep` 与 `codesign --display -vvvvvv` 对照 CodeDirectory、资源封印、DER entitlements 和 CMS。
4. 使用真实证书/P12 和 adhoc 样本分别验证 CMS、证书链、entitlements 与设备安装/启动行为。

本次没有声称这些设备级验证已经完成。
