#ifndef LDID_HPP
#define LDID_HPP

#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <functional>
#include <filesystem>
#include <optional>
#include <variant>
#include <stdexcept>




namespace ldid {

enum class CPUType : uint32_t {
    ANY = 0xFFFFFFFF,
    X86 = 7,
    X86_64 = 0x01000007,
    ARM = 12,
    ARM64 = 0x0100000C,
    ARM64_32 = 0x0200000C,
    POWERPC = 18,
    POWERPC64 = 0x01000012
};

enum class FileType : uint32_t {
    OBJECT = 1,
    EXECUTE = 2,
    FVMLIB = 3,
    CORE = 4,
    PRELOAD = 5,
    DYLIB = 6,
    DYLINKER = 7,
    BUNDLE = 8,
    DYLIB_STUB = 9,
    DSYM = 10,
    KEXT_BUNDLE = 11
};

enum class HashType : uint32_t {
    ANY = 0,
    SHA1 = 1,
    SHA256 = 2,
    SHA256_TRUNCATED = 3,
    SHA384 = 4
};

// LC_BUILD_VERSION / CodeDirectory platform identifiers. The public Apple
// cctools public IDs 1..24 plus Xcode 27 KernelKit IDs 25..30. The latter
// are reverse-engineered linker identifiers and are not ordinary app targets.
enum class Platform : uint32_t {
    UNKNOWN = 0,
    MACOS = 1,
    IOS = 2,
    TVOS = 3,
    WATCHOS = 4,
    BRIDGEOS = 5,
    MACCATALYST = 6,
    IOSSIMULATOR = 7,
    TVOSSIMULATOR = 8,
    WATCHOSSIMULATOR = 9,
    DRIVERKIT = 10,
    VISIONOS = 11,
    VISIONOSSIMULATOR = 12,
    FIRMWARE = 13,
    SEPOS = 14,
    MACOS_EXCLAVECORE = 15,
    MACOS_EXCLAVEKIT = 16,
    IOS_EXCLAVECORE = 17,
    IOS_EXCLAVEKIT = 18,
    TVOS_EXCLAVECORE = 19,
    TVOS_EXCLAVEKIT = 20,
    WATCHOS_EXCLAVECORE = 21,
    WATCHOS_EXCLAVEKIT = 22,
    VISIONOS_EXCLAVECORE = 23,
    VISIONOS_EXCLAVEKIT = 24,
    // Xcode 27 KernelKit platform IDs. Names are reverse-engineered from the
    // Xcode 27 linker platform table; these are not ordinary app targets.
    MACOS_KERNELKIT = 25,
    IOS_KERNELKIT = 26,
    TVOS_KERNELKIT = 27,
    WATCHOS_KERNELKIT = 28,
    VISIONOS_KERNELKIT = 29,
    BRIDGEOS_KERNELKIT = 30
};

// XNU osfmk/kern/cs_blobs.h CS_* values. A subset is importable from a
// Mach-O CodeDirectory (CS_ALLOWED_MACHO); the remaining bits describe
// entitlement-derived or kernel/runtime process state and cannot be granted
// merely by setting the CodeDirectory field.
enum class CodeDirectoryFlag : uint32_t {
    NONE                    = 0x00000000,
    VALID                   = 0x00000001, // CS_VALID; kernel dynamically sets
    ADHOC                   = 0x00000002, // CS_ADHOC
    GET_TASK_ALLOW          = 0x00000004, // CS_GET_TASK_ALLOW; entitlement-derived
    INSTALLER               = 0x00000008, // CS_INSTALLER; entitlement-derived
    FORCED_LV               = 0x00000010, // CS_FORCED_LV; policy-derived
    INVALID_ALLOWED         = 0x00000020, // CS_INVALID_ALLOWED; macOS-only policy
    HARD                    = 0x00000100, // CS_HARD
    KILL                    = 0x00000200, // CS_KILL
    CHECK_EXPIRATION        = 0x00000400, // CS_CHECK_EXPIRATION
    RESTRICT                = 0x00000800, // CS_RESTRICT
    ENFORCEMENT             = 0x00001000, // CS_ENFORCEMENT
    REQUIRE_LV              = 0x00002000, // CS_REQUIRE_LV
    ENTITLEMENTS_VALIDATED  = 0x00004000, // CS_ENTITLEMENTS_VALIDATED
    NVRAM_UNRESTRICTED      = 0x00008000, // CS_NVRAM_UNRESTRICTED
    RUNTIME                 = 0x00010000, // CS_RUNTIME
    LINKER_SIGNED            = 0x00020000, // CS_LINKER_SIGNED
    EXEC_SET_HARD            = 0x00100000, // CS_EXEC_SET_HARD; runtime inheritance
    EXEC_SET_KILL            = 0x00200000, // CS_EXEC_SET_KILL; runtime inheritance
    EXEC_SET_ENFORCEMENT     = 0x00400000, // CS_EXEC_SET_ENFORCEMENT; runtime inheritance
    EXEC_INHERIT_SIP          = 0x00800000, // CS_EXEC_INHERIT_SIP; runtime inheritance
    KILLED                   = 0x01000000, // CS_KILLED; kernel state
    NO_UNTRUSTED_HELPERS      = 0x02000000, // CS_NO_UNTRUSTED_HELPERS
    DYLD_PLATFORM             = NO_UNTRUSTED_HELPERS, // legacy XNU alias
    PLATFORM_BINARY           = 0x04000000, // CS_PLATFORM_BINARY; kernel/platform trust
    PLATFORM_PATH             = 0x08000000, // CS_PLATFORM_PATH; macOS path-derived
    DEBUGGED                  = 0x10000000, // CS_DEBUGGED; runtime state
    SIGNED                    = 0x20000000, // CS_SIGNED; kernel state
    DEV_CODE                  = 0x40000000, // CS_DEV_CODE; signer/runtime-derived
    DATAVAULT_CONTROLLER      = 0x80000000, // CS_DATAVAULT_CONTROLLER; entitlement-derived

    // Source compatibility aliases. The previous ldid values were incorrect;
    // LIBRARY_VALIDATION now means CS_REQUIRE_LV (0x2000), not 0x4000.
    LIBRARY_VALIDATION = REQUIRE_LV,
    FOR_TESTING = NVRAM_UNRESTRICTED,
    HOST = VALID
};

enum class ExecSegmentFlag : uint64_t {
    NONE                 = 0x000,
    MAIN_BINARY          = 0x001,
    ALLOW_UNSIGNED       = 0x010,
    DEBUGGER             = 0x020,
    JIT                  = 0x040,
    SKIP_LV              = 0x080, // obsolete in XNU; avoid unless explicitly requested
    CAN_LOAD_CDHASH      = 0x100,
    CAN_EXEC_CDHASH      = 0x200
};

constexpr uint32_t CS_ALLOWED_MACHO_MASK =
    static_cast<uint32_t>(CodeDirectoryFlag::ADHOC) |
    static_cast<uint32_t>(CodeDirectoryFlag::HARD) |
    static_cast<uint32_t>(CodeDirectoryFlag::KILL) |
    static_cast<uint32_t>(CodeDirectoryFlag::CHECK_EXPIRATION) |
    static_cast<uint32_t>(CodeDirectoryFlag::RESTRICT) |
    static_cast<uint32_t>(CodeDirectoryFlag::ENFORCEMENT) |
    static_cast<uint32_t>(CodeDirectoryFlag::REQUIRE_LV) |
    static_cast<uint32_t>(CodeDirectoryFlag::RUNTIME) |
    static_cast<uint32_t>(CodeDirectoryFlag::LINKER_SIGNED);

constexpr uint32_t CS_ENTITLEMENT_FLAGS_MASK =
    static_cast<uint32_t>(CodeDirectoryFlag::GET_TASK_ALLOW) |
    static_cast<uint32_t>(CodeDirectoryFlag::INSTALLER) |
    static_cast<uint32_t>(CodeDirectoryFlag::DATAVAULT_CONTROLLER) |
    static_cast<uint32_t>(CodeDirectoryFlag::NVRAM_UNRESTRICTED);

constexpr uint64_t CS_EXECSEG_KNOWN_MASK =
    static_cast<uint64_t>(ExecSegmentFlag::MAIN_BINARY) |
    static_cast<uint64_t>(ExecSegmentFlag::ALLOW_UNSIGNED) |
    static_cast<uint64_t>(ExecSegmentFlag::DEBUGGER) |
    static_cast<uint64_t>(ExecSegmentFlag::JIT) |
    static_cast<uint64_t>(ExecSegmentFlag::SKIP_LV) |
    static_cast<uint64_t>(ExecSegmentFlag::CAN_LOAD_CDHASH) |
    static_cast<uint64_t>(ExecSegmentFlag::CAN_EXEC_CDHASH);

static_assert(static_cast<uint32_t>(CodeDirectoryFlag::GET_TASK_ALLOW) == 0x00000004U, "CS_GET_TASK_ALLOW must match XNU");
static_assert(static_cast<uint32_t>(CodeDirectoryFlag::REQUIRE_LV) == 0x00002000U, "CS_REQUIRE_LV must match XNU");
static_assert(static_cast<uint32_t>(CodeDirectoryFlag::ENTITLEMENTS_VALIDATED) == 0x00004000U, "CS_ENTITLEMENTS_VALIDATED must match XNU");
static_assert(static_cast<uint32_t>(CodeDirectoryFlag::NVRAM_UNRESTRICTED) == 0x00008000U, "CS_NVRAM_UNRESTRICTED must match XNU");
static_assert(CS_ALLOWED_MACHO_MASK == 0x00033F02U, "CS_ALLOWED_MACHO must match XNU");
static_assert(CS_ENTITLEMENT_FLAGS_MASK == 0x8000800CU, "CS_ENTITLEMENT_FLAGS must match XNU");
static_assert(CS_EXECSEG_KNOWN_MASK == 0x000003F1ULL, "CS_EXECSEG flags must match XNU");

enum class ArchiveFormat {
    UNKNOWN,
    ZIP,
    TAR,
    IPA
};

enum class BlobMagic : uint32_t {
    CSMAGIC_REQUIREMENT = 0xfade0c00,
    CSMAGIC_REQUIREMENTS = 0xfade0c01,
    CSMAGIC_CODEDIRECTORY = 0xfade0c02,
    CSMAGIC_EMBEDDED_SIGNATURE = 0xfade0cc0,
    CSMAGIC_DETACHED_SIGNATURE = 0xfade0cc1,
    CSMAGIC_BLOBWRAPPER = 0xfade0b01,
    CSMAGIC_EMBEDDED_ENTITLEMENTS = 0xfade7171,
    CSMAGIC_EMBEDDED_DER_ENTITLEMENTS = 0xfade7172
};

// Binary opcodes shared by the Requirement compiler, verifier, and display decoder.
enum class RequirementOpcode : uint32_t {
    FALSE_EXPR = 0,
    TRUE_EXPR = 1,
    IDENTIFIER = 2,
    APPLE_ANCHOR = 3,
    ANCHOR_HASH = 4,
    INFO_KEY_VALUE = 5,
    AND_EXPR = 6,
    OR_EXPR = 7,
    CDHASH = 8,
    NOT_EXPR = 9,
    INFO_KEY_FIELD = 10,
    CERT_FIELD = 11,
    TRUSTED_CERT = 12,
    TRUSTED_CERTS = 13,
    CERT_GENERIC = 14,
    APPLE_GENERIC_ANCHOR = 15,
    ENTITLEMENT_FIELD = 16,
    CERT_POLICY = 17,
    NAMED_ANCHOR = 18,
    NAMED_CODE = 19,
    PLATFORM = 20,
    NOTARIZED = 21,
    CERT_FIELD_DATE = 22,
    LEGACY_DEVID = 23
};

constexpr uint32_t requirement_opcode_value(RequirementOpcode opcode) noexcept {
    return static_cast<uint32_t>(opcode);
}

enum class CodeSignSlot : uint32_t {
    CODEDIRECTORY = 0,
    INFOSLOT = 1,
    REQUIREMENTS = 2,
    RESOURCESLOT = 3,
    APPLICATION = 4,
    ENTITLEMENTS = 5,
    REPSPECIFIC = 6,
    DER_ENTITLEMENTS = 7,
    ALTERNATE_BASE = 0x1000,
    CMS_SIGNATURE = 0x10000
};

struct Slice {
    uint64_t offset = 0;
    uint64_t size = 0;
    CPUType cpu_type = CPUType::ANY;
    uint32_t cpu_subtype = 0;
    uint64_t align = 0;
    bool fat64_container = false;
    bool fat_cigam_container = false;
};

struct SignatureInfo {
    std::string identifier;
    std::string team_id;
    std::vector<uint8_t> cd_hash;
    HashType hash_type = HashType::SHA256;
    std::vector<uint8_t> cms_signature;
    std::string entitlements_xml;
    std::vector<uint8_t> entitlements_der;
    std::vector<uint8_t> requirements_blob;
    bool adhoc = false;
    bool true_sign = false;
    uint32_t flags = 0;
    uint32_t version = 0;
    uint8_t platform = 0;
    uint64_t exec_seg_flags = 0;
    uint64_t exec_seg_base = 0;
    uint64_t exec_seg_limit = 0;
    uint32_t runtime_version = 0;
};

struct AlternateCodeDirectoryOptions {
    HashType hash_type = HashType::ANY;
    std::optional<uint32_t> version;
    std::optional<uint32_t> page_size;
    std::optional<uint8_t> platform;
    uint32_t flags_set = 0;
    uint32_t flags_clear = 0;
    std::string identifier;
    std::string team_id;
    std::optional<uint64_t> exec_segment_base;
    std::optional<uint64_t> exec_segment_limit;
    std::optional<uint64_t> exec_segment_flags;
    std::optional<uint32_t> runtime_version;
    std::vector<uint8_t> scatter_data;
    std::vector<uint8_t> pre_encrypt_hashes;
    std::optional<uint8_t> linkage_hash_type;
    std::optional<uint8_t> linkage_application_type;
    std::optional<uint16_t> linkage_application_subtype;
    std::vector<uint8_t> linkage_data;
};

struct CustomSignatureOptions {
    // Empty optionals mean AUTO: the signer derives a compatible value.
    std::optional<uint32_t> code_directory_version;
    std::optional<uint32_t> page_size;
    std::optional<uint8_t> platform;
    uint32_t flags_set = 0;
    uint32_t flags_clear = 0;
    std::optional<uint64_t> exec_segment_base;
    std::optional<uint64_t> exec_segment_limit;
    std::optional<uint64_t> exec_segment_flags;
    std::optional<uint32_t> runtime_version;
    std::optional<uint8_t> linkage_hash_type;
    std::optional<uint8_t> linkage_application_type;
    std::optional<uint16_t> linkage_application_subtype;
    std::vector<uint8_t> linkage_data;
    std::vector<uint8_t> scatter_data;           // packed 24-byte SC_Scatter records incl. zero-count sentinel
    std::vector<uint8_t> pre_encrypt_hashes;         // precomputed hash array, exact code-slot count * hashSize
    std::vector<HashType> alternate_hash_types;     // compatibility shorthand for hash-only alternate CDs
    std::vector<AlternateCodeDirectoryOptions> alternate_code_directories; // per-slot complete generated CD settings
    std::map<uint32_t, std::vector<uint8_t>> special_slot_data; // slot number 1..11 -> bytes to hash
    std::map<uint32_t, std::vector<uint8_t>> embedded_blobs;   // SuperBlob index -> complete generic Blob
    std::vector<uint8_t> raw_cms_der;               // optional detached CMS over primary CodeDirectory
    std::vector<uint8_t> raw_superblob;             // optional complete embedded SuperBlob; validated after embedding
    std::string entitlements_xml;                   // optional inline XML plist input
    std::string requirements_expression;            // optional inline designated requirement expression
    std::vector<uint8_t> requirements_blob;          // optional complete Requirements blob
    bool enabled = false;
};

struct CertificateChainOptions {
    // Disabled by default: existing ldid behavior checks CMS mathematics only.
    bool enabled = false;
    // Require the verified chain returned by OpenSSL to terminate at a self-signed root.
    bool require_root = false;
    // Optional additional trust anchors. Default platform/OpenSSL trust paths are also loaded.
    std::string ca_file;
    std::string ca_path;
    // 0 means current time; nonzero is a Unix timestamp used for path validation.
    int64_t verification_time = 0;
};

// Apple-internal iOS app signing still relies on an Apple-issued internal
// provisioning profile in the normal device-installation path. This policy
// accepts only a real CMS-wrapped profile carrying AppleInternalProfile=true;
// it never synthesizes an Apple certificate, CMS signature, or platform trust.
struct AppleInternalProfileOptions {
    bool enabled = false;
    // Optional Apple-issued .mobileprovision to copy into the main .app.
    // Each .appex must carry its own embedded.mobileprovision.
    std::string source_path;
    bool embed_profile = true;
    bool require_der_encoded_profile = false;
};

struct VerificationOptions {
    CertificateChainOptions certificate_chain;
};

struct SignOptions {
    std::string input_path;
    std::string output_path;
    std::string identifier;
    std::string team_id;
    std::string certificate_path;
    std::string private_key_path;
    std::string p12_path;
    std::string key_password;
    std::string entitlements_path;
    std::string merge_entitlements_path;
    // -Q: designated-requirement source; -N: full requirements blob/source.
    std::string requirements_path;
    std::string overall_requirements_path;
    std::string requirements_xml;
    std::string arch;
    std::string timestamp_url;
    std::string timestamp_policy;
    HashType hash_type = HashType::SHA256;
    Platform platform = Platform::UNKNOWN;
    // Auto-detect platform from LC_BUILD_VERSION / LC_VERSION_MIN when the
    // caller does not explicitly select one. -P auto enables this behavior.
    bool platform_from_binary = true;
    uint32_t min_os_version = 0;
    uint32_t sdk_version = 0;
    uint32_t cd_flags = 0;
    int64_t timestamp = 0;
    bool adhoc = false;
    bool true_sign = false;
    bool deep = false;
    bool super_deep = false;
    bool force = false;
    bool write_copy = false;
    bool no_overwrite = false;
    bool output_stdout = false;
    bool preserve_entitlements = false;
    bool merge_only = false;
    bool sign_executables_only = false;
    bool library_validation = false;
    bool runtime = false;
    bool linker_signed = false;
    // Explicit 64-bit CodeDirectory execSegFlags override. These bits are
    // metadata/authorization inputs, not a way to bypass kernel policy.
    uint64_t exec_seg_flags_override = 0;
    bool exec_seg_flags_override_set = false;
    bool emit_signing_time = true;
    bool timestamp_enabled = false;
    bool timestamp_required = false;
    std::string timestamp_ca_file;
    std::string timestamp_ca_path;
    bool timestamp_require_root = false;
    bool merge_entitlements_deep = false;
    // 0 = automatic (bounded to 4 workers); 1 = serial.
    uint32_t jobs = 0;
    CustomSignatureOptions custom_signature;
    AppleInternalProfileOptions apple_internal_profile;
};

struct ArchiveEntryInfo {
    std::string path;
    uint64_t size = 0;
    bool is_directory = false;
    bool is_executable = false;
    bool is_symlink = false;
    bool is_signable = false;
};

struct ArchiveSignPlan {
    std::vector<std::string> macho_paths;
    std::vector<std::string> bundle_paths;
    std::vector<std::string> nested_bundle_paths;
    std::vector<std::string> framework_paths;
    std::string root_dir;
};

struct VerificationResult {
    bool ok = false;
    std::string message;
    std::vector<std::string> errors;
    std::vector<std::string> warnings;
    explicit operator bool() const {
        return ok;
    }
};

struct StreamingSignContext {
    enum class Mode {
        FULL_EXTRACT,
        PASSTHROUGH,
        INPLACE
    };
    Mode mode = Mode::FULL_EXTRACT;
    std::filesystem::path work_dir;
    ArchiveSignPlan plan;
    SignOptions options;
};

std::vector<uint8_t> read_file(const std::filesystem::path& path);
bool write_file(const std::filesystem::path& path, const std::vector<uint8_t>& data);
std::string read_text(const std::filesystem::path& path);
bool write_text(const std::filesystem::path& path, const std::string& text);
std::string to_hex(const std::vector<uint8_t>& data);
std::vector<uint8_t> from_hex(const std::string& hex);
std::string default_identifier_from_path(const std::filesystem::path& path);

class CryptoEngine {
public:
    static std::vector<uint8_t> sha1(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> sha256(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> hash(HashType type, const std::vector<uint8_t>& data);
    static std::vector<uint8_t> sign_pkcs7(const std::vector<uint8_t>& data, const std::string& cert_path, const std::string& key_path, const std::string& password);
    static bool verify_pkcs7(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature);
    static std::vector<uint8_t> build_apple_cdhash_attr(const std::vector<uint8_t>& cd_hash, HashType hash_type);
    static std::vector<std::vector<uint8_t>> extract_certs_raw(const std::string& cert_path);
};

class KeychainManager {
public:
    static bool load_p12(const std::string& path, const std::string& password, std::vector<uint8_t>& cert_der, std::vector<uint8_t>& key_der);
    static std::string extract_team_id_from_certificate_file(const std::string& cert_path);
    static std::string extract_team_id_from_p12(const std::string& p12_path, const std::string& password);
    static std::vector<uint8_t> get_public_key_hash(const std::string& cert_path);
};

class MachOParser {
public:
    static bool is_macho(const std::vector<uint8_t>& data);
    static std::vector<Slice> parse_slices(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> select_slice(const std::vector<uint8_t>& data, const std::string& arch);
    static SignatureInfo get_signature_info(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> strip_signature(const std::vector<uint8_t>& data);
    static std::vector<uint8_t> embed_signature(const std::vector<uint8_t>& data, const std::vector<uint8_t>& signature);
    static std::vector<uint8_t> rebuild_fat(const std::vector<std::vector<uint8_t>>& slices);
};

class BlobBuilder {
public:
    static std::vector<uint8_t> make_blob(BlobMagic magic, const std::vector<uint8_t>& data);
    static std::vector<uint8_t> build_superblob(const std::map<uint32_t, std::vector<uint8_t>>& blobs);
    static std::vector<uint8_t> build_code_directory(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags);
    static std::vector<uint8_t> build_cd_versioned(const std::vector<uint8_t>& code, const std::string& identifier, const std::string& team_id, HashType hash_type, uint32_t flags, uint32_t version);
    static std::vector<uint8_t> build_entitlements_blob(const std::string& xml);
    static std::vector<uint8_t> build_der_entitlements_blob(const std::string& xml);
    static std::vector<uint8_t> build_requirements_blob(const std::string& identifier, const std::string& team_id);
    static std::vector<uint8_t> build_dr(const std::string& identifier, const std::string& team_id);
    static std::vector<uint8_t> compile_requirements(const std::string& xml);
    static std::vector<uint8_t> der_encode_plist_xml(const std::string& xml);
};

class ArchiveEngine {
public:
    static bool is_archive(const std::filesystem::path& path);
    static ArchiveFormat detect_format(const std::filesystem::path& path);
    static std::vector<ArchiveEntryInfo> list_contents(const std::filesystem::path& path);
    static std::vector<ArchiveEntryInfo> scan_for_signables(const std::filesystem::path& dir);
    static void extract_archive(const std::filesystem::path& archive_path, const std::filesystem::path& out_dir);
    static void create_archive(const std::filesystem::path& dir, const std::filesystem::path& out, ArchiveFormat format);
    static void create_ipa(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void create_zip(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void create_tar(const std::filesystem::path& dir, const std::filesystem::path& out);
    static void extract_ipa(const std::filesystem::path& ipa, const std::filesystem::path& dir);
    static void repack_ipa(const std::filesystem::path& dir, const std::filesystem::path& out);
    static std::filesystem::path find_app_bundle(const std::filesystem::path& dir);
    static std::filesystem::path find_executable_in_bundle(const std::filesystem::path& bundle);
    static void stream_sign(const std::filesystem::path& in, const std::filesystem::path& out, const SignOptions& options);
};

class Signer {
public:
    static void sign(const std::filesystem::path& path, const SignOptions& options);
    static std::vector<uint8_t> sign_memory(const std::vector<uint8_t>& data, const SignOptions& options);
    static void unsign(const std::filesystem::path& path);
    static void unsign_deep(const std::filesystem::path& path);
    static std::vector<uint8_t> unsign_memory(const std::vector<uint8_t>& data);
    static void reset_cryptid(const std::filesystem::path& path);
    static void deep_sign(const std::filesystem::path& path, const SignOptions& options);
    static void super_deep_sign(const std::filesystem::path& path, const SignOptions& options);
    static void merge_entitlements(const std::filesystem::path& path, const SignOptions& options);
    static void sign_ipa(const std::filesystem::path& ipa, const std::filesystem::path& out, const SignOptions& options);
    static void sign_archive(const std::filesystem::path& archive, const std::filesystem::path& out, const SignOptions& options);
    static void sign_bundle(const std::filesystem::path& bundle, const SignOptions& options);
    static void sign_plan(const ArchiveSignPlan& plan, const SignOptions& options);
};

class Verifier {
public:
    static VerificationResult verify(const std::filesystem::path& path);
    static VerificationResult verify(const std::filesystem::path& path, const VerificationOptions& options);
    static VerificationResult verify_memory(const std::vector<uint8_t>& data);
    static VerificationResult verify_memory(const std::vector<uint8_t>& data, const VerificationOptions& options);
    static VerificationResult verify_with_system(const std::filesystem::path& path);
    static VerificationResult verify_bundle(const std::filesystem::path& bundle);
    static VerificationResult verify_bundle(const std::filesystem::path& bundle, const VerificationOptions& options);
    static VerificationResult verify_archive(const std::filesystem::path& archive);
    static VerificationResult verify_archive(const std::filesystem::path& archive, const VerificationOptions& options);
};

class Display {
public:
    static void display_info(const std::filesystem::path& path);
    static void display_signature(const std::filesystem::path& path);
    static void display_entitlements(const std::filesystem::path& path);
    static void display_requirements(const std::filesystem::path& path);
    static void display_cdhash(const std::filesystem::path& path);
    static void display_archive_contents(const std::filesystem::path& path);
    static void display_certificates(const std::filesystem::path& path);
};

// The in-process iosinject utility is integrated as an optional ldid subcommand.
// It edits Mach-O load commands, signs, and verifies through ldid APIs without spawning helper executables:
//   ldid --iosinject [iosinject-options] App.app payload...
namespace iosinject {
int run(int argc, char** argv);
}

}

#endif