# ldid — Custom Code Signature CLI / Verification Enhancements

本版本保持 `ldid.cpp` + `ldid.hpp` 双文件结构和命令行界面。它把代码签名分成两个正交维度：

1. **签名身份/分发类别**：App Store、TestFlight、Apple Development、Ad Hoc、Enterprise/In-House、Apple 系统组件候选、Ad-hoc/local signing 等。
2. **签名载荷/结构变体**：Mach-O SuperBlob、CodeDirectory、Alternate CodeDirectory、CMS/PKCS#7、Requirements、XML/DER Entitlements、CodeResources、Launch Constraints、Linkage Metadata、Detached Signature 等。

分类依赖文件中可观察到的证书主题、CMS、Provisioning Profile、Entitlements、Bundle 元数据及路径证据。**不能仅凭某个 CodeDirectory flag、Team ID 或 CMS 存在，就证明 App Store/企业/Apple 系统身份。** Apple 内核的 `CS_PLATFORM_BINARY` 和 validation category 是运行时信任状态，不是用户可写入的签名字段。

## 1. 本次新增/修正

- CodeDirectory v2.0.1–v2.6 解析与结构检查；主 CodeDirectory 和 Alternate slots `0x1000`–`0x1004` 分别检查。
- SHA-1、SHA-256、SHA-256-truncated、SHA-384；CMS 的 digest algorithm 在签名时显式绑定主 CodeDirectory hash type（SHA-256-truncated 对应完整 SHA-256 CMS digest）。
- XML Entitlements 与 DER Entitlements 结构、哈希和语义一致性检查；iOS/tvOS/watchOS/bridgeOS 现代目标在 XML Entitlements 存在时要求 DER slot，并检查空/全零 DER。
- Special slots：Info.plist 与 CodeResources 在 Bundle 验证阶段逐架构比对；Requirements、Application、RepSpecific、Entitlements、DER Entitlements 和 Launch Constraint slots 在 Mach-O 验证阶段检查。
- CMS 数学签名验证与证书链信任验证分离。证书链默认关闭，可选使用 OpenSSL 默认 trust paths 和额外 CA file/path；可选择额外要求链终止在自签根证书。
- TSA 响应在签名时校验状态、nonce、messageImprint、CMS 签名、timestamping EKU/ESS；`--timestamp-required` 强制 TSA 链验证。可额外指定 TSA CA 和根证书要求。
- Provisioning Profile：检查 CMS 数学签名、可选证书链、过期时间、TeamIdentifier、ApplicationIdentifier、设备列表、ProvisionsAllDevices、get-task-allow、DeveloperCertificates 与签名者匹配、应用 Entitlements 允许列表。
- `--merge-deep`：递归合并嵌套 plist 字典；标量和数组由 overlay 替换，不执行猜测式数组 union。
- `--check-amfi`：静态预检目标平台、DER Entitlements、私有 Entitlements、调试/JIT/动态代码签名等风险和 ad-hoc/TrustCache 提示。它不会模拟真实内核 AMFI，也不会承诺设备一定可安装/启动。
- `--signature-diff`：按相对路径和架构比较签名信息。
- `--json`、`--quiet`：结构化 JSON 与 CI 友好输出；signature-inspect JSON 包含逐文件/逐架构数据、CMS signer/attribute OID、Profile 和分类证据。
- `LDID_CONFIG` / `~/.ldidrc` / `--config` / `--profile` 配置。
- `--jobs`：独立 Mach-O 和 Fat slices 并行签名；嵌套 Bundle 仍按依赖顺序签名。
- `--strip-codesig --deep`：递归剥离 Bundle 树中 Mach-O 签名和 `_CodeSignature` 目录。
- `-M`：支持 Mach-O、Bundle 和 Archive/IPA 的保留/合并 Entitlements 后重签。
- `iosinject` 在进程内修改 Mach-O load commands，并在 staging Bundle 上完成注入、签名和可选验证后再提交；不启动外部 `insert_dylib`、`ldid` 或 `clang` 进程。
- `PLIST_REAL` 不再错误地序列化为字符串 DER；不支持的类型明确报错。临时目录创建有重试上限。无法准确重建的 CodeResources requirement 不再生成伪造的 DR 字符串，而是省略可选字段。

## 2. 证书链验证（默认关闭）

默认行为仍然只检查 CMS 数学签名和相关代码摘要，不进行证书链信任判断。

```bash
# CMS 数学签名/代码哈希，不做证书链检查（默认）
ldid --signature-validate MyApp.app

# 使用 OpenSSL 默认 trust paths 检查所有 CMS signer 的证书链
ldid --signature-validate MyApp.app --verify-chain

# 检查证书链，并额外要求验证路径终止于链中包含的自签根证书
ldid --signature-validate MyApp.app --verify-chain-root

# 指定额外 CA 文件或 CA 目录；显式指定即启用链验证
ldid --signature-validate MyApp.app --ca-file roots.pem
ldid --signature-validate MyApp.app --ca-path ./ca-directory

# 按指定 Unix 时间验证证书有效期
ldid --signature-validate MyApp.app --verify-chain --verify-time 1761868800

# 显式关闭链验证（覆盖配置文件里的 verifyChain=true）
ldid --signature-validate MyApp.app --no-verify-chain
```

选项语义：

- `--verify-chain`：启用 X.509 path validation，信任锚来自 OpenSSL 默认路径和显式 CA 来源。
- `--verify-chain-root`：隐含启用链验证，并额外要求返回的验证路径最后一张证书为链中包含的自签根证书。
- `--ca-file FILE` / `--ca-path DIR`：加载额外 trust anchors；不是把任意中间证书自动当成可信根。
- `--verify-time UNIX`：指定历史验证时间；不传则使用当前时间。
- `--no-verify-chain`：关闭链检查并清除 root 要求。
- 链验证仅适用于带 CMS/SignerInfo 的签名；ad-hoc 或无 CMS 的签名没有证书链，报告为 `N/A`，不会把“无证书”伪装成“链验证通过”。
- `--verify-chain-root` 额外要求 OpenSSL 构建出的验证路径最后一张证书为可验证的自签根证书；若验证路径被信任中间 CA 截断、未包含自签根，按设计失败。

**重要**：指定自定义 CA 代表“按这组信任锚验证”，不等于 Apple 官方信任。要判断 Apple Developer/Distribution 身份，必须使用正确的 Apple CA 集合。iOS 设备上的 OpenSSL 默认 CA 路径也未必等同于 iOS Keychain/System Trust；在没有可用默认根证书时，请提供可信 CA 文件/目录。

传统验证命令也支持这些选项：

```bash
ldid --verify --verify-chain MyBinary
ldid --verify --verify-chain-root MyBinary
```

## 3. RFC 3161 时间戳

```bash
ldid -S -K identity.p12 \
  --timestamp-url https://tsa.example.invalid \
  --timestamp-required \
  --timestamp-ca-file tsa-roots.pem \
  --timestamp-require-root \
  MyBinary
```

- `--timestamp-required` 会让没有有效 TSA 响应、nonce/imprint 不匹配、TSA CMS 签名/ESS/EKU 错误或 TSA 链不可信时签名失败；此模式会强制启用 TSA 证书链验证，即使普通代码签名证书链检查默认关闭。
- `--timestamp-ca-file` / `--timestamp-ca-path` 提供 TSA 信任锚。
- `--timestamp-require-root` 除链验证外，还要求链中包含自签根。
- 普通 `signingTime` CMS 属性与 RFC 3161 时间戳是不同功能。

## 4. Custom Signature Template

```bash
# 导出默认空白模板
ldid --signature-template custom.json

# 检查模板字段、类型、版本和互斥项
ldid --signature-template-check custom.json

# 从模板签名并在签名后验证
ldid --signature-apply custom.json MyApp.app MyApp.custom.app \
  --p12 identity.p12 --password "$P12_PASSWORD"

# 对签名输出额外启用证书链/root 验证
ldid --signature-apply custom.json MyApp.app MyApp.custom.app \
  --p12 identity.p12 --password "$P12_PASSWORD" \
  --verify-chain-root --ca-file apple-roots.pem
```

模板字段默认为空/Auto。空字符串表示由 ldid 依据文件和其他配置生成，不表示将字段强制写成 0。未知 SuperBlob Blob 可以作为原始数据导入/保留；不理解其语义的结构不会被标成“已完整验证”。

## 5. 分析、完整检查、差异和 JSON

```bash
# 查看分类表和签名格式表
ldid --signature-catalog

# 详细分析所有文件/架构
ldid --signature-inspect MyApp.app

# 完整检查结构、代码页哈希、特殊 slots、CMS、资源封套和 Profile 关联
ldid --signature-validate MyApp.app

# 真正结构化 JSON（不是单纯把文本报告塞进字段）
ldid --signature-inspect MyApp.app --json
ldid --signature-validate MyApp.app --verify-chain-root --ca-file roots.pem --json

# CI quiet 模式：成功时只输出 PASS；失败输出诊断并返回非零状态
ldid --signature-validate MyApp.app --quiet

# 比较重签前后两个应用
ldid --signature-diff Original.app Resigned.app
ldid --signature-diff Original.ipa Resigned.ipa --json
```

JSON report 的主要字段包括：文件相对路径、架构/CPU subtype、identifier、Team ID、cdhash、CMS 状态、XML/DER Entitlements、Requirements、CodeDirectory 版本/flags/hash/page size/code limit、Alternate CodeDirectories、CMS signer subject/fingerprint/有效期/算法/属性 OID、Provisioning Profile 证据、签名分类 evidence/limitations、SuperBlob slots 和完整文本诊断。

Detached Signature 没有目标 executable 时，工具只能验证其结构/CMS；Code-page hashes 会明确标为未检查，`--signature-validate` 返回 `INCOMPLETE`，不能伪装成完整通过。

## 6. AMFI 静态预检

```bash
ldid --check-amfi MyApp.app --target-ios 18.0 --target-chip A16
ldid --check-amfi MyApp.app --target-ios 18.0 --target-chip A16 --verify-chain --json
```

返回状态：

- `STATIC_BLOCKED`：文件静态结构/已知规则出现阻断项。
- `STATIC_REVIEW`：有无法离线确定的风险或警告。
- `NO_STATIC_BLOCKERS`：未发现已编码的静态阻断项。

它不执行设备安装、不读取 TrustCache、不调用真实 AMFI，也无法知道特定 OS build、设备策略、Apple 私有例外或系统运行时状态。`NO_STATIC_BLOCKERS` 不等于“保证能安装/启动”。

## 7. 配置文件与 profiles

配置来源优先级：命令行参数覆盖 profile，profile 覆盖 `defaults`。默认路径是 `$HOME/.ldidrc`；可用 `LDID_CONFIG=/path/file.json` 或 `--config FILE` 覆盖。

```json
{
  "defaults": {
    "hashType": "sha256",
    "jobs": 4,
    "verifyChain": false,
    "verifyChainRoot": false
  },
  "profiles": {
    "trollstore": {
      "adhoc": true,
      "deep": true,
      "preserveEntitlements": true,
      "hashType": "sha256",
      "jobs": 4,
      "verifyChain": false
    },
    "developer-check": {
      "verifyChain": true,
      "verifyChainRoot": true,
      "caFile": "/path/to/trusted-roots.pem"
    }
  }
}
```

```bash
LDID_CONFIG="$HOME/.ldidrc" ldid --profile trollstore -S -M MyBinary
ldid --config ./ci-ldid.json --profile developer-check --verify MyApp.app
```

## 8. Entitlements / Bundle / 并行 / 剥离

```bash
# 递归合并嵌套字典；overlay 中同名数组和标量替换原值
ldid -S overlay.plist --merge-deep -M -K identity.p12 MyApp.app

# 递归剥离 Bundle 树中的 Mach-O 签名和 _CodeSignature 资源目录
ldid --strip-codesig --deep MyApp.app

# 自动选择线程数（实现有上限）；1 表示串行
ldid -S -K identity.p12 --jobs 4 MyApp.app
ldid -S -K identity.p12 --jobs 1 MyApp.app

# 只重签指定 Fat slice；未选择的 slices 原样保留并会输出警告
ldid -S -K identity.p12 -A arm64 UniversalBinary
```

Bundle 签名的依赖顺序不会被并行化打乱：嵌套代码先签，随后生成 CodeResources，最后签父 Bundle executable。独立 Mach-O 文件和独立 Fat slices 可以并行。`-A` 只对匹配架构重新签名；其他 slice 保留原数据/原签名，用户需要自行确认混合签名架构是否符合分发目标。

`-M` 在没有新 Entitlements 输入时保留已有 Entitlements 并重签；有 `-S FILE` 或 merge source 时可执行合并。对 Bundle/Archive/IPA 同样应用成员级保留/合并逻辑。

## 9. 签名身份分类边界

分类器输出证据和 limitations：

- Development / Ad Hoc / In-House Profile 可以根据 `ProvisionedDevices`、`ProvisionsAllDevices`、`get-task-allow` 识别 profile 声明类型。
- App Store Connect 的 profile 形态不证明最终从 App Store 下载；已安装的 App Store 应用通常没有 embedded profile。
- Apple iPhone OS Application Signing 证书主题可以作为 Apple-managed signing 候选证据，但仅靠 Mach-O 通常无法区分 App Store 与 TestFlight。
- Apple 系统路径/Apple 证书主题都只是候选证据。`CS_PLATFORM_BINARY` 和 XNU validation category 是 kernel/runtime 状态。
- 本版本刻意不启用证书链检查作为默认行为；若链检查开启，结论只针对当前配置的 OpenSSL trust store。

## 10. 本版本明确保留的限制

- 不验证证书链，除非用户显式加 `--verify-chain` 或 `--verify-chain-root`；默认始终关闭。
- 不把 `--check-amfi` 描述成真实设备 AMFI 模拟。
- `DER-Encoded-Profile` 当前报告存在性/长度；profile 主体仍以 CMS payload plist 为语义来源，未将 DER profile 所有字段做完整的双向语义比较。
- Requirements 已支持现有表达式编译/显示子集和原始 Blob 校验；未来未知 opcode 可保留，但不声称理解其语义。
- Launch Constraints/LWCR 的结构和特殊槽位有检查；未来新策略语义不受支持时会标记为未知/不完整。
- CodeResources 会校验已实现的 `files`/`files2` 哈希、符号链接、嵌套 cdhash、Info.plist 和 CodeResources special hashes；未知规则键/未来规则方言不自动解释为有效。
- CodeDirectory v2.6 是 XNU 定义的布局；目标 iOS 版本是否接受仍应通过该系统版本的真实验证器/设备测试。
- CMS 签名生成保持单 SignerInfo；多 SignerInfo 可分析，但不作为通用模板生成能力。
- `--verify-chain-root` 要求链中包含自签根；当信任锚配置为受信任中间证书或平台把路径截断在中间证书时，该模式会按设计失败。

## 11. 构建检查说明

本源码在当前编辑环境使用 Clang C++20 `-fsyntax-only -Wall -Wextra -Wpedantic -Werror` 检查通过。环境没有真实 libplist 开发头/库，因此该检查使用临时 API 声明桩，不代表完整静态链接通过。GitHub Actions 的 macOS/Xcode 全量链接、最终 iOS 16.5 SDK 元数据验收，以及真实设备安装/启动仍需由 CI 和设备验证。
