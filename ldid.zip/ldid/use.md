ldid — iOS 代码签名工具

目录

· 构建
· 基本用法
· 命令行选项速查
· 常见场景
· CodeDirectory flags
· 时间戳签名
· 验证
· iosinject 子命令
· 限制与注意事项

---

构建

依赖库：

· OpenSSL 3.x
· libplist
· libcurl
· libarchive
· libbz2 / liblzma / zlib / libxml2

Theos 交叉编译示例：

```make
THEOS ?= ./theos
TARGET := iphone:clang:16.5:16.0
ARCHS := arm64
TOOL_NAME := ldid
ldid_FILES := ldid.cpp
include $(THEOS)/makefiles/common.mk
include $(THEOS_MAKE_PATH)/tool.mk
```

产物为 Mach-O arm64 可执行文件，可放到越狱设备或 TrollStore 使用。

---

基本用法

```
ldid [选项] file...
```

file 可以是：

· 单个 Mach-O 可执行文件 / dylib / framework 二进制
· 一个 .app / .framework / .appex / .xpc / .plugin / .kext bundle 目录
· 一个包含多个可签名目标的普通目录
· 一个 .ipa / .zip / .tar 归档

不带任何选项时，只显示文件信息（等价于 -d）。

---

命令行选项速查

签名

选项 说明
-S[file.xml] 签名。可附带 entitlements XML。不跟文件名时表示保留已有 entitlements
-s 用现有 entitlements 重新签名
-M merge-only：保留已有 entitlements 并重签。可单独使用
-K<file.p12> 使用 PKCS#12 证书 + 私钥签名
--cert <file.pem> / --certificate <file.pem> 使用 PEM/DER 证书签名（需配合 --key）
--key <file.pem> / --private-key <file.pem> 指定 PEM 私钥（需配合 --cert）
-U<password> .p12 或加密私钥的密码
-I<identifier> 设置 CodeDirectory identifier
-t<TeamID> 设置 team ID
-Q<file> designated requirement 源文件（XML/DER，无 0xfade0c01 头部的 requirements 文本）
-N<file> 完整 requirements：0xfade0c01 superblob 直接使用，否则按源文本编译
-C<flags> 设置 CodeDirectory flags，逗号或空格分隔
-H[hash] 主 hash 算法：sha1 / sha256 / sha256-truncated / sha384（不带参数等价 sha256）
-A<arch> 目标架构，如 arm64 / arm64e / x86_64。若二进制中没有该架构，报错
-arch <arch> 同 -A
-P<platform> platform：ios / macos / tvos / watchos / bridgeos / maccatalyst / iossimulator / tvossimulator / watchossimulator / driverkit
-a 生成 ad-hoc 签名（无 CMS；无证书时自动等价 ad-hoc）
--true-sign 额外输出 Apple cdhashes (1.2.840.113635.100.9.2) 属性
--deep 递归签名嵌套 bundle（1 层）
--super-deep 无深度限制地递归签名
--min-os <version> CodeDirectory 的 runtime 版本（如 16.0）。仅在 --runtime 时生效

注意

· 未提供 -K / --cert 时，签名自动标记为 ad-hoc（CS_ADHOC）。
· --min-os 不会改写 LC_BUILD_VERSION；它只影响 CodeDirectory 的 runtime 字段。

时间戳

选项 说明
--timestamp 启用 RFC 3161 时间戳
--timestamp-url=<url> 指定 TSA 服务地址
--timestamp-url <url> 同上
-T<url> 同上（兼容老式写法，需包含 ://）
--timestamp-required 时间戳失败时报错退出
--timestamp-policy=<oid> TSA policy OID
--no-timestamp 关闭时间戳（默认行为；不影响 signingTime）
--no-signing-time 不写出 PKCS9 signingTime 属性（与时间戳无关）

去除与重置

选项 说明
-r 移除已有签名
--reset-cryptid 将 LC_ENCRYPTION_INFO* 的 cryptid 重置为 0

输出控制

选项 说明
-w 原地覆盖写入（等价于默认行为；保留以兼容）
-n 不覆盖原文件，自动生成 <file>.signed / <file>-N.signed
-O 输出到 stdout
--force 强制写入（临时加上 owner_write 位）

信息与验证

选项 说明
-d 显示文件信息（默认）
-e 显示 entitlements
-q / -D 显示 requirements（人类可读）
-h 显示 cdhash
--verify 校验签名（CodeDirectory、alternate CD、special slots、CMS、资源封条）；不校验 Apple 信任链
-v / --version 显示版本

子命令

选项 说明
--iosinject ... 调用集成 iosinject：ldid --iosinject [opts] App.app payload...（见下文）

---

常见场景

1. 用 entitlements XML 签名

```bash
ldid -Sent.xml MyApp
```

2. 用 p12 证书 + entitlements 签名

```bash
ldid -S -Kcert.p12 -U"password" App.app
```

3. 用 PEM 证书 + 私钥签名

```bash
ldid -S --cert cert.pem --key key.pem App.app
```

证书或私钥加密时可用 -U 提供密码：

```bash
ldid -S --cert cert.pem --key key.pem -U"password" App.app
```

4. 用 p12 保留已有 entitlements 重签

```bash
ldid -S -M -Kcert.p12 -U"password" App.app
```

5. 不带证书的 ad-hoc 签名

```bash
ldid -S -a App.app
# 或（无证书自动 ad-hoc）
ldid -S App.app
```

6. 深度签名 App bundle 内的所有嵌套

```bash
ldid -S -Kcert.p12 --deep MyApp.app
```

7. 保留已签名内容、只换证书

```bash
ldid -S -M -Knewcert.p12 -U"password" MyApp.app
```

8. 对整个 .ipa 签名

```bash
ldid -S -Kcert.p12 MyApp.ipa
```

流式处理，不会先把整包解压到磁盘。

9. 对目录树中所有可签名文件签名

```bash
ldid -S -Kcert.p12 Payload/
```

10. 移除签名

```bash
ldid -r MyBinary
```

11. 重置 cryptid

```bash
ldid --reset-cryptid MyBinary
```

12. 用 SHA-384 签名

```bash
ldid -S -Hsha384 -Kcert.p12 MyApp
```

13. 只签名主可执行文件，不动嵌套

```bash
ldid -S -Kcert.p12 MyApp.app/MyApp
```

14. 指定 designated requirement 源

```bash
ldid -S -Qreq.txt -Kcert.p12 MyApp
```

-Q 接受 DSL 源文本（如 identifier "com.example.app" and anchor apple generic），会编译成单条 DR。

15. 指定完整 requirements superblob

```bash
ldid -S -Nfull-req.blob -Kcert.p12 MyApp
```

-N 若输入以 0xfade0c01 开头，直接作为 requirements 使用；否则按源文本编译。

16. 输出到 stdout

```bash
ldid -S -O MyBinary > MyBinary.signed
```

17. 不覆盖原文件

```bash
ldid -S -n MyBinary
# 生成 MyBinary.signed（如已存在会生成 MyBinary-1.signed）
```

---

CodeDirectory flags

通过 -C 传入，多个用逗号或空格分隔。加 no- 前缀表示清除对应位。

Flag 值 说明
host 0x1 允许作为 host 进程
adhoc 0x2 ad-hoc 签名
hard 0x100 强制
kill 0x200 违规即杀进程
expires / check-expiration 0x400 检查过期
restrict 0x800 受限
enforcement 0x1000 强制
library-validation 0x4000 库校验
runtime 0x10000 hardened runtime
linker-signed 0x20000 linker-signed

示例：

```bash
ldid -S -C"runtime,library-validation" -Kcert.p12 MyApp
ldid -S -C"no-runtime" -Kcert.p12 MyApp
```

adhoc flag 在无证书签名时会自动设置，即使未显式写 -C adhoc。

---

时间戳签名

默认行为

· 不写 RFC 3161 时间戳。
· PKCS9 signingTime 默认写出。

启用时间戳

```bash
ldid -S -Kcert.p12 \
     --timestamp \
     --timestamp-url=http://timestamp.apple.com/ts01 \
     MyApp
```

强制时间戳成功

```bash
ldid -S -Kcert.p12 \
     --timestamp-required \
     --timestamp-url=http://timestamp.apple.com/ts01 \
     MyApp
```

指定 policy OID

```bash
ldid -S -Kcert.p12 \
     --timestamp \
     --timestamp-url=http://timestamp.apple.com/ts01 \
     --timestamp-policy=1.2.3.4.5 \
     MyApp
```

关闭 signingTime，但保留时间戳

```bash
ldid -S -Kcert.p12 --timestamp --timestamp-url=... --no-signing-time MyApp
```

时间戳验证

TSA 响应会被校验：

· status == granted 或 grantedWithMods
· nonce 与请求一致
· msgImprint 与请求的 SHA-256 一致
· token 必须是单个 DER SEQUENCE

token 作为 1.2.840.113549.1.9.16.2.14 属性加入 CMS signer info。

---

验证

基本校验

```bash
ldid --verify MyApp
```

校验内容：

· Mach-O 结构与 LC_CODE_SIGNATURE 有效性
· SuperBlob 结构完整性（含 offset/length 与重复槽检查）
· CodeDirectory：
  · 版本、hash 算法、page size
  · 每个 code slot 的 hash
  · 所有 alternate CodeDirectory（槽位 0x1000 .. 0xFFFF）
  · alternate CD 的 special slots 同步校验
  · special slots（Info.plist、requirements、entitlements、DER entitlements、CodeResources）
· designated requirement 与 CodeDirectory 的 identifier / team ID 一致性
· CMS PKCS#7 签名（若存在）

输出成功信息时会提示：

```
<path>: valid (signature format/integrity checked; certificate chain not verified)
```

bundle 验证

```bash
ldid --verify MyApp.app
```

额外校验：

· _CodeSignature/CodeResources 可读且为合法 plist
· files（v1）与 files2（v2）中的两套记录都被校验
· 未在封条中的资源被封条遗漏时报错
· 嵌套 bundle 的 cdhash 与 files2 记录一致
· CodeResources 自身在 CodeDirectory special slot 3 中的 hash

归档验证

```bash
ldid --verify MyApp.ipa
```

自动解压并对其中的所有可签名目标验证。

显示信息

```bash
ldid -d MyApp                  # 基础信息（fat 二进制按架构分别展示）
ldid -e MyApp                  # entitlements
ldid -q MyApp                  # requirements
ldid -h MyApp                  # cdhash
ldid -e -q -h -d MyApp         # 全部
```

---

iosinject 子命令

ldid --iosinject 是集成到 ldid 的 iosinject（VERSION 2.0）实现，可对 .app 注入 dylib / framework / xcframework / .deb / 静态库。

用法

```
ldid --iosinject [options] App.app payload...
```

payload 支持：

· .dylib
· .framework（整个目录）
· .xcframework
· .deb（自动解出 data/ 里的 Mach-O）
· .a（通过 clang -dynamiclib -force_load 编译成 dylib）

选项

选项 说明
--ldid PATH 使用的 ldid 可执行文件（默认 ldid）
--entitlements PATH 主可执行文件使用的 entitlements
--output PATH 输出 .app 路径
--inplace 原地修改输入 .app
--overwrite 允许覆盖已存在的输出
--sign 注入后签名整棵 app 树
--verify 注入后校验主可执行文件
--strip-codesig 注入前先 strip 主可执行文件的签名
--weak 弱链接（传递给 insert_dylib --weak）
--force 传递给 ldid 的 --force
--preserve-metadata 嵌套二进制重签时保留元数据（传递 -s）
--deep 递归深度 64
--super-deep 递归深度 256
--dry-run 只打印将执行的动作
--verbose 打印子进程命令
--help 显示帮助

依赖

· insert_dylib（当注入需要修改 LC_LOAD_DYLIB 时）
· clang（当 payload 是 .a 静态库时）

示例

```bash
# 注入 dylib 并签名（输出到 <app>.injected.app）
ldid --iosinject --sign --entitlements ent.xml MyApp.app Inject.dylib

# 原地注入 + strip 原签名 + 立即签名
ldid --iosinject --inplace --strip-codesig --sign MyApp.app Inject.framework

# 从 .deb 注入
ldid --iosinject --sign --overwrite --output /tmp/Out.app MyApp.app tweak.deb

# 预览
ldid --iosinject --dry-run MyApp.app Inject.dylib
```

未指定 --output 且未指定 --inplace 时，默认输出到 <原 app 名>.injected.app（已存在则报错，除非 --overwrite）。

---

限制与注意事项

签名时

· -Q 与 -N 的区别：-Q 用于单条 designated requirement 源文本；-N 可以接受完整 requirements superblob 或源文本，且优先级高于 -Q。
· -M 保留既有 entitlements：-M 不带外部 entitlements 时表示"保留已有 entitlements"，这与原版 ldid / TrollStore 的兼容行为一致。若提供了 entitlements，则作为 overlay 合并。
· -w / -n / -O 语义：
  · -w 显式原地覆盖（与默认等价，保留以兼容）
  · -n 生成不冲突的 .signed 副本
  · -O 输出到 stdout
· --deep / --super-deep：--deep 递归 1 层；--super-deep 无深度限制。普通嵌套签名建议显式 --deep。
· .framework / .appex / .xpc 会作为 bundle 处理（生成 Info.plist 和 CodeResources）。
· 主可执行文件只签一次：先生成 _CodeSignature/CodeResources，再把它的 hash 放到 CodeDirectory special slot 3，然后一次签名完成。这样避免了中间状态不一致。
· 嵌套 bundle 顺序确定：使用路径排序 + 最长路径去重，避免 recursive_directory_iterator 的不确定顺序导致嵌套 bundle 被签两遍、cdhash 不一致。
· -A 未命中会报错：requested architecture not found: <arch>。若需跳过签名某个 slice，请去掉 -A。
· --min-os 只在 --runtime 时生效：不启用 --runtime 时 --min-os 被忽略，且不会修改 LC_BUILD_VERSION。
· --runtime 的版本回退：若 --runtime 时既没 --min-os、二进制里也没有 LC_BUILD_VERSION，会回退到 0x000A0E00（10.14）。
· -K 与 --cert/--key 不能混用：只能二选一。
· PEM 私钥密码：加密私钥通过 -U 提供。
· iOS 14+ 需要 DER entitlements：Platform::IOS / TVOS / WATCHOS / BRIDGEOS 且 XML entitlements 非空时，会自动同时生成 DER entitlements；若 platform 未指定但原签名含 DER entitlements，也会继续生成。
· P12 加载失败会报根因：文件打不开、密码错误、缺证书/私钥都会抛出带上下文的错误。
· arm64e 建议：--min-os ≥ 14.0 且启用 --runtime。
· simulator 目标：使用 iossimulator / tvossimulator / watchossimulator。

验证时

· --verify 不校验 Apple 信任链（无系统钥匙串信任评估）。校验的是签名结构和自洽性。
· 会完整重算每个 page 的 hash。
· 会校验所有 alternate CodeDirectory（0x1000 .. 0xFFFF），不只是槽位 0x1000。
· 会读取 .app 内所有嵌套 bundle 的签名字段并交叉校验 files2。
· 会同时校验 files（v1）与 files2（v2），避免老系统的封条被跳过。

性能

· 归档签名走流式处理：Mach-O 直接内存签名；非 Mach-O 条目在未知大小时会落盘到临时文件。
· .ipa 默认不做完整解压再打包，除非用到 --deep / --super-deep 且归档内包含 bundle。
· Bundle 树遍历使用 outermost_nested_bundles 一次选出所有顶层嵌套 bundle，避免重复遍历。

兼容性

· 生成的 CodeDirectory 版本根据实际字段自动升级：
  · v0x20001：基础
  · v0x20200：带 team ID
  · v0x20300：带 64 位 code limit（code_limit > 4 GiB 会强制升级）
  · v0x20400：带 exec seg
  · v0x20500：带 runtime
  · v0x20600：带 pre-encrypt
· fat 重建保留原始 align：不再硬编码为 14/12，可正确处理非常规对齐的 universal binary。
· 归档检测：先检查 Mach-O magic，并排除 ARCHIVE_FORMAT_EMPTY/RAW，避免把普通二进制误判为归档。

---

版本

ldid enhanced two-file edition — 提供 ldid.cpp + ldid.hpp 两个源文件即可构建完整工具；内置 --iosinject 子命令。