# ldid in-process tweak injection and signing optimization

## Build

The GitHub Actions workflow is at `.github/workflows/build_libs.yml`. It builds arm64 device static dependencies and `ldid` for the pinned Theos `iPhoneOS16.5.sdk` package. The Mach-O SDK metadata must match the SDKSettings.plist version; the package directory name and the Mach-O recorded SDK version can differ (the iOS 16.5 SDK package records SDK version 16.4).

The workflow uses Release optimization (`-O3`, `-DNDEBUG`, section splitting, ThinLTO where supported), then checks static-library architectures, final platform metadata, unresolved dependencies, and packages the output artifacts. A successful YAML/shell syntax check does not replace a real GitHub macOS build.

## Usage

```sh
ldid --iosinject [options] MyApp.app tweak.dylib
```

Payload types supported in-process: device `.dylib`, `.framework`, `.xcframework`, `.deb`, and `.zip` containing frameworks/dylibs. The output may be an `.app` directory or an `.ipa` archive:

```sh
ldid --iosinject --output MyApp.injected.ipa MyApp.app payload.zip
```

Useful options include `--inplace`, `--overwrite`, `--weak`, `--entitlements PATH`, `--preserve-metadata`, `--deep`, `--super-deep`, `--verify`, `--dry-run`, and `--verbose`.

No external `insert_dylib`, `ldid`, or `clang` process is spawned by the `--iosinject` path. Mach-O load commands are edited through ldid's parser in memory; archive extraction and IPA packaging use the linked libarchive library; signing and verification use ldid's internal code.

Static `.a` archives are intentionally rejected: a static archive is not a dyld-loadable runtime image. Converting an arbitrary static archive into a dylib requires a linker and suitable object/link metadata. Provide a prebuilt device `.dylib` or `.framework` instead of silently invoking an external linker.

## Implementation notes

- The load-command insertion follows the observable `insert_dylib` semantics: `LC_LOAD_DYLIB` or `LC_LOAD_WEAK_DYLIB`, updating `ncmds` and `sizeofcmds`, handling universal/fat slices, and avoiding duplicate commands.
- The parser/buffer-editing approach follows the general ChOma-style in-memory Mach-O manipulation model. This version does not link the ChOma library itself; it uses ldid's existing parser/rebuilder so it can remain a self-contained two-source-file tool.
- When the Mach-O header has insufficient zeroed padding, the injector fails with a diagnostic rather than shifting arbitrary file offsets and risking corruption.
- Independent Mach-O files are signed in parallel (up to four workers). `CodeResources` hashing streams files in 256 KiB chunks and parallelizes independent file hashing while serializing plist writes. IPA ZIP output uses deflate level 1 as a speed/size balance and is published from a temporary file only after success.
- Verification checks signature structure/integrity but deliberately does not verify certificate chains, as requested.

## References

- TrollFools: https://github.com/Lessica/TrollFools
- insert_dylib: https://github.com/tyilo/insert_dylib
- ChOma: https://github.com/opa334/ChOma

The public projects above are references for behavior and design. This implementation does not invoke their command-line tools at runtime.

## Validation performed in the build workspace

- `clang++ -std=c++20 -fsyntax-only -Wall -Wextra -Wpedantic` completed without diagnostics using temporary libplist API declarations because the local workspace does not contain the target iOS libplist development package.
- Synthetic thin Mach-O load-command insertion and idempotence test passed.
- Synthetic two-slice fat Mach-O insertion and idempotence test passed.
- ZIP and Debian `.deb` payload extraction tests passed.
- End-to-end host-side archive extraction/install plus in-process load-command insertion test passed.

A full macOS/Xcode dependency build and on-device app launch/signature acceptance test have not been run in this workspace.
