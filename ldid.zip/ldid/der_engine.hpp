#ifndef LDID_DER_ENGINE_HPP
#define LDID_DER_ENGINE_HPP

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

namespace ldid::der {

struct Limits {
    size_t max_bytes = 32U * 1024U * 1024U;
    size_t max_nodes = 100000U;
    unsigned max_depth = 64U;
};

struct Node {
    unsigned tag_class = 0;       // 0 universal, 1 application, 2 context, 3 private
    uint32_t tag_number = 0;
    bool constructed = false;
    size_t offset = 0;
    size_t header_length = 0;
    size_t content_offset = 0;
    size_t content_length = 0;
    size_t total_length = 0;
    std::vector<Node> children;
};

struct Result {
    bool ok = false;
    std::string error;
    Node root;
    size_t node_count = 0;
};

inline bool is_valid_utf8(const uint8_t* p, size_t n) {
    size_t i = 0;
    while (i < n) {
        const uint8_t c = p[i++];
        if (c <= 0x7f) continue;
        uint32_t cp = 0;
        unsigned need = 0;
        if (c >= 0xc2 && c <= 0xdf) { cp = c & 0x1f; need = 1; }
        else if (c >= 0xe0 && c <= 0xef) { cp = c & 0x0f; need = 2; }
        else if (c >= 0xf0 && c <= 0xf4) { cp = c & 0x07; need = 3; }
        else return false;
        if (need > n - i) return false;
        for (unsigned j = 0; j < need; ++j) {
            const uint8_t t = p[i++];
            if ((t & 0xc0) != 0x80) return false;
            cp = (cp << 6) | (t & 0x3f);
        }
        if ((need == 1 && cp < 0x80) || (need == 2 && cp < 0x800) ||
            (need == 3 && cp < 0x10000) || cp > 0x10ffff ||
            (cp >= 0xd800 && cp <= 0xdfff)) return false;
    }
    return true;
}

inline bool validate_oid_content(const uint8_t* p, size_t n, std::string& error) {
    if (n == 0) { error = "OBJECT IDENTIFIER has empty content"; return false; }
    size_t i = 0;
    while (i < n) {
        if (p[i] == 0x80) { error = "OBJECT IDENTIFIER has a non-minimal base-128 subidentifier"; return false; }
        bool terminated = false;
        while (i < n) {
            const uint8_t b = p[i++];
            if ((b & 0x80) == 0) { terminated = true; break; }
        }
        if (!terminated) { error = "OBJECT IDENTIFIER has an unterminated base-128 subidentifier"; return false; }
    }
    return true;
}


inline bool all_digits(const uint8_t* p, size_t n) {
    for (size_t i = 0; i < n; ++i) if (p[i] < '0' || p[i] > '9') return false;
    return true;
}

inline unsigned decimal_value(const uint8_t* p, size_t n) {
    unsigned value = 0;
    for (size_t i = 0; i < n; ++i) value = value * 10U + static_cast<unsigned>(p[i] - '0');
    return value;
}

inline bool valid_calendar_date(unsigned year, unsigned month, unsigned day) {
    if (month < 1 || month > 12 || day < 1) return false;
    static constexpr unsigned days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    unsigned max_day = days[month - 1];
    const bool leap = (year % 4U == 0U && year % 100U != 0U) || year % 400U == 0U;
    if (month == 2 && leap) max_day = 29;
    return day <= max_day;
}

inline bool valid_der_time(const uint8_t* p, size_t n, bool generalized) {
    const size_t base = generalized ? 14U : 12U;
    if (n < base + 1U || p[n - 1] != 'Z') return false;
    if (!all_digits(p, base)) return false;
    const unsigned year = generalized ? decimal_value(p, 4) : decimal_value(p, 2);
    const size_t date_offset = generalized ? 4U : 2U;
    const unsigned month = decimal_value(p + date_offset, 2);
    const unsigned day = decimal_value(p + date_offset + 2U, 2);
    const unsigned hour = decimal_value(p + date_offset + 4U, 2);
    const unsigned minute = decimal_value(p + date_offset + 6U, 2);
    const unsigned second = decimal_value(p + date_offset + 8U, 2);
    // UTCTime's two-digit year is interpreted per X.509's 1950/2050 rule.
    const unsigned full_year = generalized ? year : (year >= 50U ? 1900U + year : 2000U + year);
    if (!valid_calendar_date(full_year, month, day) || hour > 23U || minute > 59U || second > 59U) return false;
    if (!generalized) return n == base + 1U;
    if (n == base + 1U) return true;
    if (p[base] != '.' || n <= base + 2U) return false;
    const size_t fraction_length = n - base - 2U; // exclude '.' and terminal 'Z'
    if (!all_digits(p + base + 1U, fraction_length)) return false;
    // DER forbids trailing zeroes in a fractional second representation.
    return p[n - 2U] != '0';
}

inline bool valid_printable_string(const uint8_t* p, size_t n) {
    for (size_t i = 0; i < n; ++i) {
        const uint8_t c = p[i];
        const bool alpha_num = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
        const bool punctuation = c == ' ' || c == 0x27 || c == '(' || c == ')' || c == '+' ||
            c == ',' || c == '-' || c == '.' || c == '/' || c == ':' || c == '=' || c == '?';
        if (!alpha_num && !punctuation) return false;
    }
    return true;
}

class Parser {
public:
    Parser(const std::vector<uint8_t>& bytes, Limits limits = {}) : bytes_(bytes), limits_(limits) {}

    Result parse() {
        Result result;
        if (bytes_.empty()) { result.error = "input is empty"; return result; }
        if (bytes_.size() > limits_.max_bytes) { result.error = "input exceeds DER byte limit"; return result; }
        size_t pos = 0;
        if (!parse_node(pos, bytes_.size(), 0, result.root, result.error, result.node_count)) return result;
        if (pos != bytes_.size()) { result.error = "trailing bytes follow the top-level DER value"; return result; }
        result.ok = true;
        return result;
    }

private:
    const std::vector<uint8_t>& bytes_;
    Limits limits_;

    bool parse_node(size_t& pos, size_t end, unsigned depth, Node& node,
                    std::string& error, size_t& count) {
        if (depth > limits_.max_depth) { error = "ASN.1 nesting depth limit exceeded"; return false; }
        if (++count > limits_.max_nodes) { error = "ASN.1 node count limit exceeded"; return false; }
        if (pos >= end || end > bytes_.size()) { error = "truncated ASN.1 tag"; return false; }
        const size_t start = pos;
        const uint8_t first_tag = bytes_[pos++];
        node.tag_class = first_tag >> 6;
        node.constructed = (first_tag & 0x20U) != 0;
        uint32_t tag_number = first_tag & 0x1fU;
        if (tag_number == 0x1fU) {
            tag_number = 0;
            bool first = true, terminated = false;
            while (pos < end) {
                const uint8_t b = bytes_[pos++];
                if (first && (b & 0x7fU) == 0) { error = "non-minimal high-tag-number encoding"; return false; }
                first = false;
                const uint32_t payload = static_cast<uint32_t>(b & 0x7fU);
                const uint32_t maximum = std::numeric_limits<uint32_t>::max();
                if (tag_number > (maximum - payload) / 128U) {
                    error = "ASN.1 tag number overflows uint32"; return false;
                }
                tag_number = tag_number * 128U + payload;
                if ((b & 0x80U) == 0) { terminated = true; break; }
            }
            if (!terminated || tag_number < 31) { error = "invalid high-tag-number encoding"; return false; }
        }
        node.tag_number = tag_number;
        if (pos >= end) { error = "truncated ASN.1 length"; return false; }
        const uint8_t first_length = bytes_[pos++];
        size_t length = 0;
        if (first_length < 0x80U) {
            length = first_length;
        } else {
            const size_t octets = first_length & 0x7fU;
            if (octets == 0) { error = "indefinite length is forbidden in DER"; return false; }
            if (octets > sizeof(size_t) || octets > end - pos) { error = "invalid or truncated long-form length"; return false; }
            if (bytes_[pos] == 0) { error = "long-form length has a leading zero octet"; return false; }
            for (size_t i = 0; i < octets; ++i) {
                if (length > (std::numeric_limits<size_t>::max() >> 8)) { error = "ASN.1 length overflows size_t"; return false; }
                length = (length << 8) | bytes_[pos++];
            }
            if (length < 128) { error = "long-form length used for a value shorter than 128 octets"; return false; }
        }
        if (length > end - pos) { error = "ASN.1 value length exceeds enclosing boundary"; return false; }
        node.offset = start;
        node.header_length = pos - start;
        node.content_offset = pos;
        node.content_length = length;
        node.total_length = node.header_length + length;
        if (node.tag_class == 0 && !validate_universal(node, error)) return false;

        const size_t content_end = pos + length;
        if (node.constructed) {
            while (pos < content_end) {
                Node child;
                if (!parse_node(pos, content_end, depth + 1, child, error, count)) return false;
                node.children.push_back(std::move(child));
            }
            if (pos != content_end) { error = "constructed ASN.1 value is not fully consumed"; return false; }
            if (node.tag_class == 0 && node.tag_number == 17 && !set_is_sorted(node)) {
                error = "SET/SET OF elements are not in DER lexicographic order";
                return false;
            }
        }
        pos = content_end;
        return true;
    }

    bool validate_universal(const Node& n, std::string& error) const {
        const uint8_t* p = bytes_.data() + n.content_offset;
        const size_t len = n.content_length;
        switch (n.tag_number) {
            case 0: error = "end-of-contents tag is not valid in DER"; return false;
            case 1:
                if (n.constructed || len != 1 || (p[0] != 0x00 && p[0] != 0xff)) {
                    error = "BOOLEAN must be primitive, one octet, and encoded as 00 or FF"; return false;
                }
                break;
            case 2: case 10:
                if (n.constructed || len == 0) { error = "INTEGER/ENUMERATED must be primitive and non-empty"; return false; }
                if (len > 1 && ((p[0] == 0x00 && (p[1] & 0x80U) == 0) ||
                                (p[0] == 0xff && (p[1] & 0x80U) != 0))) {
                    error = "INTEGER/ENUMERATED contains redundant sign octets"; return false;
                }
                break;
            case 3:
                if (n.constructed || len == 0 || p[0] > 7 || (len == 1 && p[0] != 0)) {
                    error = "BIT STRING has invalid primitive form or unused-bit count"; return false;
                }
                if (len > 1 && p[0] != 0 && (p[len - 1] & ((1U << p[0]) - 1U)) != 0) {
                    error = "BIT STRING has non-zero unused trailing bits"; return false;
                }
                break;
            case 4:
                if (n.constructed) { error = "OCTET STRING must be primitive under DER"; return false; }
                break;
            case 5:
                if (n.constructed || len != 0) { error = "NULL must be primitive with zero length"; return false; }
                break;
            case 6:
                if (n.constructed || !validate_oid_content(p, len, error)) return false;
                break;
            case 16:
                if (!n.constructed) { error = "SEQUENCE must use constructed encoding"; return false; }
                break;
            case 17:
                if (!n.constructed) { error = "SET must use constructed encoding"; return false; }
                break;
            case 12:
                if (n.constructed || !is_valid_utf8(p, len)) { error = "UTF8String is not valid primitive UTF-8"; return false; }
                break;
            case 18:
                if (n.constructed || std::any_of(p, p + len, [](uint8_t c) { return c != ' ' && (c < '0' || c > '9'); })) {
                    error = "NumericString must be primitive and contain only digits or spaces"; return false;
                }
                break;
            case 19:
                if (n.constructed || !valid_printable_string(p, len)) {
                    error = "PrintableString contains a character outside the ASN.1 PrintableString repertoire"; return false;
                }
                break;
            case 20:
                if (n.constructed) { error = "TeletexString must be primitive under DER"; return false; }
                break;
            case 21:
                if (n.constructed) { error = "VideotexString must be primitive under DER"; return false; }
                break;
            case 22:
                if (n.constructed || std::any_of(p, p + len, [](uint8_t c) { return c > 0x7f; })) {
                    error = "IA5String must be primitive 7-bit ASCII"; return false;
                }
                break;
            case 23:
                if (n.constructed || !valid_der_time(p, len, false)) {
                    error = "UTCTime must be canonical YYMMDDHHMMSSZ with a valid calendar value"; return false;
                }
                break;
            case 24:
                if (n.constructed || !valid_der_time(p, len, true)) {
                    error = "GeneralizedTime must be canonical YYYYMMDDHHMMSS[.fraction]Z"; return false;
                }
                break;
            case 25:
                if (n.constructed) { error = "GraphicString must be primitive under DER"; return false; }
                break;
            case 26:
                if (n.constructed || std::any_of(p, p + len, [](uint8_t c) { return c < 0x20 || c > 0x7e; })) {
                    error = "VisibleString must contain only visible 7-bit ASCII characters"; return false;
                }
                break;
            case 27:
                if (n.constructed) { error = "GeneralString must be primitive under DER"; return false; }
                break;
            case 28:
                if (n.constructed || (len % 4) != 0) { error = "UniversalString must be primitive and have a length divisible by four"; return false; }
                for (size_t i = 0; i < len; i += 4) {
                    const uint32_t cp = (static_cast<uint32_t>(p[i]) << 24) | (static_cast<uint32_t>(p[i + 1]) << 16) |
                        (static_cast<uint32_t>(p[i + 2]) << 8) | static_cast<uint32_t>(p[i + 3]);
                    if (cp > 0x10ffffU || (cp >= 0xd800U && cp <= 0xdfffU)) {
                        error = "UniversalString contains an invalid Unicode scalar value"; return false;
                    }
                }
                break;
            case 30:
                if (n.constructed || (len % 2) != 0) { error = "BMPString must be primitive and have an even length"; return false; }
                for (size_t i = 0; i < len; i += 2) {
                    const uint16_t cp = static_cast<uint16_t>((static_cast<uint16_t>(p[i]) << 8) | p[i + 1]);
                    if (cp >= 0xd800U && cp <= 0xdfffU) { error = "BMPString contains a surrogate code unit"; return false; }
                }
                break;
            default:
                // Unknown universal types are structurally checked but not semantically interpreted.
                break;
        }
        return true;
    }

    bool set_is_sorted(const Node& n) const {
        for (size_t i = 1; i < n.children.size(); ++i) {
            const Node& a = n.children[i - 1];
            const Node& b = n.children[i];
            const size_t common = std::min(a.total_length, b.total_length);
            const int cmp = std::memcmp(bytes_.data() + a.offset, bytes_.data() + b.offset, common);
            if (cmp > 0 || (cmp == 0 && a.total_length > b.total_length)) return false;
        }
        return true;
    }
};

inline Result validate(const std::vector<uint8_t>& bytes, Limits limits = {}) {
    return Parser(bytes, limits).parse();
}

inline std::string tag_name(unsigned tag_class, uint32_t tag) {
    if (tag_class != 0) return tag_class == 1 ? "APPLICATION" : tag_class == 2 ? "CONTEXT" : "PRIVATE";
    switch (tag) {
        case 1: return "BOOLEAN"; case 2: return "INTEGER"; case 3: return "BIT STRING";
        case 4: return "OCTET STRING"; case 5: return "NULL"; case 6: return "OBJECT IDENTIFIER";
        case 10: return "ENUMERATED"; case 12: return "UTF8String"; case 16: return "SEQUENCE";
        case 17: return "SET"; case 18: return "NumericString"; case 19: return "PrintableString";
        case 20: return "TeletexString"; case 22: return "IA5String"; case 23: return "UTCTime";
        case 24: return "GeneralizedTime"; case 26: return "VisibleString"; case 27: return "GeneralString";
        case 28: return "UniversalString"; case 30: return "BMPString";
        default: return "UNIVERSAL(" + std::to_string(tag) + ")";
    }
}

} // namespace ldid::der
#endif
