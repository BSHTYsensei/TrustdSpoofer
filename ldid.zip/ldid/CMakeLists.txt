cmake_minimum_required(VERSION 3.20)
project(ldid_custom_signature_engine LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(OpenSSL 4.1 REQUIRED COMPONENTS Crypto SSL)
find_package(LibArchive REQUIRED)
find_package(CURL REQUIRED)
find_package(Threads REQUIRED)
find_package(PkgConfig REQUIRED)
pkg_check_modules(PLIST REQUIRED IMPORTED_TARGET libplist-2.0)

add_executable(ldid ldid.cpp)
target_include_directories(ldid PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(ldid PRIVATE
    OpenSSL::Crypto
    OpenSSL::SSL
    LibArchive::LibArchive
    CURL::libcurl
    PkgConfig::PLIST
    Threads::Threads
)

if(APPLE)
    find_library(SECURITY_FRAMEWORK Security REQUIRED)
    find_library(COREFOUNDATION_FRAMEWORK CoreFoundation REQUIRED)
    target_link_libraries(ldid PRIVATE ${SECURITY_FRAMEWORK} ${COREFOUNDATION_FRAMEWORK})
endif()

include(CTest)
if(BUILD_TESTING)
    add_executable(der_engine_tests tests/der_engine_tests.cpp)
    target_include_directories(der_engine_tests PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME der_engine_tests COMMAND der_engine_tests)

    add_executable(cms_attribute_tests tests/cms_attribute_tests.cpp)
    target_include_directories(cms_attribute_tests PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    target_link_libraries(cms_attribute_tests PRIVATE OpenSSL::Crypto)
    add_test(NAME cms_attribute_tests COMMAND cms_attribute_tests)
endif()

install(TARGETS ldid RUNTIME DESTINATION bin)
