# LDID Custom Signature Structure Engine (extension work)

This source tree is an extension of the supplied two-file `ldid` archive. Existing command-line signing behavior and `ldid.custom-signature` schema v1 are retained. New templates are emitted as schema v2; the loader accepts schema v1 and v2.

## New inspection commands

```sh
ldid --oid-check 1.2.840.113635.100.6.1.18
ldid --der-inspect attribute.der --hex
ldid --der-inspect certificate-extension.der --json
ldid --certificate-inspect signing-cert.pem
ldid --certificate-inspect signing-cert.der --oid-registry oid-registry.json --json
# or use a schema v2 signature template as the OID registry source:
ldid --certificate-inspect signing-cert.pem --oid-registry template-v2.json
```

`--certificate-inspect` accepts one PEM or DER X.509 certificate and reports each extension's numeric OID, OpenSSL or registry label, Apple/private namespace hint, Critical bit, raw `extnValue` bytes, generic DER validity, certificate validity dates, signature algorithm, public-key type/size, SHA-256 fingerprint, and OpenSSL's best-effort textual decoder output. It reports duplicate extension OIDs and warns about critical extensions for which it has no known decoder. The registry is metadata only; it does not make a critical extension understood by Apple or another relying party. The sample Apple labels are grounded in TN2206 and the Apple Developer ID certificate policy, but an OID match alone never establishes an Apple-issued certificate or trusted chain. Apple TN3127 explicitly scopes its example OID-based Requirements to `anchor apple generic`.

Manage a local OID registry without hand-editing JSON:

```sh
ldid --oid-registry-add oid-registry.json 1.3.6.1.4.1.55555.1.2 "My Extension" "My Enterprise" "Profile extension"
ldid --oid-registry-list oid-registry.json
ldid --oid-registry-validate oid-registry.json
ldid --oid-registry-remove oid-registry.json 1.3.6.1.4.1.55555.1.2
```

`--der-inspect` validates one complete canonical DER value and renders a bounded tree. It rejects indefinite lengths, non-minimal lengths/tags/INTEGER/OID subidentifiers, malformed primitive encodings, non-DER SET ordering, invalid time/string forms, excessive depth/nodes, and trailing bytes.

## SuperBlob custom-blob builder

Existing `customBlobs[].blobHex` import remains supported. Schema v2 also accepts a builder form, so the caller does not need to manually prepend the generic Blob magic/length header:

```json
{
  "customBlobs": [
    { "slot": "0x1234", "magic": "0xfade0c02", "encoding": "der", "payloadHex": "3003020101" },
    { "slot": "0x1235", "magic": "0xfade0b01", "encoding": "plist-xml", "payloadXML": "<?xml version=\"1.0\"?><plist version=\"1.0\"><dict/></plist>" }
  ]
}
```

`encoding` may be `raw`, `der`, or `plist-xml`; `der` and `plist-xml` payloads are validated before the Blob is built. The slot must not collide with a generated standard slot. A custom magic value does not make an arbitrary payload meaningful to Apple; only a known slot/magic/payload contract is interoperable.

## Schema v2 additions

```json
{
  "schema": "ldid.custom-signature",
  "schemaVersion": 2,
  "certificate": {
    "oidRegistry": [
      { "oid": "1.3.6.1.4.1.55555.1.1", "name": "Example Private Extension", "namespace": "Example", "notes": "..." }
    ],
    "requiredExtensions": ["1.2.840.113635.100.6.1.18"]
  },
  "cms": {
    "signedAttributes": [
      { "oid": "1.3.6.1.4.1.55555.2.1", "valueDERHex": "0c0b48656c6c6f20576f726c64" }
    ],
    "unsignedAttributes": []
  }
}
```

The above is a fragment to merge into the template emitted by `ldid --signature-template`; it is not a complete template. The example private OIDs are placeholders and must be replaced by an OID under a PEN/arc controlled by the signer. `requiredExtensions` only asserts that the supplied signing certificate already contains these extensions. It never modifies an issued certificate. A certificate extension must be inserted by the certificate owner during CSR creation or by the issuing CA before the certificate is signed.

### CMS attribute semantics

* Each custom attribute accepts one complete canonical DER value in `valueDERHex`.
* A custom SignedAttribute is inserted before `PKCS7_final`, so it is included in the CMS signature calculation. The library computes the final signature after insertion.
* A custom UnsignedAttribute is attached after signature calculation. It is not protected by the signer's CMS signature.
* Duplicate OIDs in the same attribute set are rejected. Managed CMS attributes (`contentType`, `messageDigest`, and `signingTime`) cannot be overridden. The RFC 3161 timestamp-token and countersignature OIDs are reserved in the unsigned set.
* Custom attributes require a real certificate/private-key identity. They cannot be combined with ad-hoc signing or imported raw CMS/SuperBlob data.
* RFC 3161 timestamp tokens remain handled by the dedicated timestamp workflow.

The DER encoder/validator ensures the attribute is syntactically canonical before OpenSSL decodes it into a CMS `Attribute`. OpenSSL performs final CMS DER encoding and signature calculation. This is not an arbitrary ASN.1 schema compiler: application-specific attribute schemas still need to be defined and validated by the attribute owner.

## Build

Requirements:

* C++17 compiler and CMake 3.20+
* OpenSSL 4.1 development headers and libraries
* libplist development package with pkg-config module `libplist-2.0`
* libarchive and libcurl development packages
* Apple Security and CoreFoundation frameworks when building the macOS-only code paths

Build and run the full executable plus CTest suite:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

Run the standalone DER and CMS unit tests without configuring/linking the full executable:

```sh
./tests/run-tests.sh
# Optional sanitizer pass:
CXXFLAGS="-std=c++17 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer" ./tests/run-tests.sh
```

`make` builds the full executable; `make test` runs the standalone unit tests; `make install` installs the full executable.

## Validation boundaries

The engine distinguishes, rather than conflates:

1. ASN.1 / DER structural validity;
2. CodeDirectory and special-slot hash consistency;
3. CMS signature mathematics;
4. optional X.509 chain validation against configured trust anchors;
5. acceptance by the target Apple operating system and its current policy.

A locally valid DER object or mathematically valid CMS signature does not establish certificate trust or platform acceptance. Apple TN3127 explicitly warns that code-signature internals are not API and have changed over time; Apple recommends using Xcode/`codesign` to sign and `codesign` or the Security framework to inspect and validate signatures. This implementation intentionally works at the format level for compatibility and research, so it must be checked against the actual target OS. Apple-specific requirements depend on the exact OS release, code-signing context, entitlement policy, provisioning profile, and runtime policy. Do not treat setting CodeDirectory flags, adding Apple-looking OIDs, or writing entitlements as granting Apple platform trust or privileges.

## Work not claimed as complete

This increment adds a strict DER validator/inspector and raw-DER CMS attribute integration. It does not yet provide a fully interactive tree editor, a generic ASN.1 schema compiler, certificate issuance/CA signing, universal unknown CodeDirectory field mutation, or target-iOS runtime acceptance testing. Unknown SuperBlob data should continue to be preserved rather than rewritten without a known layout.
